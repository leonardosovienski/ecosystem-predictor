# Kill Criteria — Ecossistema PREDICTORS

Critérios objetivos de encerramento por projeto e por hipótese. Regra geral (seção 51 do mandato): o fato de algo ter recebido muito desenvolvimento NÃO é argumento para continuar (evitar sunk cost fallacy).

## Por projeto

### `ecosystem-predictor`
**Encerrar/reduzir permanentemente à fatia mínima (`contracts` apenas) se, em 60 dias:**
- A colisão de módulos `src`/`scripts` não tiver sido corrigida e coberta por um teste de CI que instale os 3 domínios reais juntos; **ou**
- Nenhum consumidor real (humano ou automatizado) do gateway HTTP surgir; **ou**
- Um sétimo ciclo de "fechamento final"/auditoria interna ocorrer sem que as recomendações do ciclo anterior tenham sido de fato implementadas (padrão já observado 6 vezes).

### `core-predictor`
**Não há critério de encerramento total** — é o único ativo com uso real amplo e verificado. Critério de **poda obrigatória** por módulo: qualquer submódulo com zero consumidores confirmados por 90 dias adicionais após esta auditoria (ledger, rating, ordinal, calibration, nullref, asof, stress, testing.coverage, contracts.economic) deve ser removido ou movido para um repositório de "experimental/incubação" separado do núcleo canônico.

### `predictor-ops`
**Não há critério de encerramento total** — uso real crítico em cripto. Critério de poda: hash-chain de auditoria e backend Redis sem consumidor real confirmado em 90 dias devem ser removidos. Scripts PowerShell "transitional" devem ser removidos ou o prazo formalmente renegociado dentro de 30 dias (já vencido desde a versão 3.0).

### `cripto-predictor`
**Congelar toda a camada `trading/`** até que H6 ou H7 (ou uma hipótese nova) produza um veredito GO líquido de custos — nenhuma condição de tempo, só de resultado.
**Encerrar formalmente H6** se, ao atingir n≈250 (poder adequado medido pelo próprio projeto), o intervalo de confiança do efeito cruzar zero ou for negativo.
**Encerrar formalmente H7** se, após completar a coleta de CPI/PPI e validar `DXYProvider` ponta a ponta, o primeiro backtest walk-forward líquido de custos não mostrar edge com IC95 não cruzando zero em amostra ≥250.
**Não reabrir H1-H5** sem uma mudança estrutural de dado ou hipótese (não reparametrização).

### `brasileirao-predictor`
**Encerrar formalmente o caminho de probabilidade pura (1X2/OU2.5/BTTS via Elo+NB+DC)** — já cumpre o critério: perde do mercado em 4 temporadas consecutivas, concentrado onde o edge deveria aparecer. Não reabrir sem informação PIT genuinamente nova (escalação, lesões, técnico).
**Encerrar formalmente A1** se, dentro de 45 dias da retomada operacional (chave rotacionada + 7 dias de coleta real + auditoria manual de 50 eventos, já especificados no próprio protocolo), a divergência Pinnacle×soft não mostrar spread líquido de fricção economicamente relevante.
**Se A1 não for retomado operacionalmente dentro de 90 dias desta auditoria, mover formalmente para ENCERRADO** (não deixar em limbo pré-registrado indefinidamente).

### `stocks-predictor`
**Domínio de fatores: já cumpre o critério de encerramento** (6/6 hipóteses refutadas com rigor). Não reabrir sem nova fonte de sinal estrutural.
**Linha RJ: não iniciar a primeira rodada real de julgamento até:** (a) a censura por empresa (`censoring_horizon_trading_days`) estar de fato implementada no código, não apenas no config; (b) o resultado da primeira rodada real ser tratado com o mesmo ceticismo que o próprio poder estatístico (68% a N=40, efeito grande) já justifica — um único resultado "significativo" não deve, por si só, autorizar capital.
**Encerrar formalmente a linha RJ** se, após a primeira rodada real completa (ingestão de todos os snapshots disponíveis de emissores em RJ na B3), nenhuma família de features mostrar efeito com IC95 não cruzando zero E robusto a LOCO (leave-one-company-out).

## Critérios de encerramento aplicáveis a qualquer hipótese do ecossistema (regra geral)

Encerrar uma hipótese quando qualquer um dos seguintes for verdadeiro:
1. Ausência persistente de capacidade preditiva (IC cruza zero de forma estável em reexecução).
2. Capacidade preditiva existe mas edge desaparece após custos realistas (o padrão mais comum observado nesta auditoria).
3. Ausência de evidência prospectiva após prazo/amostra razoável definidos a priori.
4. Fragilidade extrema (resultado desaparece com pequenas variações de parâmetro, período ou custo).
5. Dados inviáveis (fonte não escalável a point-in-time, ou universo estruturalmente pequeno demais para poder estatístico adequado — caso RJ).
6. Alternativa externa comprovadamente superior descoberta (não observado nesta auditoria, mas critério válido a manter).
7. Custo de manutenção supera benefício demonstrado por 2 ciclos de revisão consecutivos.

## O que NÃO é critério de encerramento (evitar sunk cost fallacy)
- Volume de código ou commits já investidos.
- Tempo decorrido, isoladamente (sem olhar para o valor da informação do próximo passo).
- "Quase deu certo" sem IC formal que sustente isso.
- Pressão para "ter algo para mostrar" — um encerramento bem documentado É o resultado, não uma falta de resultado.
