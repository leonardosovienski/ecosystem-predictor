# Decisão de Portfólio — Ecossistema PREDICTORS

Este documento consolida a decisão de portfólio da auditoria (Partes XX-XXII do relatório master), como ferramenta autônoma de alocação de recursos.

## Decisão por projeto

| Projeto | Decisão | Condição/gatilho | Reversão |
|---|---|---|---|
| `ecosystem-predictor` | **REDUZIR** | Manter `contracts`+`registry` só se a colisão de módulos for corrigida e testada com os 3 domínios reais em CI; remover Postgres/Redis/S3/scheduler/gateway do `compose.yaml` até haver consumidor real | Reverter para MANTER se um consumidor real do gateway HTTP surgir e o bug crítico for corrigido e comprovadamente estável |
| `core-predictor` | **MANTER + REDUZIR** | Manter o núcleo essencial (~68-77% já usado); podar módulos dormant (~22-24%) em 90 dias se nenhum consumidor surgir; cortar tag atualizada | Reverter poda se um domínio novo (dentro ou fora do ecossistema atual) demonstrar necessidade real de um módulo hoje dormant |
| `predictor-ops` | **MANTER + REDUZIR** | Manter núcleo (`runner`/`redaction`/`runtime` local); podar hash-chain/Redis/scripts Windows vencidos; resolver a dependência decorativa em `stocks-predictor` | Reverter poda de Redis se cripto ou brasileirão passarem a rodar em múltiplas máquinas concorrentes |
| `cripto-predictor` | **MANTER + TESTAR** (escopo reduzido) | Congelar `trading/`; continuar coleta H6 até n≈250; completar H7; NÃO escalar capital/engenharia até GO líquido | Reverter para ENCERRAR se H6 e H7 ambos falharem e nenhuma hipótese nova surgir em 6 meses |
| `brasileirao-predictor` | **CONGELAR** (probabilidade pura) + **MANTER+TESTAR** (A1) + **MANTER** (plataforma) | Não reabrir 1X2/OU2.5/BTTS sem informação PIT nova; retomar A1 só com chave rotacionada + 7 dias reais; preservar engine como ativo de plataforma | Reverter A1 para ENCERRAR se Experimento 3 (backlog) falhar; reverter probabilidade pura só com dado estrutural novo |
| `stocks-predictor` | **CONGELAR** (fatores) + **MANTER+TESTAR** (RJ, condicionado) | Fatores permanece encerrado; RJ só avança após correção da censura por empresa; primeira rodada real com expectativa calibrada para baixo | Reverter RJ para ENCERRAR se Experimento 4 (backlog) falhar |

## Reduções de portfólio

**6 → 3**: `core-predictor` + `cripto-predictor` + `brasileirao-predictor`. Critério: `core-predictor` é o único ativo de infraestrutura com valor verificado independentemente; entre os domínios, cripto tem a disciplina científica mais madura e hipóteses vivas com poder ainda insuficiente (não refutadas), brasileirão tem a evidência mais completa e um caminho estrutural (A1) genuinamente distinto do que já falhou. `predictor-ops` seria absorvido como dependência de cripto; `ecosystem-predictor` e `stocks-predictor` sairiam.

**3 → 2**: `core-predictor` + **um** domínio econômico. Entre cripto e brasileirão, levemente a favor de **brasileirão** pelo caminho A1 (estruturalmente diferente de "vencer o mercado em probabilidade", que já foi refutado nos dois domínios de formas distintas). **Esta é a decisão de menor confiança desta síntese** — depende de informação não coletada nesta auditoria (custo real de reativar A1 vs. custo de levar H6 a n≈250).

**2 → 1**: `core-predictor`. Não pelo valor econômico (nenhum domínio tem, ainda) mas por ser o único ativo com valor **verificado independentemente**, domain-agnostic, e que preserva o ativo mais raro do ecossistema (a governança anti-p-hacking).

## Perguntas de alocação marginal (seção 55)

- **Qual projeto merece mais atenção agora?** `cripto-predictor` — hipóteses vivas (H6/H7) a uma decisão operacional simples (continuar coletando) de uma resposta definitiva.
- **Qual projeto mais provavelmente consome esforço sem retorno?** `ecosystem-predictor` — único com evidência direta de ciclo não convergente (6+ fechamentos, auditoria "do zero" auto-solicitada).
- **Qual infraestrutura deve permanecer?** Núcleo de `core-predictor` e núcleo de `predictor-ops`.
- **Qual infraestrutura deve ser simplificada?** `ecosystem-predictor` (quase inteiro), módulos dormant do core, componentes sem consumidor do ops.
- **Onde existe maior opcionalidade?** `core-predictor` — domain-agnostic, barato de redirecionar.
- **Onde existe maior evidência econômica?** Em nenhum lugar no sentido positivo; a evidência econômica mais sólida do ecossistema é negativa (brasileirão perde do mercado; cripto H1-H5 sem edge) — valiosa por eliminar caminhos, não por gerar lucro.
- **Onde existe maior ilusão de progresso?** `ecosystem-predictor` (razão documentação:código ~7-8:1, ciclos de "fechamento final" não convergentes).
- **Onde existe maior valor científico mesmo sem lucro?** `cripto-predictor` (pré-registro + DSR/PBO + controle positivo + medição de poder, generalizável).
- **Melhor alocação marginal das próximas horas/dinheiro?** (1) corrigir/decidir o bug de `ecosystem-predictor`; (2) continuar a coleta de H6 sem novo código; (3) decidir explicitamente (com prazo) se A1 será retomado.

## Cenários estratégicos — resumo da recomendação

Ver Parte XXII do relatório master para a análise completa dos 4 cenários (A: continuar como está; B: reduzir estratégias e monetizar infraestrutura; C: manter só pesquisa científica mínima; D: encerrar a maior parte, preservar ativos). **Recomendação: híbrido C+D** — congelar/encerrar caminhos já refutados, manter aberto e barato o que está perto de uma resposta (H6/H7, RJ condicionado, A1 condicionado), tratar B como hipótese a validar com esforço mínimo (Experimento 5 do backlog), não como decisão já tomada.
