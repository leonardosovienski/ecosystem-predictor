# AUDITORIA ESTRATÉGICA DO ECOSSISTEMA PREDICTORS — RELATÓRIO MASTER

**Auditor:** sessão independente de auditoria técnica/científica/estatística/econômica/estratégica (Claude, orquestrando 6 subauditorias especializadas, uma por repositório, mais síntese transversal).
**Data da auditoria:** 2026-08-31. **Método:** clone real dos 6 repositórios, leitura de código, execução real de testes/scripts/backtests onde possível, reprodução independente de valores matemáticos, grep exaustivo cross-repo, nenhuma alteração permanente a nenhum dos 6 repositórios.
**Documentos-fonte desta síntese:** os 6 relatórios individuais completos (`audit_notes/ecosystem-predictor.md`, `core-predictor.md`, `predictor-ops.md`, `cripto-predictor.md`, `brasileirao-predictor.md`, `stocks-predictor.md`), entregues junto com este master e citados aqui como PARTE IV-IX. Este documento **sintetiza**; para a evidência linha-a-linha, ver os originais.

---

## PARTE I — EXECUTIVE SUMMARY

### Conclusão principal

O ecossistema PREDICTORS é, na data do congelamento, um caso limpo de **infraestrutura crescendo mais rápido que evidência econômica** — mas não de forma uniforme, e não sem valor real. Em 6 repositórios, ~280+~235+~150+~88+~91+~140 = **≈980 commits em 2,5 meses** (o mais antigo nasceu em 2026-06-12, o congelamento é 2026-08-31), produziram: três domínios econômicos (cripto, futebol, ações) em que **nenhuma hipótese fechada gerou edge líquido positivo, prospectivo e capturável**; e três peças de infraestrutura compartilhada cuja adoção real é desigual e, num dos três casos (`ecosystem-predictor`), contém um **bug crítico não detectado** que invalida a única alegação central do repositório ("descoberta de plugins mecanicamente verificável entre os 3 domínios").

Ao mesmo tempo, seria falso e não sustentado pela evidência dizer que "nada tem valor". Existe um núcleo real e tecnicamente correto (`core-predictor`, ~68-77% efetivamente consumido, matemática verificada de forma independente) e uma cultura de pesquisa incomum para este tipo de projeto: **disciplina genuína de auto-refutação** — em pelo menos duas famílias de hipóteses (cripto H1-H5, brasileirão H1/H11/MARKET-02-06), resultados negativos foram registrados, aceitos e usados para fechar caminhos, em vez de escondidos ou reciclados. Isso é evidência científica válida, mesmo sem lucro.

### Por que houve tanto desenvolvimento sem lucro econômico comprovado?

Quatro mecanismos, todos com evidência direta nos 6 relatórios:

1. **A pergunta certa (existe edge?) foi, nos três domínios, testada com rigor genuíno — e a resposta honesta até agora é "não" ou "ainda não sabemos".** Isso não é falha de processo; é o resultado mais provável em mercados razoavelmente eficientes (apostas esportivas líquidas, ações líquidas, cripto majors) testados com metodologia correta. O processo funcionou; o resultado é apenas desfavorável.
2. **Investimento em infraestrutura antecipou necessidade em vez de responder a ela.** `ecosystem-predictor` provisiona Postgres/Redis/S3 obrigatórios para simplesmente iniciar, sem que nenhum caminho de código real os use. `core-predictor` tem ~22-24% de código (ledger, rating/Elo, ordinal, calibration, nullref, contracts.economic) construído citando domínios (LoL, F1, NBA, Copa) que já não existem no ecossistema atual — o próprio ecossistema encolheu de ~9 repositórios/5 domínios econômicos para os 6/3 atuais, deixando módulos órfãos.
3. **Um caso de override deliberado de governança**: em `cripto-predictor`, o dono construiu toda a camada de execução de trading (`trading/`, 99% de cobertura de teste) **antes** de qualquer hipótese validar edge, contra a própria política do projeto — custo de oportunidade real, não hipotético.
4. **Ciclos recorrentes de "auditoria → fechamento final → reabertura"** em `ecosystem-predictor` (pelo menos 6 documentos de "fechamento definitivo" em 40 dias, terminando com um commit final que pede uma auditoria "do zero" descartando todas as conclusões anteriores) sugerem que parte do esforço recente é consumida por processo de governança que não converge, não por pesquisa ou engenharia que avança a tese econômica.

### Estado dos 6 projetos (resumo; ver Parte XX para justificativa completa)

| Projeto | Decisão | Confiança |
|---|---|---|
| `ecosystem-predictor` | **REDUZIR** | Alta nos fatos; média na decisão |
| `core-predictor` | **MANTER + REDUZIR** | Alta |
| `predictor-ops` | **MANTER + REDUZIR** | Média-alta |
| `cripto-predictor` | **MANTER + TESTAR** (escopo reduzido, não escalar) | Alta |
| `brasileirao-predictor` | **CONGELAR** (edge de probabilidade) / **MANTER+TESTAR** (arbitragem A1) / **MANTER** (motor como plataforma) | Média-alta |
| `stocks-predictor` | **CONGELAR** (fatores) / **MANTER+TESTAR** (linha RJ) | Média-alta |

### As maiores descobertas (por valor de decisão)

1. **Bug crítico em `ecosystem-predictor`, nunca detectado pelo próprio repositório, reproduzido nesta auditoria de ponta a ponta com os 3 pacotes reais instalados juntos**: o plugin registrado como `"stocks"` é literalmente o mesmo objeto Python do plugin `"brasileirao"` (colisão do nome de módulo genérico `src`). O mecanismo "fail-closed" mais enfatizado do repositório não cobre esse caso — o plugin carrega com sucesso e devolve dados errados, silenciosamente. Nenhum CI do ecossistema jamais instala os 3 domínios juntos.
2. **Zero hipóteses econômicas aprovadas para capital, ecossistema inteiro, na última contagem auditável (42 hipóteses registradas em 2026-07-26) e reconfirmado ao vivo nesta auditoria** (`capital_permission=FORBIDDEN` para os 3 domínios, executado de fato, não apenas lido em documento).
3. **`brasileirao-predictor` perde do "mercado" de forma consistente em 4 temporadas** (RPS agregado +0,0112, concentrado em jogos de baixa confiança — exatamente onde um edge precisaria aparecer) — evidência ativa **contra** a tese central do domínio, não apenas ausência de evidência a favor.
4. **`stocks-predictor`: 6 de 6 hipóteses do domínio de fatores formalmente encerradas como não comprovadas**; a linha ativa (RJ — recuperação judicial) está em estágio M0 absoluto (zero linhas de dado real em 13 tabelas, confirmado por execução), com poder estatístico estruturalmente insuficiente mesmo antes de qualquer dado entrar (N=40, efeito grande de 1σ → 68% de poder, abaixo do convencional 80%).
5. **`cripto-predictor`: nenhuma família de hipóteses fechada mostrou edge líquido positivo**; uma delas (H5, n=440) mostrou correlação **negativa e estatisticamente significativa**, na direção oposta à hipótese. A camada de execução de trading foi construída antes de qualquer validação, contra a política do próprio projeto.
6. **`core-predictor` é o único componente de infraestrutura com pegada de uso real ampla e matemática verificada independentemente** (brier/log_loss/rps/max_drawdown reproduzidos à mão; PSR verificado algebricamente) — mas seu HEAD atual já diverge do wheel publicado que os 3 domínios de fato instalam (STALE confirmado).
7. **`predictor-ops` tem adoção real desigual**: crítico em `cripto-predictor`, parcial e em recuo em `brasileirao-predictor` (o caminho de decisão mais atual, H9, já não passa pela lib), e puramente decorativo em `stocks-predictor` (confirmado por grep exaustivo e por um shim falso rodado por um auditor terceiro sem quebrar nada).
8. **O ecossistema já foi maior**: evidência cruzada e independente em 3 dos 6 relatórios (`ecosystem-predictor`, `core-predictor`, `predictor-ops`) mostra que já existiram até 5 domínios econômicos (`lol-predictor`, `cs-predictor`, `f1-predictor`, além dos 3 atuais) e uma menção a um "snapshot de 9 repositórios" — consolidado para os 6 atuais em 2026-08-23. Isso é o pano de fundo real do "muita infraestrutura, pouca evidência": parte da infraestrutura foi dimensionada para uma superfície maior, hoje podada.
9. **Padrão sistêmico de documentação desatualizada em relação ao código, repetido de forma independente nos 6 repositórios**: `ecosystem-predictor` (docstring do registry cita grupo de entry-point errado), `core-predictor` (HEAD à frente do wheel publicado), `predictor-ops` (prazo de remoção de scripts Windows vencido), `brasileirao-predictor` (documento genérico que na verdade é 100% sobre outro domínio), `stocks-predictor` (HANDOFF afirma uma correção que o código não reflete). Isso não é um incidente isolado — é um padrão de processo.
10. **Um padrão positivo igualmente sistêmico**: em pelo menos 2 dos 3 domínios (cripto e brasileirão), quando um resultado retrospectivo "bonito" aparece (kelly-sweep pré-custos em cripto, OU2.5/2025 em brasileirão), **o próprio projeto o identifica corretamente como artefato/não executável antes que esta auditoria precisasse apontar isso**. Essa disciplina de auto-ceticismo é um ativo real, reutilizável e mais raro do que o código em si.

### Maiores riscos

- **Bus factor = 1** em todo o ecossistema (autor humano único, confirmado diretamente em `predictor-ops`, e consistente com o padrão de autoria observado nos demais). Nenhuma decisão de portfólio deveria ignorar isso.
- **Governança que não converge** (`ecosystem-predictor`): ciclos de auditoria sem critério de saída objetivo consomem esforço sem gerar decisão.
- **Multiple testing subestimado** em pontos específicos e identificados: `run_threshold_grid` em cripto, ~80 configurações do funil OU2.5 em brasileirão — nenhum dos dois tem correção de multiplicidade formal cobrindo a busca inteira.
- **Barreira anti-lookahead do `core-predictor` é contornável** por acesso a atributo "privado" (`PastView._data`) — demonstrado com um script real em `stocks-predictor`; é uma barreira de convenção, não uma garantia estrutural do Python.

### Recomendação de portfólio (resumo; detalhe na Parte XXI)

Reduzido para o essencial: **preservar o núcleo científico compartilhado** (`core-predictor`, com poda dos módulos dormant) e a **cultura de pesquisa/anti-p-hacking** como o ativo mais valioso e defensável do ecossistema; **não escalar capital ou engenharia em nenhum dos 3 domínios econômicos** até que uma hipótese específica (H6/H7 cripto a n≈250; A1 brasileirão com coleta real; RJ stocks com primeira rodada real) produza evidência líquida positiva; **reduzir `ecosystem-predictor`** à sua fatia realmente usada (`contracts`+`registry`, com o bug de colisão corrigido e testado) e **parar de provisionar Postgres/Redis/S3** sem consumidor demonstrado; **manter `predictor-ops`** com poda do que não tem consumidor confirmado (hash-chain, backend Redis, scripts Windows vencidos).

---

## PARTE II — METODOLOGIA E ESTADO AUDITADO

### Commits e estado congelado (FACT, `git log`/`git status` executados nesta sessão)

| Repositório | Branch | HEAD SHA | Data HEAD | Commits totais | Primeiro commit | Working tree |
|---|---|---|---|---|---|---|
| `cripto-predictor` | main | `c2222586cfef0391e2360df970fed7a86f03027a` | 2026-08-28 | 279 | 2026-06-16 | limpo |
| `brasileirao-predictor` | main | `e27db0cf078f747c26cf3e44487d097278e5605b` | 2026-08-31 | 235 | 2026-07-10 | limpo |
| `stocks-predictor` | main | `93a4d0ff1bb6b43cad87bf25377ef69a2091b267` | 2026-08-30 | 150 | 2026-06-12 | limpo |
| `core-predictor` | main | `2ca42fd1b6519cc338ba41ca96c427c8a6423afc` | 2026-08-26 | 88 | 2026-06-16 | limpo |
| `predictor-ops` | main | `c2f2ee0e03c5e37a2a379df2e27be0ae9e4c56e3` | 2026-08-26 | 91 | 2026-07-15 | limpo |
| `ecosystem-predictor` | main | `e690594e51543b608bea83b2ec71228e539dfc07` | 2026-08-24 | 140 | 2026-07-17 | limpo |

Congelamento da auditoria: **2026-08-31**, todos os 6 repositórios clonados via HTTPS público no início desta sessão, nenhuma alteração feita depois.

### Ambiente

Python 3.11 (padrão do container), 3.12 e 3.13 disponíveis via `uv`; testes rodados majoritariamente em Python 3.13. `uv` usado como gerenciador em todos os 6 repos (todos têm `uv.lock`). Dependências externas reais (`predictor-core` wheel v2.3.0, `predictor-ops` wheel v3.1.0) baixadas com sucesso do GitHub Releases em todos os ambientes de teste — a rede do ambiente de auditoria permitiu isso (nota: HANDOFFs de `cripto-predictor` registram sessões anteriores com rede bloqueada; não foi o caso aqui).

### O que foi de fato executado (não apenas lido) — resumo cross-repo

- **296/296 testes** de `core-predictor` (86,55% cobertura de branch).
- **80+1+3 testes** de `predictor-ops` (`tests_v2` + `posix_integration` + `integration_tests` com Redis real subido pelo auditor); `windows_integration` não executável neste ambiente Linux (limitação declarada, não falha).
- **70 testes** de `ecosystem-predictor` isolado (83% cobertura) + **reprodução real de ponta a ponta** instalando os 3 domínios reais juntos (achado crítico, ver Parte IV).
- **832/834 testes** de `cripto-predictor` (2 skips por dependência não instalada), controle positivo e `attest_harness.py --dry-run` reproduzidos.
- **873/874 testes** de `brasileirao-predictor` (1 skip, 1 deselecionado), barreiras estáticas de CI reproduzidas.
- **242/242 testes** de `stocks-predictor`, scripts de auto-diagnóstico (`audit_db.py`, `diagnose_universe.py`, `poc_leak.py`) executados com sucesso.

### Principais impossibilidades de reprodução (declaradas, não escondidas)

- **Nenhum dado bruto de mercado** (OHLCV/funding/OI de cripto, `matches.db` do Brasileirão, `stocks.db`/COTAHIST de ações) está presente em nenhum dos 3 repositórios de domínio — todos vivem fora do Git, na máquina do dono, por design. **Todos os números exatos de PSR/Spearman/Sharpe/RPS/Brier/ROI citados nos 3 domínios são, para esta auditoria, CLAIM DOCUMENTAL (L1-L2), não recalculados de forma independente**, exceto onde uma checagem cruzada entre dois artefatos já commitados foi possível (ex.: H12 do Brasileirão, valores idênticos entre `trials.json` e o relatório bruto).
- Testes de integração Windows (`predictor-ops/windows_integration`, `.NET LineupWorker` do Brasileirão) não executáveis neste ambiente Linux.
- Chaves de API reais (`ODDS_API_KEY`, `ODDSPAPI_KEY`, exchanges de cripto) ausentes por design — nenhum provedor de dados ao vivo pôde ser testado.

### Nível de acesso e limitações desta síntese

Cada um dos 6 subauditores recebeu o texto integral das seções relevantes do documento-mestre da auditoria (fornecido pelo usuário), mas não o documento completo de 66 seções palavra por palavra em todos os casos — em alguns relatórios individuais isso está marcado explicitamente ("reconstruí as 13 perguntas do checkpoint com base no espírito da tarefa"). Isso é registrado aqui por transparência: as respostas aos checkpoints obrigatórios são reconstruções de boa-fé, fiéis ao objetivo declarado da auditoria, não citações literais de um texto que os subauditores não receberam palavra por palavra.

---

## PARTE III — MAPA DO ECOSSISTEMA

```
                     ┌─────────────────────┐
                     │  ecosystem-predictor │  ← "control plane": registry, gateway HTTP,
                     │  (REDUZIR)           │    contracts Pydantic, Postgres/Redis/S3 (não usados)
                     └──────────┬───────────┘
                                │ descobre via entry_points
                                │ "predictor.plugins" (UNIDIRECIONAL — nenhum domínio importa ecosystem)
                                │ [BUG: stocks e brasileirao colidem quando instalados juntos]
              ┌─────────────────┼─────────────────┐
              │                 │                 │
     ┌────────▼──────┐ ┌────────▼────────┐ ┌──────▼─────────┐
     │cripto-predictor│ │brasileirao-pred.│ │stocks-predictor │
     │(MANTER+TESTAR) │ │(CONGELAR/TESTAR)│ │(CONGELAR/TESTAR)│
     └───────┬─────────┘ └────────┬────────┘ └───────┬─────────┘
             │  todos consomem via wheel do GitHub Releases │
             └─────────────────┬─────────────────────────────┘
                                │
                  ┌─────────────▼─────────────┐
                  │      core-predictor        │  ← contratos científicos, stats, trials,
                  │      (MANTER+REDUZIR)      │    ~68-77% consumido, matemática verificada
                  └─────────────┬───────────────┘
                                │
                  ┌─────────────▼─────────────┐
                  │      predictor-ops         │  ← runner de jobs, redação de segredos
                  │      (MANTER+REDUZIR)      │    uso desigual: cripto>>brasileirão>>stocks(~0)
                  └─────────────────────────────┘
```

**Achado estrutural chave**: a seta de `ecosystem-predictor` para os 3 domínios é a única integração "horizontal" do ecossistema, e é exatamente essa seta que está quebrada quando testada de ponta a ponta (Parte IV). As setas de `core-predictor`/`predictor-ops` para os 3 domínios são reais e majoritariamente confirmadas, mas com adoção desigual — nenhum dos 3 domínios usa 100% da superfície de nenhuma das duas libs.

O ecossistema **encolheu**: evidência cruzada e independente em `ecosystem-predictor` (4 redefinições de escopo canônico em 40 dias, de "9 repositórios"/"5 domínios" para os 6/3 atuais) e em `predictor-ops` (HANDOFF deletado, recuperado via `git show`, cita 5 consumidores: `brasileirao-predictor, cs-predictor, f1-predictor, lol-predictor, previsao-cripto`) confirmam que o ecossistema já foi maior e foi consolidado — o que explica boa parte do código "dormant" encontrado em `core-predictor` (módulos citando LoL/F1/NBA/Copa/eleições/clima).

---

## PARTE IV — AUDITORIA ECOSYSTEM (síntese)

Ver `audit_notes/ecosystem-predictor.md` para o relatório completo (289 linhas, matriz de contradições, 13 perguntas de checkpoint). Achados centrais:

- Nasceu como repositório de **documentação de governança** (17/07), não como plataforma — o primeiro código de aplicação aparece 16 dias e ~30 commits depois. Razão documentação:código de produção ≈ **7-8:1**.
- **Achado crítico [L6, reproduzido nesta auditoria, nunca documentado no repositório]**: instalando os 3 domínios reais juntos com `ecosystem-predictor`, `registry.get('stocks').instance is registry.get('brasileirao').instance` → `True`. O plugin "stocks" é o mesmo objeto Python do plugin "brasileirao", por colisão do nome de módulo genérico `src` nos dois `pyproject.toml`. O design "fail-closed" não cobre esse caso (o plugin carrega com sucesso e devolve dados errados). Nenhum CI do repositório jamais testou os 3 domínios juntos.
- Segunda colisão real encontrada: a suíte de testes do próprio `ecosystem-predictor` **quebra na coleta** se `brasileirao-predictor` estiver instalado junto (colisão do pacote `scripts`).
- Postgres, Redis e object storage são **obrigatórios para o processo iniciar**, mas nenhum caminho de código real os lê ou escreve (`db/models.py` com 0% de cobertura).
- Nenhum dos 3 domínios importa este pacote — acoplamento é unidirecional e, mesmo assim, quebrado na única integração que testa de verdade.
- 4 redefinições do "escopo canônico" em 40 dias; 6+ documentos de "fechamento final"; o **último commit do repositório** é um prompt pedindo auditoria "do zero" que descarta explicitamente todas as conclusões anteriores.
- **Recomendação: REDUZIR.**

---

## PARTE V — AUDITORIA CORE (síntese)

Ver `audit_notes/core-predictor.md` (370 linhas) para o relatório completo. Achados centrais:

- Único componente de infraestrutura com **pegada de uso real ampla**: ~68% dos submódulos, ~76-77% das linhas, com consumo confirmado em 40+ arquivos de produção nos 3 domínios.
- **Matemática verificada independentemente**: `brier`/`log_loss`/`rps`/`max_drawdown` reproduzidos à mão e batendo exatamente (tolerância 1e-12); PSR verificado algebricamente contra Bailey & López de Prado (2012); bootstrap com os 4 esquemas corretos estruturalmente. Nenhum erro matemático encontrado.
- **296/296 testes passam**, 86,55% cobertura de branch (acima do gate de 80%).
- **STALE confirmado**: HEAD tem 4 commits além da tag `v2.3.0` publicada, com correções reais de comportamento (`ledger.py`, `trials.py`, `harness.py`), sem bump de versão — os 3 domínios instalam o wheel `v2.3.0` e **não recebem essas correções**.
- **~22-24% do código é dormant** (ledger, rating/Elo, ordinal/Plackett-Luce, calibration, nullref, asof, stress, testing.coverage, contracts.economic) — construído citando domínios (LoL, F1, NBA, Copa, eleições, clima) que não estão nos 3 domínios atuais.
- `stocks-predictor` ainda carrega um `vendor/predictor_core` obsoleto (v1.3.0) em estado `DRIFT`, confirmado pela própria ferramenta `sync_core.py --audit` do repo.
- O maior módulo do repositório inteiro (`contracts/economic.py`, 442 linhas, lançado há 2 semanas) tem **zero consumidores**.
- Valor comercial independente: a matemática é padrão de mercado (equivalente em empyrical/scikit-learn/mlfinlab); o diferencial real é a **governança de processo** (TrialRegistry N+1, power attestation) — sem equivalente pronto no mercado, mas sem validação de demanda externa.
- **Recomendação: MANTER + REDUZIR** (poda dos módulos dormant; corrigir a divergência HEAD/tag).

---

## PARTE VI — AUDITORIA OPS (síntese)

Ver `audit_notes/predictor-ops.md` (279 linhas) para o relatório completo. Achados centrais:

- **Bus factor = 1** confirmado diretamente (91 commits, um único autor humano).
- O ecossistema já teve **5 domínios consumidores** (`brasileirao-predictor, cs-predictor, f1-predictor, lol-predictor, previsao-cripto`), recuperado de um HANDOFF deletado — evidência independente do encolhimento do ecossistema.
- **80 testes passam (88,02% cobertura)**, mais testes de integração real com Redis (3/3, subido pelo próprio auditor) e POSIX (1/1). `windows_integration` não testável neste ambiente (esperado). Este é um dos poucos repositórios em que o autorrelato de evidência (`docs/audit-evidence.md`) resistiu à reverificação independente quase exatamente (87,87% documentado vs. 88,02% reexecutado).
- **Uso real profundamente desigual**: `cripto-predictor` depende de forma crítica e funcional (execução de jobs, watchdogs, redação de segredos); `brasileirao-predictor` usa parcialmente e está em recuo (o caminho de decisão mais atual, funil H9, já não passa pela lib — roda como script Python puro); `stocks-predictor` declara a dependência mas **tem zero uso funcional confirmado**, corroborado por um relatório de auditoria externo já presente no próprio repo `stocks-predictor` que rodou toda a suíte com um shim falso sem quebrar nada.
- **Não é um orquestrador** (Airflow/Prefect/Dagster) — é uma lib fina de "hardening de execução de job único" que delega scheduling para `cron`/Task Scheduler. Um `cron` + script hardened de ~150-250 linhas cobriria ~70-80% do valor hoje realmente consumido.
- Componentes sem consumidor confirmado: hash-chain de auditoria (`audit.py`), backend Redis em produção, `compat/vendor_audit.py`. Scripts PowerShell "transitional" com prazo de remoção formalmente vencido (alvo 3.0, ainda presentes na 3.1.0).
- **Recomendação: MANTER + REDUZIR.**

---

## PARTE VII — AUDITORIA CRIPTO (síntese)

Ver `audit_notes/cripto-predictor.md` (208 linhas) para a tabela completa de hipóteses. Achados centrais:

- 279 commits / 2,5 meses. Nome `GarimpoInvestimentos` reflete literalmente o padrão de "garimpar" veios de sinal: pelo menos 4 famílias de hipóteses distintas tentadas (HMM+funding/OI; LLM-score D+7 direto; LLM-score D+7 invertido; trend-following técnico simples), todas fracassando líquido de custos ou imaturas.
- **832 testes passam**; controle positivo (`test_positive_control.py`) e `attest_harness.py --dry-run` reproduzidos — provam que a metodologia detecta sinal quando existe, **não** que existe edge real em cripto.
- **Nenhum dado bruto de mercado disponível nesta auditoria** — todos os valores exatos de PSR/Spearman/Sharpe são CLAIM DOCUMENTAL (L1-L2); o que foi verificado independentemente é a metodologia e o código.
- **H1-H3** (HMM+funding/OI): edge líquido negativo em todos os casos, reconfirmado em reexecução de base estendida (2026-08-27). **INVALIDADO**.
- **H5** (LLM D+7, n=440): correlação **negativa e estatisticamente significativa** (Spearman −0,166, IC95 [−0,266;−0,057]), na direção **oposta** à hipótese. **INVALIDADO**.
- **Trend-following 4h**: bruto +54,2%, líquido **−62,0%** — destruído por turnover.
- **SMA200 diário**: positivo em nível absoluto mas reprovado no gate pré-registrado (IC cruza zero, BTC não bate buy&hold).
- **H6** (inversão do sinal LLM): desenho prospectivo correto, mas `n=0` no último artefato commitado (2026-08-24, 7 dias antes do congelamento). **H7** (macro/DXY): infraestrutura pronta, zero dados coletados.
- **Achado crítico de governança**: em 2026-08-14, o dono construiu toda a camada de execução (`trading/`, 99% cobertura) **antes** de qualquer hipótese validar edge, contra a própria política do projeto (B8). Custo de oportunidade real.
- **Padrão de auto-refutação honesta e raro**: kelly-sweep pré-custos descartado como artefato; H5 relata explicitamente que um estrato alternativo teria dado resultado não-significativo mas mantém o veredito pré-registrado; documento de auditoria corrompido mantido documentado em vez de escondido; o projeto mediu formalmente o **poder do próprio gate estatístico** (n=30 detecta rho=0,2 em só ~14,7% das vezes; poder adequado exige n≈250).
- **Recomendação: MANTER + TESTAR (escopo reduzido), NÃO ESCALAR.**

---

## PARTE VIII — AUDITORIA BRASILEIRÃO (síntese)

Ver `audit_notes/brasileirao-predictor.md` (636 linhas — o relatório individual mais extenso, refletindo o volume de auto-auditorias internas já existentes no repo) para a tabela completa de hipóteses. Achados centrais:

- 235 commits / 7 semanas. Motor Elo+Binomial-Negativa+Dixon-Coles, réplica de um motor já usado no repo-irmão da Copa do Mundo.
- **873 testes passam.** Nenhum banco operacional (`matches.db`, 49,5MB) disponível nesta auditoria — todos os números primários de RPS/Brier/ROI são CLAIM DOCUMENTAL, exceto checagem cruzada H12 (números idênticos entre ledger e artefato bruto, confirmado).
- **Achado central**: o modelo **perde do "mercado" de forma consistente em RPS/Brier/log-loss nas 4 temporadas observadas** (2021-2024, n=1.318), desvantagem agregada de RPS +0,0112, concentrada justamente nos jogos de baixa confiança do modelo (onde um edge precisaria aparecer). Isto é evidência **ativa contra** a tese, não apenas ausência de evidência a favor — e o próprio projeto chega à mesma conclusão de forma honesta.
- A fonte de "mercado" usada nesse benchmark é fraca (agregado Sofascore sem bookmaker nomeado, `DIAGNOSTIC_ONLY`) — e 99,2% dos snapshots de odds do banco operacional são pós-jogo, não point-in-time.
- **Nenhum caminho econômico chegou a capital real** em 235 commits. O único mecanismo ainda formalmente vivo (arbitragem estrutural A1, Pinnacle × casas soft BR) está `NOT_STARTED` de forma consistente em 3 checkpoints datados; automação desligada em 28/08 por pedido do usuário.
- **Risco de multiple testing real e reconhecido pelo próprio time**: ~80 configurações exploradas no funil OU2.5 sem correção formal de multiplicidade cobrindo a busca inteira. O único resultado retrospectivo positivo (OU2.5/2025, ROI +23,65%, IC95 [5,91%;41,21%]) é exatamente o tipo de achado que uma busca desse tamanho produz por acaso — e o próprio projeto já o rotula como não executável.
- **Engenharia anti-leakage genuinamente forte**: walk-forward real (`PrequentialEvaluator`), guarda adicional contra vazamento entre jogos simultâneos da mesma rodada; correções matemáticas documentadas (clip de rho, decay do Elo) confirmadas implementadas, não STALE.
- **Recomendação: CONGELAR** o caminho de probabilidade pura; **MANTER+TESTAR** apenas a arbitragem A1, condicionada a retomada operacional real; **MANTER** o motor/infraestrutura como ativo de plataforma reutilizável.

---

## PARTE IX — AUDITORIA STOCKS (síntese)

Ver `audit_notes/stocks-predictor.md` (220 linhas) para a tabela completa de hipóteses. Achados centrais:

- 150 commits / 2,5 meses. Dois domínios distintos e não fundidos: (1) fatores cross-sectional (momentum, baixa-vol, sizing, reversão, filtro duplo) e (2) linha ativa **"RJ" = Recuperação Judicial** (não outra sigla) — event-driven distressed/lottery investing em ações quase-falidas na B3.
- **242 testes passam.** **6 de 6 hipóteses do domínio de fatores formalmente encerradas como "NÃO COMPROVADA"** entre 12/07 e 28/08, com IC sempre cruzando zero e DSR sempre abaixo do limiar — sem repescagem de parâmetros.
- **A linha RJ está em M0 absoluto**, confirmado por execução real (`audit_db.py`): 13 tabelas, incluindo `rj_universe`/`rj_episodes`/`rj_events`, **todas com 0 linhas**. Toda a maquinaria (242/242 testes verdes) foi testada apenas em sintético.
- **Achado quantitativo mais importante desta linha**: o próprio poder estatístico do estudo, medido pelo próprio auditor via `rj_power.py`, mostra que mesmo com efeito grande (1σ) e N=40 empresas, o poder é 68% — abaixo do convencional 80%. O universo real de empresas em RJ na B3 tende a ser pequeno, tornando o desenho estruturalmente subdimensionado antes mesmo de qualquer dado entrar.
- **Origem da hipótese**: motivada por um caso midiático específico (AMER3/Americanas, +194%) — viés de proveniência da pergunta de pesquisa, mesmo com desenho estatístico subsequente rigoroso (censura por episódio, LOCO, FDR pré-registrado).
- **`poc_leak.py` reproduziu um leak real**: a barreira anti-lookahead do `predictor_core` (`PastView`) é contornável lendo o atributo interno `_data` — achado relevante repassado à auditoria de `core-predictor`.
- **`predictor-ops` confirmado decorativo** neste repositório (achado repassado à auditoria de `predictor-ops`).
- **Contradição documentada**: HANDOFF afirma que um disclaimer obsoleto foi removido dos relatórios; a leitura direta do código e dos artefatos mostra que o texto **continua lá**.
- Impostos sobre ganho de capital **nunca modelados** em nenhum backtest.
- **Recomendação: CONGELAR** o domínio de fatores (já encerrado, sem edge); **MANTER+TESTAR** a linha RJ, condicionada à primeira rodada com dado real e à resolução (ou aceitação explícita) de dois bloqueadores auto-declarados (censura por empresa morta no código; poder estatístico estruturalmente baixo).

---

## PARTE X — AUDITORIA TRANSVERSAL

### As 12 perguntas obrigatórias (seção 44)

**1. O que Cripto aprendeu que Stocks deveria usar?** A disciplina de medir formalmente o **poder do próprio gate estatístico antes de aceitar um resultado nulo como definitivo** (cripto B12: n=30 detecta rho=0,2 em só 14,7% das vezes). Stocks já aplica algo equivalente na linha RJ (`rj_power.py`) — nesse ponto específico, a prática já se propagou. O que ainda não se propagou: a arquitetura bitemporal explícita (DPL) do cripto é mais rigorosa que o tratamento de point-in-time em stocks/fatores (que depende do parser COTAHIST + execução D+1, correto mas menos instrumentado que a DPL).

**2. O que Brasileirão aprendeu sobre probabilidades/calibração que pode ajudar outros domínios?** A distinção cuidadosa entre "calibração marginal" e "capacidade de ordenação/argmax" (o modelo nunca escolhe empate por argmax em 6 temporadas, mas isso não implica P(empate)≈0) é uma lição estatística fina que nenhum outro domínio do ecossistema documenta com esse nível de cuidado. Também a prática de comparar contra climatologia prequential congelada por bloco de data, e o cuidado (só parcial) de rotular fontes de "mercado" como `DIAGNOSTIC_ONLY` quando não são executáveis.

**3. Quais falhas aparecem nos três predictors?** (a) Nenhum recalculou nenhum número primário nesta auditoria por ausência de dados brutos no ambiente — todos dependem de uma máquina/banco fora do Git; (b) todos os três têm pelo menos um ponto de multiple-testing subestimado (kelly-sweep/threshold-grid em cripto; ~80 configs em brasileirão; UNKNOWN RESEARCH SEARCH SPACE reconhecido nos três); (c) nenhum modela fricções específicas do seu domínio de forma completa (cripto não calibra microestrutura contra execução real; brasileirão usa odds majoritariamente pós-jogo nos grandes benchmarks; stocks nunca modela impostos).

**4. Quais componentes Core são realmente universais?** `measurement.trials`/`contracts.registry` (TrialRegistry), `kernel.obs` (telemetria), `measurement.bootstrap`, `measurement.stats` (PSR/Sharpe/max_drawdown), `testing.harness` (power attestation) — usados pelos 3 domínios de forma confirmada. `measurement.metrics` (brier/log_loss/rps) é universal para os 2 domínios com previsão probabilística categórica (brasileirão, e parcialmente stocks). `data.contracts` é usado por 2 de 3.

**5. Quais componentes Ops são realmente universais?** Nenhum é usado pelos 3 de forma equivalente. `runner`/`redaction`/`runtime` local são usados por 2 de 3 (cripto crítico, brasileirão parcial/em recuo); nenhum é usado por stocks.

**6. Ecosystem é necessário ou apenas conveniente?** Nem necessário nem, hoje, nem sequer confiavelmente conveniente — é a única peça de infraestrutura cuja função central (descoberta multi-domínio) falhou quando testada de ponta a ponta nesta auditoria. Nenhum domínio depende dele para operar.

**7. Existem três soluções para o mesmo problema?** Sim, pelo menos duas vezes: (a) redação de segredos existe tanto em `predictor_ops.redaction` quanto potencialmente reimplementada localmente onde a lib não é usada (stocks); (b) modelos de custo de transação em cripto têm dois caminhos não totalmente unificados (`v3/costs.py` de bps fixo vs. `trading/microstructure.py` de simulação de book), reconciliados por um dispatcher, mas ainda assim uma duplicação parcial.

**8. O ecossistema está pagando um imposto de abstração?** Sim, claramente em `ecosystem-predictor` (Postgres/Redis/S3/scheduler provisionados sem uso) e parcialmente em `core-predictor` (~22-24% dormant) e `predictor-ops` (hash-chain, backend Redis, scripts Windows vencidos). O imposto é menor em `core-predictor` (que tem o núcleo essencial claramente proporcional ao valor) do que em `ecosystem-predictor` (onde a proporção do que é decorativo é maior que o que é usado).

**9. Quanto da complexidade atual existe para administrar complexidade anterior?** Substancial. O padrão de "vendoring → wheel" em `core-predictor` deixou lixo residual (`stocks-predictor/vendor/predictor_core` obsoleto). O padrão "tools/ workspace-bound → predictor_ops instalável" deixou 5 scripts PowerShell "transitional" com prazo de remoção vencido. O padrão "5 domínios → 3" deixou ~24% do core dormant. Isso é evidência direta e recorrente de complexidade que existe para administrar a consolidação de uma complexidade anterior, não para servir a necessidade atual.

**10. Houve deslocamento de esforço de pesquisa econômica para engenharia de plataforma?** Sim, com o exemplo mais nítido sendo a camada `trading/` do cripto-predictor, construída antes de qualquer hipótese validar edge — engenharia sofisticada (99% de cobertura) sobre um sinal que ainda não existe. Em menor grau, o próprio `ecosystem-predictor` nasceu como aparato de governança e só depois ganhou código de aplicação, na ausência de qualquer domínio que precisasse dele.

**11. Existe algo que foi generalizado cedo demais?** Sim: `core-predictor/contracts/economic.py` (442 linhas, o maior módulo do repositório, lançado há 2 semanas, zero consumidores); o schema econômico v2 completo de `predictor-ops` (kill-switch, `EconomicJobKey`, `RiskSnapshot`) construído para um cenário de execução de capital real que hoje só existe, na melhor hipótese, em 1 domínio (cripto) e mesmo lá sem capital autorizado; e o gateway HTTP de `ecosystem-predictor`, testado só em isolamento, sem nenhum consumidor real.

**12. Existem conhecimentos negativos valiosos que deveriam ser compartilhados?** Sim, e isto é talvez o ativo mais subestimado do ecossistema: (a) "modelos de probabilidade pura contra mercados líquidos e razoavelmente eficientes tendem a não vencer o mercado sem informação nova" (brasileirão, e por padrão similar em cripto H1-H5); (b) "resultados retrospectivos 'bonitos' que sobrevivem a uma busca ampla sem correção de multiplicidade formal devem ser tratados como prováveis artefatos até prova em contrário" (kelly-sweep cripto, OU2.5/2025 brasileirão); (c) "medir o poder do próprio teste antes de aceitar um nulo" (cripto B12, stocks rj_power.py) deveria ser prática obrigatória, documentada uma vez em `core-predictor`, em vez de reimplementada/redescoberta em cada domínio.

### Complexidade cresceu mais rápido que a evidência econômica?

**Teste da hipótese, tentando falseá-la (seção 45), não aceitando-a por padrão:**

Evidência a favor: ~980 commits/2,5 meses produziram infraestrutura substancial (6 repositórios, ~15.000+ linhas de código de produção somadas) e **zero** hipóteses aprovadas para capital, zero lucro líquido realizado, zero evidência prospectiva madura em qualquer domínio. `ecosystem-predictor` provisiona infraestrutura pesada (Postgres/Redis/S3) sem uso demonstrado. `core-predictor` tem ~24% de código sem consumidor. `predictor-ops` tem componentes inteiros (hash-chain, Redis) sem consumidor confirmado em produção.

Evidência contra a versão mais forte da hipótese (i.e., razões para não simplesmente concluir "tudo foi desperdiçado"): a infraestrutura essencial de `core-predictor` (~68-77%) tem uso real e correto, matematicamente verificado; a disciplina de pesquisa (pré-registro, DSR/PBO, walk-forward, medição de poder) é **evidência científica genuína**, mesmo sem lucro — reduzir incerteza sobre "isso não funciona" tem valor, só não é o mesmo tipo de valor que lucro. Os "fracassos" nos 3 domínios são, na maioria, **resultados negativos válidos**, não falhas de processo.

**Veredito**: a hipótese sobrevive parcialmente. É verdade que a *infraestrutura compartilhada e de governança* (ecosystem, partes de core e ops) cresceu além do que a evidência econômica hoje justifica. Não é verdade, com a mesma força, para a *pesquisa em si* nos 3 domínios — lá, o volume de código reflete majoritariamente tentativas de hipótese genuínas (mesmo que mal sucedidas), não gold-plating. A exceção clara dentro dos domínios é a camada `trading/` do cripto, que é gold-plating de execução construído antes do sinal.

---

## PARTE XI — EVIDENCE LEDGER

Ver arquivo separado `PREDICTORS_EVIDENCE_LEDGER.csv` (formato tabular, todas as claims de alto valor decisório, colunas ID/Projeto/Claim/Fonte/Verificação/Nível/Resultado/Status/Confiança).

## PARTE XII — CONTRADICTION MATRIX

Ver arquivo separado `PREDICTORS_CONTRADICTIONS.csv`.

## PARTE XIII — HIPÓTESES FALSIFICADAS

Ver arquivo separado `PREDICTORS_FALSIFIED_HYPOTHESES.md`.

## PARTE XIV — HIPÓTESES ABERTAS

Ver arquivo separado `PREDICTORS_OPEN_HYPOTHESES.md`.

## PARTE XV — ATIVOS REUTILIZÁVEIS

Ver arquivo separado `PREDICTORS_ASSET_INVENTORY.md`.

## PARTE XVI — UTILIZAÇÃO DA INFRAESTRUTURA

Ver arquivo separado `PREDICTORS_INFRASTRUCTURE_USAGE.csv`.

---

## PARTE XVII — DÍVIDA ESTRATÉGICA

Não apenas dívida técnica — dívida de **decisão não fechada**:

- **Hipóteses nunca concluídas**: H6/H7 (cripto, sem amostra suficiente); H14/H15/A1 (brasileirão, pré-registradas sem coleta); RJ (stocks, M0 absoluto).
- **Experimentos sem fechamento formal**: `run_threshold_grid` do cripto (commit #63, "nenhuma combinação validada contra dado real nesta revisão"); o funil de ~80 configurações do OU2.5 (brasileirão), nunca formalmente corrigido para multiplicidade como um todo.
- **Documentos conflitantes não resolvidos**: docstring do registry de `ecosystem-predictor` (grupo de entry point errado); `.env.example` referenciando domínios fora de escopo; HANDOFF de `stocks-predictor` afirmando uma correção que o código não reflete.
- **Infraestrutura sem usuário**: `ecosystem-predictor` gateway HTTP, cache Redis, object storage, scheduler; `predictor-ops` hash-chain de auditoria, backend Redis; `core-predictor` ~9 módulos dormant.
- **Resultados sem reprodução**: todos os números primários dos 3 domínios econômicos (dependem de dados fora do Git).
- **Datasets sem proveniência auditável por terceiros**: `matches.db` (brasileirão), `stocks.db`/COTAHIST bruto (stocks), dados de mercado cripto — todos vivem só na máquina do dono.
- **Abstrações sem necessidade demonstrada**: `contracts/economic.py` (core), schema econômico v2 completo de `predictor-ops` (fora de cripto).
- **Pipelines sem valor demonstrado**: gateway HTTP do ecosystem (nunca operado com tráfego real observável).
- **Dependências históricas desnecessárias**: `vendor/predictor_core` obsoleto em stocks; scripts PowerShell "transitional" vencidos em ops.

---

## PARTE XVIII — COMPLEXIDADE VS EVIDÊNCIA (timeline)

| Data aprox. | Evento de infraestrutura/complexidade | Evento de evidência econômica |
|---|---|---|
| 2026-06-12 | Início `stocks-predictor` (M0, fatores) | — |
| 2026-06-16 | Início `cripto-predictor` e `core-predictor` (v0.4.0) | — |
| 2026-07-03 | `core-predictor` v1.0.0 — "3/3 domínios consomem o core" | — |
| 2026-07-04/12 | — | H1 stocks (momentum) testada e **refutada** |
| 2026-07-10 | Início `brasileirao-predictor` | — |
| 2026-07-12 | — | Pausa estratégica declarada em stocks ("prioridade onde já há sinal") |
| 2026-07-15 | Início `predictor-ops` (reescrita de `tools/`) | — |
| 2026-07-17 | Início `ecosystem-predictor` (documentação de governança) | — |
| 2026-07-26 | — | **Veredito ecossistema: 42 hipóteses, zero aprovadas para capital** |
| 2026-08-02 | `ecosystem-predictor` ganha primeiro código de aplicação (Fase 5) | — |
| 2026-08-14 | **Cripto constrói camada `trading/` completa** (override de governança) | H1-H3 cripto já invalidadas; nenhum GO líquido |
| 2026-08-17/24 | 4ª redefinição de escopo canônico (Charter, 6 repos/3 domínios) | H4/H5 cripto refutadas (H5: correlação negativa significativa) |
| 2026-08-22/26 | — | Brasileirão: pivô de probabilidade pura para arbitragem estrutural; auditoria matemática interna encontra 4+ bugs |
| 2026-08-23/24 | `ecosystem-predictor` Charter final; último commit pede auditoria "do zero" | — |
| 2026-08-24/28 | Stocks: 3 rodadas de auditoria interna de código; pivô para linha RJ | Stocks: H2/H4/H5/H6/H8 todas refutadas |
| 2026-08-27/28 | Cripto: trend-following/SMA200 testados e reprovados no gate | Brasileirão: automação desligada por pedido do usuário |
| 2026-08-31 | Congelamento da auditoria | **Zero hipóteses aprovadas para capital em nenhum dos 3 domínios, confirmado ao vivo** |

**Leitura**: os picos de investimento em infraestrutura/engenharia (core v1.0, ecosystem Fase 5, cripto trading/) não coincidem, em nenhum caso observado, com picos de evidência econômica positiva — coincidem, na maior parte das vezes, com o período imediatamente **após** uma hipótese ter sido refutada, sugerindo um padrão de redirecionamento de esforço de "a hipótese não funcionou" para "vamos construir mais infraestrutura", em vez de "vamos testar a próxima hipótese com dado real mais rápido e mais barato".

---

## PARTE XIX — SCORECARD

Ver arquivo separado `PREDICTORS_PROJECT_SCORECARD.csv`. Nota metodológica: por instrução expressa da tarefa (seção 52), notas 0-10 só foram atribuídas onde há evidência suficiente; a maioria das células de "edge econômico" e "evidência prospectiva" está marcada **N/A** ou **0 (confiança alta)** porque a própria auditoria encontrou ausência ativa de edge, não apenas ausência de teste.

---

## PARTE XX — DECISÕES (uma por projeto)

### `ecosystem-predictor` — **REDUZIR**
Manter `contracts` (vocabulário Pydantic, ~70 linhas, validado contra os 3 domínios reais) e `registry` (mecanismo de descoberta), **condicionado a corrigir a colisão de módulos `src`/`scripts` e adicionar um teste de CI que instale os 3 domínios reais juntos** — sem isso, a alegação central do repositório permanece falsa. Remover ou congelar `cache`/`storage`/`db`/`scheduler` do `compose.yaml` e `Settings` até haver consumidor real de cada um. Não é ENCERRAR (o vocabulário de contratos tem uso real confirmado); não é MANTER como está (infraestrutura pesada sem uso e bug central não corrigido).

### `core-predictor` — **MANTER + REDUZIR**
Manter o núcleo essencial (`trials`/`registry`, `obs`, `bootstrap`, `stats`, `metrics`, `data.contracts`, `net`, `harness`) — matemática verificada, uso real amplo, substituir por implementações locais reintroduziria um risco já materializado (drift de governança "dentro de casa", CHANGELOG v1.1.0). Podar/congelar os módulos dormant (~24%: ledger, rating, ordinal, calibration, nullref, asof, stress, testing.coverage, contracts.economic). Ação de curto prazo: cortar tag `v2.3.1`/`v2.4.0` com os 4 commits pendentes ou decidir formalmente que não é urgente.

### `predictor-ops` — **MANTER + REDUZIR**
Manter o núcleo (`runner`, `redaction`, `runtime` local, `provenance`) — uso real crítico em cripto. Podar hash-chain de auditoria, backend Redis (sem plano concreto), `compat/vendor_audit.py`. Cumprir ou revisar formalmente o prazo de remoção vencido dos scripts PowerShell "transitional". Resolver a dependência decorativa em `stocks-predictor` (remover ou integrar de fato).

### `cripto-predictor` — **MANTER + TESTAR (escopo reduzido), NÃO ESCALAR**
Preservar a infraestrutura científica (DPL, DSR/PBO, controle positivo, medição de poder) — valor estratégico real. **Congelar novo investimento em `trading/`** até que H6 ou H7 (ou hipótese nova) produza um GO líquido de custos. Redirecionar esforço para levar H6 a n≈250 (não apenas n≥30) e ativar H7 de fato (CPI/PPI, DXYProvider ponta a ponta). Fechar a lacuna de contagem de tentativas do `run_threshold_grid` antes de rodá-lo contra dado real.

### `brasileirao-predictor` — **CONGELAR (probabilidade pura) + MANTER+TESTAR (A1) + MANTER (plataforma)**
Congelar novas variações do motor Elo+NB+Dixon-Coles até informação PIT genuinamente nova (escalação, lesões, técnico) existir — não mais variações de hiperparâmetro sobre os mesmos dados históricos. Manter+testar a arbitragem estrutural A1 apenas se o operador retomar explicitamente com chave rotacionada e coleta real de 7 dias. Não reabrir 2025/2026 como holdout — já contaminados por decisão documentada do próprio usuário. Preservar a infraestrutura de governança (ledger, `PrequentialEvaluator`, `ci_check.py`) como ativo de plataforma reutilizável.

### `stocks-predictor` — **CONGELAR (fatores) + MANTER+TESTAR (RJ)**
O domínio de fatores não precisa de nenhuma ação além de permanecer congelado — 6 hipóteses testadas com rigor real, todas honestamente encerradas. A linha RJ merece a próxima etapa (dado real), mas com expectativa calibrada para baixo (poder estatístico estruturalmente insuficiente) e dois bloqueadores auto-declarados resolvidos antes da primeira leitura: censura por empresa (`censoring_horizon_trading_days`, hoje morta no código) e reconhecimento explícito de que mesmo um resultado "significativo" na primeira rodada real precisa de ceticismo extra dado N pequeno.

---

## PARTE XXI — DECISÃO DO PORTFÓLIO

**Se tivéssemos que reduzir 6 projetos para 3:** `core-predictor` (único ativo de infraestrutura com valor real e verificado independentemente) + `cripto-predictor` (domínio com a disciplina científica mais rigorosa e hipóteses ainda vivas com poder insuficiente, não refutadas) + `brasileirao-predictor` (domínio com a evidência mais completa e honesta, incluindo evidência ativa contra a tese de probabilidade pura, mas com um caminho estrutural ainda não testado). `predictor-ops` seria absorvido/reduzido a uma dependência de `cripto-predictor` (onde tem uso real); `ecosystem-predictor` e `stocks-predictor` sairiam desta lista de 3 — não porque `stocks-predictor` careça de rigor (tem), mas porque, dos 3 domínios, é o que está mais distante de qualquer evidência (linha ativa em M0 absoluto) e tem o histórico de resultado mais uniformemente negativo (6/6 hipóteses fechadas refutadas).

**Se tivéssemos que reduzir para 2:** `core-predictor` + **um** domínio econômico. Entre cripto e brasileirão: brasileirão tem evidência mais completa e um caminho estrutural (A1) genuinamente diferente do "vencer o mercado em probabilidade" (que já falhou); cripto tem infraestrutura científica mais madura (DPL, medição de poder) mas nenhum caminho ainda não testado tão claramente distinto dos já refutados. **Levemente a favor de brasileirão pelo caminho A1**, mas esta é a decisão de menor confiança desta síntese — poderia razoavelmente inverter com mais informação sobre o custo de reativar a coleta A1 vs. o custo de levar H6 a n≈250.

**Se tivéssemos que manter apenas um ativo de todo o ecossistema:** `core-predictor` — não por ser o mais valioso economicamente (nenhum é, ainda), mas por ser o único com valor **verificado independentemente**, reutilizável em qualquer domínio futuro (inclusive fora de trading/apostas), e que preserva o ativo mais raro do ecossistema (a governança anti-p-hacking: TrialRegistry N+1, power attestation).

**Qual projeto merece mais atenção agora?** `cripto-predictor` — é o único com hipóteses vivas (H6/H7) que estão a uma decisão operacional simples (continuar coletando até n≈250) de produzir uma resposta definitiva, em vez de mais pesquisa especulativa.

**Qual projeto mais provavelmente consome esforço sem retorno, se não for redirecionado?** `ecosystem-predictor` — o padrão comportamental (4 redefinições de escopo, 6+ fechamentos não convergentes, auditoria "do zero" auto-solicitada) é o único, dos 6, com evidência direta de que o próprio ciclo de trabalho não está convergindo.

**Qual infraestrutura deve permanecer?** O núcleo de `core-predictor` (~68-77% hoje usado) e o núcleo de `predictor-ops` (`runner`/`redaction`/`runtime` local).

**Qual infraestrutura deve ser simplificada?** `ecosystem-predictor` (Postgres/Redis/S3/scheduler/gateway sem uso), os módulos dormant de `core-predictor` (~24%), e os componentes sem consumidor de `predictor-ops` (hash-chain, Redis, scripts Windows vencidos).

**Onde existe maior opcionalidade?** Em `core-predictor` — por ser domain-agnostic e ter uso comprovado, é o ativo mais barato de re-direcionar para um domínio futuro (dentro ou fora de trading/apostas).

**Onde existe maior evidência econômica?** Em nenhum lugar, no sentido positivo — a maior *evidência econômica* de todo o ecossistema é, paradoxalmente, a evidência **negativa e bem estabelecida** de que brasileirão perde do mercado de forma consistente, e de que cripto H1-H5 não têm edge líquido. Isso tem valor real (elimina caminhos), mas não é lucro.

**Onde existe maior ilusão de progresso?** Em `ecosystem-predictor` — volume de documentação (7-8:1 sobre código) e ciclos de "fechamento final" recorrentes sem convergência real são o padrão mais claro de atividade que se parece com progresso sem ser.

**Onde existe maior valor científico mesmo sem lucro?** Em `cripto-predictor` — a combinação de pré-registro, DSR/PBO, controle positivo e medição formal de poder estatístico é uma prática de pesquisa que, isolada e generalizada (já parcialmente vive em `core-predictor`), tem valor que sobrevive independentemente de cripto especificamente gerar lucro.

**Qual é a melhor alocação marginal das próximas horas/dinheiro?** Nesta ordem: (1) corrigir e testar o bug de colisão de `ecosystem-predictor` OU descontinuar essa parte — decisão barata, alto valor de informação; (2) continuar a coleta de H6 (cripto) até poder adequado — já em andamento, só precisa de tempo/paciência, não de novo código; (3) decidir explicitamente (não por omissão) se a arbitragem A1 do brasileirão será retomada — hoje está numa zona cinzenta cara de manter (documentação, pré-registro) sem gerar dado.

---

## PARTE XXII — CENÁRIOS ESTRATÉGICOS

### Cenário A — Continuar tentando estratégias financeiras nos 3 domínios como estão
**Upside**: se qualquer uma das hipóteses vivas (H6/H7 cripto, A1 brasileirão, RJ stocks) validar, o ecossistema já tem infraestrutura de execução pronta (`trading/`, `predictor-ops`). **Downside**: repete o padrão observado de 2,5 meses de esforço por resultado majoritariamente negativo; custo de oportunidade alto se a probabilidade real de sucesso for baixa (como a evidência atual sugere). **Custo**: alto (múltiplos domínios em paralelo). **Prazo**: meses a indefinido. **Risco**: médio-alto de repetir o pre-mortem (Parte XXV). **Evidência necessária para justificar**: nenhuma nova — é a continuação do status quo. **Reversibilidade**: alta (nada de capital real em jogo). **Hipótese principal**: "mais dados/mais tempo eventualmente encontram edge". **Risco de autoengano**: alto — é fácil confundir "ainda não testamos o suficiente" com "vale a pena continuar indefinidamente" sem um critério de parada explícito.

### Cenário B — Reduzir estratégias financeiras e monetizar/consolidar infraestrutura
**Upside**: `core-predictor` (governança de pesquisa quant, point-in-time, trial registry) tem um diferencial real não replicado facilmente no mercado geral; poderia, em tese, interessar a pesquisadores quant independentes fora do ecossistema. **Downside**: **HYPOTHESIS não validada** — não há nenhuma evidência de demanda externa nos 6 repositórios; validar exigiria esforço de go-to-market que o ecossistema (bus factor=1) pode não ter capacidade de sustentar junto com pesquisa. **Custo**: médio (documentação, empacotamento, possivelmente remoção de acoplamentos específicos do domínio). **Prazo**: meses. **Risco**: alto de investir em GTM sem demanda comprovada. **Evidência necessária**: pelo menos 1 conversa/validação com um usuário externo real antes de qualquer investimento de engenharia adicional. **Reversibilidade**: média. **Principal risco de autoengano**: assumir que "a tecnologia é boa" implica "há mercado" — a auditoria não encontrou nenhuma evidência de demanda.

### Cenário C — Manter apenas pesquisa científica mínima
**Upside**: preserva o valor de aprendizado (hipóteses eliminadas com credibilidade, infraestrutura reaproveitável) a custo mínimo; sem pressão de "provar lucro rápido", a disciplina de pré-registro/DSR pode continuar a ser aplicada com paciência (ex.: H6 até n≈250). **Downside**: sem foco de monetização, o ecossistema pode continuar a gerar aprendizado negativo indefinidamente sem nunca "encerrar" formalmente nenhum domínio. **Custo**: baixo. **Prazo**: indefinido, de baixa intensidade. **Risco**: baixo financeiramente, médio em termos de tempo de vida pessoal investido sem retorno. **Evidência necessária**: nenhuma adicional para começar — é reduzir escopo, não expandir. **Reversibilidade**: alta. **Hipótese principal**: "o valor está em aprender e manter opcionalidade, não em lucro imediato". **Risco de autoengano**: usar "é ciência" como justificativa permanente para nunca fechar um domínio, mesmo quando a evidência já é suficiente para uma decisão (ex.: brasileirão-probabilidade-pura).

### Cenário D — Encerrar grande parte do ecossistema, preservar só ativos reaproveitáveis
**Upside**: libera tempo/energia; reconhece que 3 domínios com 0 hipóteses aprovadas para capital em 2,5 meses é evidência real, não ruído; preserva o que já foi comprovadamente valioso (`core-predictor`, cultura de pré-registro) sem carregar o peso morto de `ecosystem-predictor` e das partes não usadas de `predictor-ops`. **Downside**: hipóteses ainda vivas e não refutadas (H6/H7 cripto, A1 brasileirão, RJ stocks) nunca receberiam sua chance completa — risco de encerrar prematuramente algo que estava a pouco esforço adicional de uma resposta definitiva. **Custo**: baixo (é uma redução). **Prazo**: imediato. **Risco**: baixo financeiro, médio de arrependimento científico (fechar algo perto do ponto de decisão). **Evidência necessária para escolher isto sobre C**: nenhuma adicional — é uma decisão de apetite a risco/tempo, não de evidência faltante. **Reversibilidade**: baixa para o conhecimento tácito (se a pessoa/tempo se dispersar, é caro reconstituir o contexto), média para o código (está no Git). **Principal risco de autoengano**: usar "não deu certo até agora" para justificar encerrar hipóteses que estão estruturalmente a um passo pequeno e barato (H6, RJ) de uma resposta, confundindo "caro no agregado" com "caro no próximo passo marginal".

**Recomendação desta auditoria entre os 4 cenários**: um **híbrido C+D**, não A nem B em sua forma pura — congelar/encerrar os caminhos já refutados (probabilidade pura do Brasileirão, fatores do Stocks, trading/ do cripto sem sinal), manter aberto e barato o que está perto de uma resposta (H6/H7 cripto, RJ stocks — condicionado aos bloqueadores já identificados, A1 brasileirão condicionado à retomada operacional real), e tratar B (monetização de infraestrutura) como uma hipótese a validar com esforço mínimo (uma conversa real com um usuário potencial), não como uma decisão de portfólio já tomada.

---

## PARTE XXIII — EXPERIMENTOS RECOMENDADOS

Ver arquivo separado `PREDICTORS_EXPERIMENT_BACKLOG.md`, ordenado por valor da informação / custo / tempo.

## PARTE XXIV — KILL CRITERIA

Ver arquivo separado `PREDICTORS_KILL_CRITERIA.md`.

---

## PARTE XXV — PRE-MORTEM

*"Daqui a 12 meses, ainda sem lucro e com ainda mais código — o que provavelmente aconteceu?"*

1. **H6 nunca chegou a n≈250** porque a coleta prospectiva depende de um processo manual (commit à mão do `h6_status.json`) que foi deprioritizado assim que outra distração apareceu. *Prevenção*: automatizar o commit do status (ainda que não o dado bruto), e tratar "sem atualização por >14 dias" como sinal de alerta automático, não silencioso.
2. **`ecosystem-predictor` recebeu um "fechamento final" nº 7** sem que o bug de colisão de módulos fosse corrigido, porque a auditoria "do zero" pedida no último commit focou em documentação, não em reproduzir o registry com os 3 domínios reais instalados juntos. *Prevenção*: qualquer nova auditoria deste repositório deve começar pela reprodução técnica (como esta auditoria fez), não pela releitura de documentos.
3. **A1 (brasileirão) nunca foi retomado** porque rotacionar a chave de API e monitorar 7 dias de coleta manual é um trabalho tedioso e fácil de adiar indefinidamente sem prazo. *Prevenção*: definir uma data-limite explícita; se não retomado até lá, mover formalmente para ENCERRADO em vez de deixar em limbo.
4. **A linha RJ (stocks) coletou dado real mas nunca corrigiu a censura por empresa morta no código**, produzindo um "resultado" enviesado que foi tratado como definitivo sem o ceticismo que o próprio código já alertava ser necessário. *Prevenção*: bloquear (não apenas alertar) qualquer veredito de RJ até `censoring_horizon_trading_days` estar de fato implementado.
5. **`core-predictor` acumulou mais ~15-20% de código dormant** porque cada domínio continuou a "generalizar preventivamente" no core em vez de esperar um segundo consumidor real. *Prevenção*: regra explícita — nenhum módulo novo em `core-predictor` sem pelo menos 1 consumidor real já identificado no momento do merge.
6. **O bus factor permaneceu 1** em todos os 6 repositórios, e um período de indisponibilidade do único mantenedor causou meses de estagnação sem que ninguém percebesse até esta auditoria (ou a próxima) apontar. *Prevenção*: documentar explicitamente esse risco como aceito, ou buscar um segundo colaborador mesmo que parcial.
7. **Nova infraestrutura foi construída para o "próximo domínio" antes de qualquer domínio atual gerar lucro**, repetindo o padrão de `contracts/economic.py` e do schema v2 de `predictor-ops`. *Prevenção*: aplicar a mesma pergunta desta auditoria ("o próximo dólar/hora aqui tem valor esperado maior que a alternativa?") antes de qualquer novo módulo de infraestrutura.
8. **Resultados positivos isolados e não corrigidos por multiplicidade (tipo OU2.5/2025) foram, sob pressão de tempo, promovidos a "quase-GO" apesar do próprio time já os ter rotulado como não executáveis.** *Prevenção*: a trava não pode ser só documental — o código de decisão de capital deveria recusar programaticamente qualquer resultado sem odds PIT nomeadas, não confiar em disciplina humana de não usar o número.
9. **A auditoria "do zero" pedida no último commit de `ecosystem-predictor` se tornou, ela mesma, mais um ciclo de documentação sem reprodução técnica**, repetindo o padrão dos 6 "fechamentos" anteriores. *Prevenção*: qualquer prompt de auditoria futura deveria exigir explicitamente reprodução executável (como este documento fez) como critério de aceite, não permitir que "ler documentos" seja suficiente.
10. **O ecossistema encolheu mais uma vez** (de 6 para 4-5 repositórios) sem que a decisão fosse formalmente registrada como tal — simplesmente por abandono silencioso, como aparentemente aconteceu com `lol-predictor`/`cs-predictor`/`f1-predictor`. *Prevenção*: qualquer descontinuação de domínio deveria gerar um documento formal de encerramento (com razão e ativos preservados), não apenas silêncio no histórico de commits.

---

## PARTE XXVI — RED TEAM

Atacando as próprias conclusões desta síntese:

**Contra "REDUZIR ecosystem-predictor"**: o melhor argumento contrário é que o bug de colisão é uma correção **barata** (renomear pacotes), e talvez o veredito devesse ser "MANTER+TESTAR condicionado à correção" em vez de "REDUZIR" — a diferença semântica entre as duas pode ser pequena na prática, mas "REDUZIR" carrega conotação mais negativa do que a evidência técnica pura (um bug corrigível) sozinha talvez justifique. *Ajuste*: mantenho REDUZIR porque o problema não é só o bug — é o padrão comportamental (6 fechamentos não convergentes, infraestrutura pesada sem uso, doc:código 7-8:1) que é independente do bug específico e não desaparece com uma correção pontual.

**Contra "zero edge em todos os domínios fechados"**: pode-se argumentar que estou **subestimando ativos estratégicos** ao tratar H12 do Brasileirão (ensemble xG, RPS melhora com IC95 que não cruza zero) como "apenas qualidade de modelo, não edge econômico" — talvez essa distinção seja excessivamente rígida, e uma melhora de calibração real tenha valor comercial próprio (ex.: para um produto de "melhores probabilidades", não de apostas). *Ajuste*: aceito parcialmente — adicionei isso como um ativo residual potencial na Parte XV, mas mantenho a separação de estágios da cadeia conceitual (capacidade preditiva ≠ edge econômico) como corretamente aplicada aqui, porque é exatamente a distinção que a tarefa pediu para não confundir.

**Contra "MANTER core-predictor"**: onde posso estar **superestimando qualidade de engenharia**? A verificação matemática que fiz (brier/log_loss/rps/max_drawdown) cobre só 4 de ~28 submódulos — é possível que outros módulos "ESSENCIAIS" (ex.: `kernel.net`, com 42% de cobertura) tenham bugs não descobertos porque não foram verificados com o mesmo rigor. *Ajuste*: registrado explicitamente na Parte V/VI (a cobertura baixa de `kernel.net` já está marcada como risco); não mudo a recomendação, mas reduzo levemente a confiança implícita em "nenhum erro matemático encontrado" para "nenhum erro encontrado nos 6 pontos verificados, cobertura parcial do restante".

**Contra "não há evidência de demanda para monetização de infraestrutura" (Cenário B)**: estou aplicando um padrão talvez **desigual** — exijo evidência de demanda externa para infraestrutura, mas aceito "pode gerar lucro futuro" como razão suficiente para não encerrar hipóteses de pesquisa ainda vivas (H6/H7). Isso é uma inconsistência potencial de padrão entre projetos. *Ajuste*: reconheço a assimetria — a diferença defensável é que H6/H7 já têm *protocolo* e *custo marginal baixo* para resposta (só precisam de mais tempo de coleta, não de novo investimento), enquanto a hipótese de monetização de infraestrutura exigiria esforço novo (GTM) sem nenhum protocolo de validação já em andamento. Mantenho a recomendação, mas explicito esse critério de desempate aqui.

**Onde a falta de dados me impede de concluir com mais confiança?** Em todos os 3 domínios, a ausência de dados brutos nesta auditoria significa que **toda a análise de robustez, sensibilidade e captura de edge depende de confiar nos números já processados pelo próprio projeto**. Isso é uma limitação genuína e reconhecida — o nível de confiança desta síntese é alto para "o processo é metodologicamente correto e os vereditos negativos são internamente consistentes", e médio (não alto) para "os números exatos citados são precisos", porque não pude recalculá-los com dado bruto em nenhum dos 3 domínios.

**Onde a documentação pode estar me enganando?** O padrão repetido de documentação desatualizada (achado #9 da Parte I) significa que qualquer claim positivo que EU não tenha verificado por execução direta (marcado L1-L2 nos relatórios individuais) deveria ser tratado com o mesmo ceticismo que apliquei aos claims negativos — não apliquei um padrão duplo aqui deliberadamente, mas a assimetria natural é que é mais fácil verificar "o teste passa" (positivo, fácil) do que "o número X está correto" (precisa do dado bruto, impossível aqui) — então claims positivos sobre correção matemática tendem a estar em nível de confiança mais alto (L5-L6, testados) do que claims positivos sobre resultado econômico (L1-L2, documental), e isso é o padrão correto a manter, não um viés a corrigir.

---

## PARTE XXVII — ROADMAP SEM DESENVOLVIMENTO PREMATURO

### AGORA (somente auditoria, medição e validação)
- Corrigir e testar (com CI real) a colisão de módulos em `ecosystem-predictor`, OU decidir formalmente descontinuar o registry multi-domínio.
- Cortar uma tag `v2.3.1`/`v2.4.0` de `core-predictor` com os 4 commits pendentes, ou decidir formalmente adiar.
- Decidir explicitamente (não por omissão) se a arbitragem A1 do brasileirão será retomada nas próximas semanas — com data-limite.
- Decidir explicitamente se `predictor-ops` será integrado de fato em `stocks-predictor` ou removido de lá.

### PRÓXIMOS EXPERIMENTOS (só depois de preencher as lacunas críticas acima)
- Continuar a coleta prospectiva de H6 (cripto) até n≈250, sem novo código, só paciência e disciplina de commit do status.
- Se A1 for retomado: 7 dias de coleta real com chave rotacionada, seguido de auditoria manual de 50 eventos, conforme o próprio protocolo já especifica.
- Se a linha RJ (stocks) avançar: primeira rodada real, condicionada a corrigir a censura por empresa morta no código.
- Validar a hipótese de monetização de infraestrutura (`core-predictor`) com pelo menos 1 conversa real com um usuário potencial externo — sem escrever nenhum código de produto novo antes disso.

### DESENVOLVIMENTO PERMITIDO (só quando justificado por evidência)
- Qualquer correção pontual de bug já identificado nesta auditoria (colisão de módulos, censura RJ, sincronização de tag do core).
- Poda de código dormant já identificado (não é "desenvolvimento novo", é redução).

### DESENVOLVIMENTO PROIBIDO POR ENQUANTO (tudo que aumente complexidade sem reduzir incerteza relevante)
- Qualquer nova feature em `trading/` (cripto) antes de H6/H7 produzirem um GO líquido de custos.
- Qualquer novo módulo em `core-predictor` sem um consumidor real já identificado no momento do merge.
- Qualquer investimento no gateway HTTP, cache, storage ou scheduler de `ecosystem-predictor` antes de haver um consumidor real demonstrado.
- Qualquer expansão do schema econômico v2 de `predictor-ops` para novos domínios antes de cripto (o único domínio que hoje o usa parcialmente) ter capital autorizado.
- Qualquer novo domínio econômico (7º repositório) antes de pelo menos um dos 3 domínios atuais produzir uma resposta definitiva (GO ou encerramento formal) para suas hipóteses vivas.

---

*Fim do relatório master. Ver arquivos anexos para as tabelas completas (Evidence Ledger, Contradictions, Scorecard, Infrastructure Usage) e documentos de apoio (Open/Falsified Hypotheses, Asset Inventory, Portfolio Decision, Experiment Backlog, Kill Criteria), além dos 6 relatórios individuais completos em `audit_notes/`.*
