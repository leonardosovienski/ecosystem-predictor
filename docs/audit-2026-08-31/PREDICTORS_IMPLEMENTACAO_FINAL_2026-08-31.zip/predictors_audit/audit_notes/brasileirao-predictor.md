# Auditoria técnica independente — `brasileirao-predictor`

**Auditor:** revisão cética externa (não desenvolvedora do projeto)
**Repositório:** `brasileirao-predictor` (parte do ecossistema PREDICTORS, 6 repos)
**HEAD auditado:** `e27db0cf078f747c26cf3e44487d097278e5605b` (branch `main`)
**Congelado em:** 2026-08-31 · 235 commits desde 2026-07-10 (FACT — verificado com `git log`)
**Modo:** somente leitura. Nenhum commit, edição de arquivo rastreado ou comando destrutivo foi executado.

---

## 0. Taxonomia de evidência usada neste documento

| Rótulo | Significado |
|---|---|
| **FACT** | Verificado diretamente por mim (execução, leitura de código, hash, teste) |
| **INFERENCE** | Conclusão lógica a partir de FACTs, não testada isoladamente |
| **HYPOTHESIS** | Possível explicação, não testada |
| **CONFIRMADO** | Claim do repo verificado independentemente e batendo |
| **PARCIALMENTE CONFIRMADO** | Parte do claim verificada, parte não |
| **CLAIM DOCUMENTAL** | Só existe no HANDOFF/docs; não reproduzido por mim |
| **CONTRADITÓRIO** | Documentos internos se contradizem entre si |
| **STALE** | Correção documentada mas não presente no código atual |
| **NÃO REPRODUZÍVEL** | Tentei reproduzir e não consegui (falta de dado/ambiente) |
| **INVALIDADO** | Claim testado e refutado (pelo próprio projeto ou por mim) |
| **INCONCLUSIVO** | Evidência insuficiente para decidir, mesmo com boa metodologia |
| **NÃO TESTADO** | Não há evidência de que tenha sido testado |
| **MISSING EVIDENCE** | Não há artefato/registro que permita verificar |

Níveis L0–L6 seguem a cadeia conceitual da tarefa: **L0 Dados corretos → L1
Experimento válido → L2 Capacidade preditiva → L3 Edge econômico → L4 Edge
capturável → L5 Resultado líquido → L6 Robustez prospectiva/escalabilidade**.

---

## 1. Nota metodológica crítica: este repositório já se auditou pesadamente

Diferente de um projeto típico, `brasileirao-predictor` contém uma cadeia longa
de auto-auditorias internas explícitas — `docs/AUDITORIA_MATEMATICA_E_CORRECOES_2026-08-26.md`,
`docs/DOSSIE_ANALISE_PREDICTOR_2026-08-26.md`,
`docs/RELATORIO_FINAL_CONSOLIDADO_2026-08-26.md`,
`docs/ou25_v2/AUDITORIA_INTEGRAL_2026-08-28.md`, `docs/HANDOFF_OU25_RODADA_2026_08_29.md`
— assinadas com data, número de testes, hashes SHA-256 e limitações explícitas.
Essas auditorias já fazem boa parte do trabalho que normalmente eu teria que
descobrir do zero, e o tom delas é **incomum**: assumem ativamente que o
resultado é negativo (capital bloqueado, sem edge demonstrado) e documentam
bugs encontrados contra si mesmas.

Isso é uma faca de dois gumes para uma auditoria independente:

- **Positivo (FACT):** a cultura de governança do repo é genuinamente forte —
  pré-registro obrigatório, ledger append-only de hipóteses
  (`data/trials.json`, 29 entradas únicas), barreira de somente-leitura para
  pesquisa (P12), CI com barreiras estáticas (`scripts/ci_check.py`), e um
  histórico de bugs matemáticos reais encontrados e corrigidos (ver §5).
- **Risco (INFERENCE):** eu não posso simplesmente confiar nessas
  auto-auditorias como se fossem uma auditoria externa — elas foram escritas
  pelo mesmo processo/agente que constrói o sistema, seguindo o mesmo
  documento-mestre (`HANDOFF.md`) que a Regra 3 desta tarefa me manda não
  tratar como verdade. Onde pude, reexecutei e recalculei; onde não pude
  (ausência do banco operacional `data/matches.db`), isso está marcado
  explicitamente como **NÃO REPRODUZÍVEL POR MIM**, mesmo quando o próprio
  repo também already afirma o mesmo.

Minha auditoria, portanto, faz três coisas: (a) verifica se o que é
verificável sem o banco operacional bate; (b) audita a *qualidade do processo*
de auto-auditoria, procurando lacunas que ele mesmo pode ter deixado passar;
(c) audita explicitamente a cadeia conceitual (dados→edge→capturável→líquido→
prospectivo) para não deixar a documentação confundir estágios.

---

## 2. O que eu consegui reproduzir de fato (FACT)

| Item | Comando | Resultado observado por mim | Comparação com claim documental |
|---|---|---|---|
| Instalação do ambiente | `uv sync --all-extras --locked` | 58 pacotes instalados, incluindo `predictor-core==2.3.0` e `predictor-ops==3.1.0` baixados de releases do GitHub de outros repos do ecossistema | Consistente — dependências externas do ecossistema resolvem |
| Suíte de testes completa | `uv run python -m pytest -q` | **873 passed, 1 skipped, 1 deselected** em 261,78s | HANDOFF cita 752 (commit `20c5d2c`, mais antigo), depois 814/815 (commit `bec073d`, auditoria 28/08). Contagem cresce de forma monotônica e plausível ao longo dos commits — **CONFIRMADO** como tendência, não como número fixo (o próprio README avisa para nunca copiar um número histórico) |
| Barreiras estáticas de CI | `uv run python scripts/ci_check.py --fast` | 5 barreiras: pytest pulado (fast), P12 (pesquisa somente-leitura) verde, P3 (Elo contido no serving) verde, smokes de predict/live **pulados por ausência de `data/matches.db`** | **CONFIRMADO** — bate exatamente com o que a auditoria interna de 28/08 relatou para o clone limpo |
| Banco operacional `data/matches.db` | `find . -iname matches.db` | **Ausente** — excluído por `.gitignore` (`*.db`), como declarado | **CONFIRMADO**: o repositório é estruturalmente incapaz de rodar backtests reais de ponta a ponta sem um artefato de ~49,5 MB que não está versionado. Todo benchmark numérico "canônico" citado nos docs (RPS, Brier, matrizes de confusão, comparação com mercado) é **NÃO REPRODUZÍVEL POR MIM** neste ambiente — só posso auditar os JSONs de saída já commitados e o código que os geraria |
| Métricas probabilísticas (`predictor_core.measurement.metrics`) | teste ad-hoc em Python (`brier`, `log_loss`, `rps` com vetor `[0.2,0.3,0.5]`, outcome=2) | `brier=0.38`, `log_loss=0.6931`, `rps=0.145` — bate com cálculo manual independente | **CONFIRMADO**: as fórmulas de Brier multiclasse, log-loss e RPS ordinal (CDF cumulativa vs. degrau, dividido por K-1) estão matematicamente corretas e a implementação é stdlib pura, sem heurística escondida |
| `predictor_core.testing.prequential.PrequentialEvaluator` | leitura de código | ABC que fatia por índice, remove `target_key` de `predict_step`, e os históricos usados no ecossistema (`src/evaluator.py`, `src/elo_baseline.py`, `src/serving_evaluator.py`) herdam dela de fato | **CONFIRMADO**: existe walk-forward real, não retrospectivo disfarçado — a proteção anti-leakage é estrutural (o core literalmente apaga o campo de resultado antes de entregar as features), não apenas disciplinar |
| Guarda de "bloco de kickoff" em `src/evaluator.py` | leitura de código | `train_step` só enfileira; o fit real acontece em `predict_step`, truncando por `kickoff < horizon` — evita que jogos simultâneos da mesma rodada vazem uns para os outros | **CONFIRMADO** — é uma proteção anti-leakage mais sofisticada do que a maioria dos backtests esportivos public que eu já vi (a maioria ignora rodadas simultâneas) |
| Fix do clip silencioso de Dixon-Coles | leitura de `src/dixon_coles.py` | `DixonColesMatrix.__init__` **lança `ValueError`** se `rho` está fora do intervalo válido, em vez de `clip` silencioso | **CONFIRMADO, NÃO STALE** — a correção descrita em `AUDITORIA_MATEMATICA_E_CORRECOES_2026-08-26.md` item 2 está de fato implementada no código atual |
| Fix de regressão à média do Elo até o horizonte | leitura de `src/ratings.py` (`compute_ratings`, função `decay`) | Decai `ratings[team]` proporcionalmente ao tempo desde o último jogo até `asof`/horizonte, com meia-vida configurável | **CONFIRMADO, NÃO STALE** — bate com o item 3 da auditoria matemática |
| Point-in-time correto no provedor de odds prospectivas | leitura de `src/data/the_odds_api_provider.py` | Linha 100: `if ... or captured >= kickoff: continue` — descarta explicitamente qualquer cotação capturada **no ou depois do kickoff**, tanto em `fetch_markets` quanto em `fetch_event_markets` | **CONFIRMADO**: há um guard de código real (não só convenção documental) contra usar odds de fechamento/pós-jogo como se fossem pré-jogo, para o pipeline "The Odds API" (H3/H5/H7/H9) |
| Consistência interna do ledger vs. artefato bruto (H12) | comparei `data/trials.json` (nota da trial `h12-ensemble-xg-ligado-vs-desligado`) com `reports/research_xg_ensemble_2026-08-22.json` | RPS controle `0.217749`, tratamento `0.213339`, ganho `0.004410`, IC95 `[0.001436; 0.007741]` — **idênticos** nos dois arquivos, em todas as casas decimais checadas | **CONFIRMADO**: não há divergência entre o que o ledger resume e o artefato bruto que deveria sustentá-lo — checagem cruzada real de dados, não só de prosa |
| Escopo indevido de um doc "geral" | leitura de `docs/CAUSA_RAIZ.md` | O documento inteiro (evita-favoritos, componente azarão/empate, experimentos causais A/B/C/F) usa **51 jogos da Copa 2026**, não Brasileirão | **CONTRADITÓRIO/RISCO DE CONFUSÃO DE ESCOPO**: o `DOSSIE_ANALISE...` avisa explicitamente que só `RELATORIO_FINAL.md` e `CONCLUSOES.md` são legado da Copa — mas `CAUSA_RAIZ.md` também é 100% sobre a Copa e não carrega esse aviso. Um leitor apressado pode citá-lo como evidência causal do Brasileirão por engano |

---

## 3. Tese original, histórico e pivôs (seções 14–16)

**FACT** (README + HANDOFF + trials.json): o objetivo original é replicar, no
Brasileirão Série A, um motor genérico (Elo + Binomial Negativa + Dixon-Coles)
já usado no repo-irmão `wc-predictor-v2` (Copa do Mundo), e testar se ele gera
edge de apostas de valor contra odds de mercado (1X2, depois OU2.5, BTTS,
mercados de 1º tempo). A hipótese H1 nasce explicitamente como réplica da
**única** hipótese com CLV comprovado no repo da Copa.

Linha do tempo reconstruída (FACT via `data/trials.json`, `git log`, docs
datados):

1. **2026-07-10 a 2026-07-25** — bootstrap do domínio Brasileirão, ingestão
   Sofascore, backtest walk-forward inicial. H1 (OU2.5 walk-forward,
   2024–2025) roda: ROI +7,9%, CLV open +19,55%, mas **IC95 cruza zero e DSR
   fica na trave** → **REFUTADA** (não GO).
2. **2026-07-25** — bug B-1 encontrado e corrigido: odds do agregado Sofascore
   estavam carimbadas com o nome de uma casa (bookmaker) que nunca as forneceu
   de fato. H3/H5 (shadow OU2.5 e ensemble xG shadow) são reabertas como
   "*-pinnacle-2026", agora usando The Odds API com bookmaker nomeado de
   verdade.
3. **2026-08-09 a 2026-08-22** — expansão para mercados 1X2/BTTS/OU2.5,
   testes de cadência de refit (H11), ensemble xG (H12 — única "comprovada"),
   divergência modelo×mercado (MARKET-02/03/04/06) — todas com veredito
   **NO-GO / REFUTADA / ARCHIVE**.
4. **2026-08-22 a 2026-08-24** — pivô explícito: em vez de tentar vencer o
   mercado com o mesmo motor de probabilidade, o próximo caminho econômico
   passa a ser **arbitragem estrutural** entre casa de referência (Pinnacle)
   e casas soft brasileiras (MARKET-05/A1), um mecanismo que não depende do
   modelo interno vencer o mercado em probabilidade pura.
5. **2026-08-26** — auditoria matemática encontra e corrige 4+ bugs reais
   (normalizador NB+DC, domínio de rho, decay terminal do Elo, climatologia
   contaminada com a própria coorte). H13 é **substituída sem avaliação**
   porque o baseline e o motor continham esses defeitos; sucessoras H14/H15
   são pré-registradas mas a coleta nunca começa antes do congelamento.
6. **2026-08-27 a 2026-08-31** — pivô para OU2.5 com um "Fase 0"
   (`A1_OU25_PHASE0_RUNBOOK.md`): sem labels, sem picks, sem Kelly, sem
   capital até homologação. Estado final congelado: `PAPER_CAPITAL_TEST`,
   banca virtual 100u, exposição real 0u, zero candidatos executados,
   automação desligada por pedido explícito do usuário.

**INFERENCE:** a trajetória mostra um padrão saudável de "falha rápida,
descarte honesto, pivô" (H1→H3/H5→H9→H13→H14/H15; MARKET-02→03→04→05→06),
mas também mostra que **nenhum caminho chegou a capital real em 235 commits e
~7 semanas de trabalho intenso**. Isso não é em si evidência contra o
processo — é evidência de que o domínio é difícil e/ou que o motor de
probabilidade escolhido (Elo+NB+DC, força resumida por um único índice) tem
teto estrutural baixo contra um mercado com mais informação (ver §4).

---

## 4. Validade estatística e calibração (seção 41 — prioridade máxima)

### 4.1 As métricas estão corretas?

**CONFIRMADO** (ver §2): Brier multiclasse, log-loss e RPS ordinal em
`predictor_core.measurement.metrics` foram verificados manualmente por mim e
batem com as fórmulas padrão da literatura (RPS de Constantinou & Fenton para
resultados ordinais 1X2). Não há heurística escondida, e o código é stdlib
pura, o que facilita auditoria (não há dependência de bibliotecas com
comportamento oculto).

### 4.2 Existe walk-forward real ou é retrospectivo disfarçado?

**CONFIRMADO** que existe um motor prequential genuíno
(`PrequentialEvaluator`), com proteção anti-leakage estrutural (o campo alvo é
fisicamente removido antes de `predict_step`) e uma guarda adicional contra
vazamento *dentro* de uma rodada simultânea (`src/evaluator.py`) — um cuidado
que projetos de apostas esportivas amadores tipicamente **não** têm. Isso é um
ponto genuinamente forte do repositório.

Ressalva (**INFERENCE**, baseada em §4.4/§4.5 abaixo): "walk-forward real" não
é sinônimo de "seleção de hipótese cega". O motor evita vazamento *dentro* de
cada backtest, mas não evita, por si só, vazamento *entre* backtests — i.e.,
overfitting do processo de pesquisa ao reexecutar o mesmo painel histórico
repetidas vezes com variações (ver §7).

### 4.3 Existe baseline forte (Elo) para comparação?

**PARCIALMENTE CONFIRMADO.** Existe `src/elo_baseline.py` herdando do mesmo
`PrequentialEvaluator`, e a `H4_DIXON_COLES_CALIBRATED` é comparada contra uma
**climatologia prequential** (frequência histórica marginal, congelada por
bloco de data) — não contra Elo puro como baseline principal nos relatórios
mais recentes que examinei (`AUDITORIA_MATEMATICA...`, `DOSSIE_ANALISE...`).
A climatologia é um baseline mais fraco que Elo puro (Elo já captura força
relativa; climatologia não capta nada específico do confronto). O modelo bate
a climatologia com IC95 que não cruza zero:

| Métrica | Serving v2 | Climatologia prequential | Delta | IC95 do delta |
|---|---:|---:|---:|---:|
| RPS | 0,213240 | 0,221284 | −0,008044 | [−0,012119; −0,004452] |
| Brier 1X2 | 0,622222 | 0,640130 | −0,017908 | [−0,025904; −0,010295] |
| Log loss | 1,036350 | 1,060805 | −0,024455 | [−0,036870; −0,013293] |

n=1.320, 2021–2024 (**CLAIM DOCUMENTAL**, não reproduzido por mim — banco
ausente). Isso é **capacidade preditiva mínima demonstrada** (L2) contra um
baseline fraco, não evidência de edge econômico (L3), e o próprio dossiê
interno é honesto sobre isso.

Achado adicional relevante (**FACT** via `data/trials.json`, trial H14): a
climatologia usada em H13 (antes da correção) estava contaminada com a própria
coorte de avaliação — outro bug real encontrado e corrigido, mas que
**invalidou retroativamente** o único gate econômico 1X2 que estava em
andamento (H13 foi substituída "sem avaliação final").

### 4.4 O modelo bate o mercado de forma estatisticamente significativa?

**INVALIDADO — na direção oposta à esperada.** O achado mais importante desta
auditoria (CLAIM DOCUMENTAL, consistente entre `DOSSIE_ANALISE` e
`RELATORIO_FINAL_CONSOLIDADO`, ambos de 2026-08-26, **não reproduzido por mim**
por falta do banco):

| Temporada | n | RPS modelo | RPS mercado (agregado Sofascore, sem vig) | Modelo − mercado |
|---|---:|---:|---:|---:|
| 2021 | 180 | 0,204551 | 0,189191 | +0,015360 |
| 2022 | 380 | 0,210715 | 0,203368 | +0,007347 |
| 2023 | 380 | 0,218833 | 0,210820 | +0,008013 |
| 2024 | 378 | 0,214532 | 0,198260 | +0,016272 |
| **Total** | **1.318** | **0,213309** | **0,202115** | **+0,011193** |

Em RPS, menor é melhor: o mercado bate o modelo em todas as quatro temporadas.
A desvantagem é maior justamente quando a confiança máxima do modelo é baixa
(<40%: +0,0166 RPS) e quase desaparece quando a confiança é alta (≥60%:
−0,0003 RPS, i.e. empatado). Isso é uma evidência **contra** L3 (edge
econômico): o modelo não só não bate o mercado, ele perde de forma consistente
e concentrada exatamente nos jogos ambíguos, que é onde um edge real
precisaria aparecer.

Limitação séria que o próprio time documenta com honestidade: o "mercado" aqui
é um **agregado sem bookmaker nomeado do Sofascore**, rotulado
`SOFASCORE_AGGREGATE_UNNAMED_DIAGNOSTIC_ONLY` — não é preço executável, não
tem timestamp de captura point-in-time garantido, e pode ter viés de seleção
ou de fechamento (ver §5). Ou seja: mesmo essa comparação desfavorável ao
modelo é, ironicamente, **fraca como medida de mercado eficiente real** —
apenas um diagnóstico, nunca uma medida de mercado executável.

### 4.5 Calibração probabilística: é real e bem medida?

**PARCIALMENTE CONFIRMADO, com ressalva estrutural importante.**

- A calibração marginal de empate (`p_draw` médio vs. frequência real) é
  **razoável até 2025** (gaps de −0,6 a +2,8 p.p.), mas piora em 2026
  (gap de −4,76 p.p., amostra ainda pequena: n=225).
- O `argmax` **nunca escolhe empate** em nenhuma das seis temporadas
  observadas (2021–2026), embora a probabilidade marginal de empate não seja
  próxima de zero. O próprio relatório interno distingue corretamente
  "calibração marginal" de "capacidade de ordenação/argmax" — uma distinção
  estatisticamente correta que evita o erro clássico de achar que "nunca
  prever empate" implica "P(empate)≈0".
- 73–78% dos erros em todos os anos são do tipo "resultado não vencido pelo
  mandante classificado como vitória da casa" — um padrão **estrutural e
  recorrente**, não um acidente de uma temporada.
- **MISSING EVIDENCE** (reconhecido no próprio dossiê, seção 13, pergunta 6):
  não há decomposição formal de Brier em calibração/resolução/incerteza, nem
  slope/intercept de calibração por classe com IC, nem histogramas PIT/rank.
  Ou seja, a "calibração" reportada é sobretudo calibração-marginal simples
  (média prevista vs. frequência observada em faixas largas), não um pacote
  completo de diagnósticos de calibração probabilística. Isso é uma lacuna
  real que reduz a confiança de que "o modelo está bem calibrado" seja uma
  afirmação totalmente sustentada — é **plausível, mas incompletamente
  auditado mesmo internamente**.

**Meu nível de confiança pessoal, como auditor cético, de que a calibração
reportada é real (não artefato de bug) e mede o que diz medir: MÉDIO-ALTO.**
As fórmulas de métrica estão corretas (verifiquei eu mesma), o walk-forward é
genuíno (verifiquei eu mesma), e há um histórico público de bugs de calibração
sendo *encontrados e corrigidos pelo próprio processo* (normalizador NB-DC,
domínio de rho, decay terminal, climatologia contaminada) — o que é evidência
de um processo que se auto-corrige, não de um processo que esconde furos. Mas
minha confiança não é "alta" pura porque (a) não reproduzi os números
primários (sem banco), (b) a decomposição fina de calibração (slope/intercept,
PIT histograms) é uma lacuna reconhecida, e (c) todo o "confirmado" depende de
transitivamente confiar na cadeia de auto-auditoria já que não tenho acesso ao
dado bruto.

---

## 5. Odds históricas e point-in-time (seção C)

**PARCIALMENTE CONFIRMADO / MISTO** — há dois caminhos de odds bem
diferenciados no repositório, e é importante não confundi-los:

1. **`src/data/the_odds_api_provider.py`** (The Odds API, chave `ODDS_API_KEY`):
   **CONFIRMADO** por leitura de código que há um guard estrutural
   (`captured >= kickoff: continue`) contra usar cotações capturadas no ou
   após o apito como se fossem pré-jogo. Usado pelas trials H3/H5/H7/H9
   ("*-pinnacle-2026"), com bookmaker nomeado (Pinnacle) desde a correção do
   bug B-1 (2026-07-25).
2. **`collector_a1.py` / `poc_oddspapi.py`** (OddsPapi, chave `ODDSPAPI_KEY`,
   comparação Pinnacle × casas soft BR): este é o "único caminho econômico
   ainda vivo" segundo os próprios docs — **e está, de forma verificada e
   consistente em três documentos datados de dias diferentes (24/08, 26/08,
   28/08), permanentemente `NOT_STARTED`**: 0 dias de shadow, 0 snapshots, 0
   requests registrados, `ODDSPAPI_KEY` ausente do ambiente, nenhuma tarefa
   agendada instalada. A auditoria de 28/08 registra ainda que a chave
   fornecida anteriormente em chat "deve ser considerada exposta" e não deve
   ser reutilizada.
3. **Agregado Sofascore sem bookmaker** (`sofascore_matches`, usado nos
   benchmarks "modelo vs. mercado" citados em §4.4): rotulado
   `DIAGNOSTIC_ONLY`, sem `captured_at` point-in-time garantido para todas as
   linhas. A auditoria de 28/08 verificou uma cópia real do banco operacional
   e encontrou: dos 25.142 snapshots de odds, apenas 200 são marcados
   `pre_match=1`; os demais 24.942 (99,2%) são `pre_match=0`, i.e. **não são
   elegíveis como preço executável point-in-time**. Isso é uma limitação
   estrutural séria e bem documentada: a maior parte do histórico de odds
   disponível no banco operacional **não serve** para medir edge contra
   mercado eficiente de forma rigorosa.

**CONCLUSÃO desta seção:** existe engenharia de point-in-time correta no
código que lida com fontes nomeadas (The Odds API), mas a fonte de odds
efetivamente usada nos grandes benchmarks retrospectivos "modelo vs. mercado"
(§4.4, e a maior parte do OU2.5 anual — ver §6) é o agregado sem bookmaker,
que é adequado só como diagnóstico. **Não há, até o congelamento, nenhuma
coorte prospectiva com odds nomeadas e point-in-time em volume suficiente
para medir edge real capturável (L4).**

---

## 6. Tentativa de reprodução (seção D)

| Comando | Resultado |
|---|---|
| `uv sync --all-extras --locked` | ✅ sucesso — dependências do ecossistema resolvidas via GitHub releases |
| `uv run python -m pytest -q` | ✅ **873 passed, 1 skipped, 1 deselected**, 261,78s |
| `uv run python scripts/ci_check.py --fast` | ✅ 5 barreiras, com os 2 smokes de banco marcados `PULADO (sem banco)` — comportamento esperado e documentado |
| Backtests/benchmarks reais (`scripts/backtest_walkforward.py`, `scripts/benchmark_predictor.py`) | ❌ **NÃO REPRODUZÍVEL POR MIM** — dependem de `data/matches.db` (49,5 MB), que está fora do Git por design e não foi fornecido a esta sessão. Nenhum comando de coleta (`ingest_sofascore`) funciona no sandbox (o próprio README avisa: "o Sofascore não responde ao sandbox") |
| Coletor A1 / odds prospectivas | ❌ **NÃO REPRODUZÍVEL POR MIM** — requer `ODDSPAPI_KEY`/`ODDS_API_KEY` reais, ausentes de `.env.example` por design |

**Conclusão desta seção:** o software instala e a suíte de testes (que testa
lógica unitária, contratos, formatos, guardas anti-leakage, parsers, etc. com
dados sintéticos/fixtures) passa integralmente. Isso é evidência real de
qualidade de engenharia (**CONFIRMADO**). Mas **nenhum número econômico ou de
qualidade preditiva agregada deste relatório foi recalculado por mim a partir
de dados brutos** — todos os números de RPS/Brier/ROI/CLV citados aqui vêm de
artefatos JSON já commitados (`reports/*.json`) ou de prosa nos docs, e
recebem o rótulo **CLAIM DOCUMENTAL** salvo quando houve checagem cruzada
explícita entre dois artefatos independentes (como fiz para H12, §2).

---

## 7. Multiple testing e graus de liberdade (seção F)

**FACT:** o ledger de hipóteses (`data/trials.json`) tem **29 nomes únicos**
com status explícito (6 refutadas, 3 informativas, 3 substituídas, 6
inconclusivas, 2 exploratórias, **1 comprovada**, 8 pré-registradas). Além
disso, apenas para o mercado OU2.5 v2, o grid fatorial fechado
(`reports/ou25_v2/ou25_factorial/`) registra **1.620 combinações por fold ×
10 folds = 16.200 "trials" registrados por célula**, com 9 células (3
cadências de refit × 3 tamanhos de bloco de bootstrap) — ou seja, uma ordem de
grandeza de **centenas de milhares de combinações avaliadas** só nessa
sub-busca. O ponto positivo (**CONFIRMADO**): o campo `selection` desse
artefato diz explicitamente `"none; closed factorial reported in full"` — o
grid inteiro é reportado, não só a melhor célula, o que é uma prática correta
contra p-hacking *dentro* dessa sub-busca específica.

Porém, no nível do **processo de pesquisa como um todo** (não de uma única
grade fechada), o próprio `docs/HANDOFF_OU25_RODADA_2026_08_29.md` admite uma
lacuna que ele mesmo não resolve: *"ausência de seleção retrospectiva entre as
80 configurações investigadas"* aparece na lista do que **ainda não foi
validado**. Ou seja, o time reconhece que existiram ~80 configurações
diferentes exploradas no caminho até o "recorte mais interessante" de OU2.5
(EV mínimo 15%, odd 1,80–2,40) — e não há, até o congelamento, uma correção de
multiplicidade formal (tipo Holm/Bonferroni) cobrindo *essa* busca específica,
mesmo havendo Holm aplicado a comparações pontuais como H14/H15.

**UNKNOWN RESEARCH SEARCH SPACE (parcial):** não consegui, a partir do que
está versionado, reconstruir a árvore completa de todas as combinações de
mercado × EV mínimo × banda de odd × turno × temporada que foram exploradas
ao longo de 235 commits antes de chegar no recorte "Under 2.5, EV≥15%, odd
1,80–2,40". O ledger de 29 hipóteses documenta as *hipóteses formais*
pré-registradas, mas não documenta necessariamente toda exploração informal
(varreduras de sensibilidade, tentativas de threshold, etc.) que pode ter
precedido cada pré-registro. Isso é consistente com — mas não prova — a
possibilidade de que o "recorte mais interessante" tenha sido encontrado por
um processo de busca mais amplo do que o formalmente registrado.

**INFERENCE:** o único resultado retrospectivo com IC95 inferior de ROI
estritamente positivo em todo o corpus que revisei é **2025 completo** (ROI
+23,65%, IC95 [+5,91%; +41,21%], n=159) e **2025 primeiro turno** (ROI
+33,26%, IC95 [+9,80%; +57,12%], n=86) para o recorte Under 2.5/EV≥15%. Isso
é exatamente o tipo de resultado que uma busca sobre ~80 configurações, sem
correção de multiplicidade formal, produziria por acaso com probabilidade não
desprezível. O próprio time rotula esse resultado como **contaminado**
(2025 já foi "aberto" como holdout para outro propósito — ver §8) e como
`PREDICTION_GENERATION_AND_ECONOMIC_EXECUTABILITY_NOT_REVALIDATED`. Concordo
com essa autoavaliação: **este resultado positivo isolado não deve ser tratado
como edge, é o resultado mais provável de aparecer em uma busca ampla sobre
séries temporais curtas com odds agregadas pós-jogo.**

---

## 8. Auditorias internas anteriores: STALE check (seção E)

Verifiquei se as correções descritas nas auto-auditorias estão de fato
presentes no código atual (não apenas escritas em prosa):

| Correção documentada | Onde | Verificação |
|---|---|---|
| Normalizador NB+Dixon-Coles ausente na verossimilhança | `AUDITORIA_MATEMATICA...`, item 1 | **NÃO REPRODUZIDO NUMERICAMENTE** (exigiria refit completo), mas a suíte `test_dixon_coles.py`/`test_dixon_coles_fit.py` (20 testes) passa |
| `rho` deixa de ser clipado silenciosamente | item 2 | **CONFIRMADO** — `src/dixon_coles.py` levanta `ValueError` explícito (ver §2) |
| Regressão à média do Elo até o horizonte | item 3 | **CONFIRMADO** — implementado em `src/ratings.py::compute_ratings` (ver §2) |
| Climatologia prequential (sem vazar a própria coorte) | item 4 | **PARCIALMENTE CONFIRMADO** — a trial H13 foi explicitamente descartada por causa desse bug e a sucessora H14 declara `baseline: prequential_climatology_dirichlet_1_by_date_block`; não abri o código da climatologia linha a linha para confirmar a ausência total de vazamento, mas o teste `test_prereg_serving_vs_climatologia.py` passa (12 testes, 1 skip) |
| Estratos menores que o bloco de bootstrap recebem `ci95=null` em vez de abortar | item 5 | **CLAIM DOCUMENTAL**, coerente com a existência de `reports/benchmark_h9_frozen_corrected_2021_2024_2026-08-26.json` citado nos docs; não reproduzido |
| Hash do cache inclui versão do algoritmo | item 6 | **NÃO VERIFICADO DIRETAMENTE** (exigiria inspecionar `cron_update_models.py`/cache real, que não existe neste checkout) |
| Bug B-1 (odds carimbadas com bookmaker errado) | `data/trials.json`, notas H3/H5 | **CLAIM DOCUMENTAL**, consistente entre múltiplas trials |
| Bug do replay OU2.5 dividindo jogos simultâneos entre treino/teste | `AUDITORIA_INTEGRAL_2026-08-28.md` | **CONFIRMADO por meio indireto**: os testes de regressão citados (`test_ou25_nested_replay.py`, 10 testes) passam na minha execução da suíte completa |

**Conclusão desta seção:** nos itens que consegui checar diretamente lendo o
código-fonte (não apenas os testes passando, mas a lógica em si), **as
correções documentadas estão de fato implementadas — nenhuma STALE
encontrada** nos pontos verificados. Isso é um resultado positivo genuíno para
a integridade do processo. A ressalva é que nem todos os itens documentados
puderam ser verificados por mim por falta do banco operacional.

---

## 9. Resultados negativos: crédito explícito (seção G)

O projeto merece crédito real por hipóteses corretamente descartadas com
metodologia adequada (IC95, bootstrap de bloco móvel, correção de
multiplicidade quando aplicável, poder estatístico calculado antes de
declarar "sem efeito"):

- **H1** (OU2.5 walk-forward, réplica da única hipótese comprovada na Copa):
  refutada com IC95 cruzando zero e DSR na trave — não forçada a "quase-GO".
- **H11** (cadência de refit 10 vs. 100 jogos): ganho de RPS com IC95
  `[-0,00165; +0,00475]` cruzando zero → refutada, mesmo com ponto estimado
  favorável ao tratamento.
- **MARKET-02/03/04/06** (divergência 1X2 vs. mercado, OU2.5 residual, BTTS):
  todas fechadas com veredito explícito (`NO_GO_CURRENT_RESIDUAL`,
  `ARCHIVE_OU25_CURRENT_RESIDUAL`, `NO_GO_LOW_MODEL_RESOLUTION`,
  `NO_GO_STRUCTURAL`), incluindo cálculo de MDE (mínimo efeito detectável) e
  análise de permutação (1.000 permutações estratificadas em MARKET-03) antes
  de declarar ausência de sinal — em vez de simplesmente reportar "p>0,05".
- **Experimentos causais de intervenção** (`docs/CAUSA_RAIZ.md`, embora sobre
  o domínio Copa, não Brasileirão — ver §2): distinguem corretamente
  correlação de causa ao testar componentes isoladamente (ex.: zerar rho não
  move o componente de empate → Dixon-Coles não é a causa do viés de empate;
  descomprimir Elo move o componente de azarão → compressão de Elo é causa).
  Esse padrão metodológico, se replicado no domínio Brasileirão (não
  encontrei evidência de que tenha sido — **MISSING EVIDENCE**), seria um bom
  modelo a seguir.
- **H9** (réplica prospectiva formal do H1/H8): nunca atingiu amostra mínima
  antes de ser descontinuada pela auditoria matemática de 26/08 — corretamente
  rotulada `inconclusiva`, não forçada a "GO" nem "NO-GO" prematuro.

**INFERENCE:** o padrão geral é de disciplina científica acima da média para
este tipo de projeto solo/pequena equipe — a tentação usual em backtests de
apostas esportivas é maquiar resultados negativos como "promissores com mais
dados"; aqui os vereditos são majoritariamente diretos.

---

## 10. Tabela de hipóteses

| Hipótese | Claim original | Evidência encontrada | Resultado reproduzido? | Edge bruto | Edge líquido | Prospectivo? | Estado após auditoria |
|---|---|---|---|---|---|---|---|
| H1 — OU2.5 walk-forward 2024–25 (réplica Copa) | Mesma hipótese com CLV comprovado na Copa teria edge no Brasileirão | `data/trials.json`, `docs/RELATORIO_BACKTEST_2026-07-10.md` | Não (banco ausente) — **CLAIM DOCUMENTAL** | ROI +7,9% (ponto) | IC95 [−2,18%; +17,19%] cruza zero | Não | **INVALIDADO** (refutada) |
| H4 — Dixon-Coles calibrado (motor base) | Motor genérico capta força relativa | `src/model.py`, `src/dixon_coles.py`, testes | Parcial (código lido, lógica correta; números não recalculados) | — | — | — | **REFUTADA** como trial formal, mas **mantida como motor de serving/baseline** |
| H9 — réplica prospectiva OU2.5 (Pinnacle nomeado) | Confirmar H1/H8 com odds PIT nomeadas | Registro pré-jogo formal em `data/trials.json` | Não — amostra nunca atingiu o mínimo antes de ser descontinuada | N/D | N/D | Sim (mas incompleto) | **INCONCLUSIVA** |
| H11 — cadência de refit 10 vs 100 (retrospectivo) | Refit mais frequente melhora RPS | `reports/research_01a_refit_cadence_2026-08-21.json` | **CONFIRMADO** (cross-check ledger×artefato) — mas IC95 cruza zero | RPS Δ=0,00176 (ponto) | IC95 [−0,00165; +0,00475] | Não | **REFUTADA** |
| H11-v2 — mesma pergunta, algoritmo corrigido | Reexecução pós-correções matemáticas | `data/trials.json` | CLAIM DOCUMENTAL | RPS Δ negativo (favorável) | IC95 favorável, mas **registrado após ver o resultado** | Não | **INCONCLUSIVA** (não é pré-registro cego, vira insumo p/ H15) |
| H12 — ensemble xG ligado vs. desligado | Desligar ensemble melhora RPS | `reports/research_xg_ensemble_2026-08-22.json` **cross-checado por mim** contra `data/trials.json` | **CONFIRMADO** (números idênticos nos dois artefatos) | RPS Δ=0,00441 | IC95 [0,00144; 0,00774] — não cruza zero | Não (retrospectivo, mesma amostra onde efeito foi visto antes) | **COMPROVADA** apenas como *qualidade de modelo* — explicitamente **NÃO** autoriza edge econômico |
| H13 — serving vs. climatologia (1X2) | Serving bate climatologia numa coorte prospectiva | `data/trials.json` | N/A — nunca avaliada | N/D | N/D | Não (nunca chegou a n≥900) | **SUBSTITUÍDA sem avaliação** (baseline/motor tinham bugs) |
| H14 — serving v2 vs. climatologia prequential (prospectivo) | Sucessora corrigida de H13 | `docs/AUDITORIA_MATEMATICA...`, `data/trials.json` | Não — coleta `NOT_STARTED` no congelamento | N/D | N/D | Planejado, não iniciado | **PRÉ-REGISTRADA, sem dados** |
| H15 — refit 10 vs 100, serving v2 (prospectivo) | Sucessora de H11/H11-v2 | idem | Não — coleta `NOT_STARTED` | N/D | N/D | Planejado, não iniciado | **PRÉ-REGISTRADA, sem dados** |
| MARKET-03 — divergência 1X2 modelo×mercado | Divergência ordena retorno | `docs/experiments/MARKET_03_EDGE_ORDERING_PROTOCOL.md`, teste de permutação | CLAIM DOCUMENTAL (metodologia sólida: 1.000 permutações, MDE) | Sem monotonicidade | — | Não | **REFUTADA** (`NO_GO_CURRENT_RESIDUAL`) |
| MARKET-04 — OU2.5/BTTS resolução estrutural | Modelo separa jogos o suficiente para operar | `docs/RELATORIO_SESSAO_0B_2026-08-24.md` | CLAIM DOCUMENTAL | BTTS std=1,29pp < 2pp mínimo | — | Não | **REFUTADA** (`NO_GO_STRUCTURAL`) |
| MARKET-05/A1 — arbitragem estrutural Pinnacle×soft | Mecanismo não depende do modelo vencer o mercado em probabilidade | `data/trials.json`, `docs/experiments/STRUCTURAL_EDGE_SHADOW_PROTOCOL.md` | **NÃO REPRODUZÍVEL / NÃO INICIADO** — 0 dias de shadow, chave ausente | N/D | N/D | Não | **PRÉ-REGISTRADA**, único caminho ainda formalmente vivo, mas **paralisado operacionalmente** (tarefas desligadas 28/08) |
| OU2.5 v2 — Under 2.5, EV≥15%, odd 1,80–2,40 (recorte "mais interessante") | Recorte com melhor resultado contrafactual 2024–2026 | `docs/HANDOFF_OU25_RODADA_2026_08_29.md`; ~80 configurações exploradas (não corrigido p/ multiplicidade) | CLAIM DOCUMENTAL, ledger revalidado (742 linhas, sem duplicatas) | ROI 2025 completo +23,65% | IC95 ROI [+5,91%; +41,21%] — único positivo em toda a auditoria | **Não** — odds `POSTGAME_APPROXIMATION`, sem bookmaker/timestamp PIT; 2025 é holdout já contaminado | **INCONCLUSIVO / NÃO CAPTURÁVEL** — tratado corretamente pelo próprio time como não executável |

---

## 11. Cadeia conceitual, nível por nível (Regra 6)

| Nível | Pergunta | Veredito |
|---|---|---|
| **L0 — Dados corretos** | Os dados point-in-time existem e são íntegros? | **PARCIAL.** `PRAGMA integrity_check=ok` reportado para o banco operacional (não verificado por mim, banco ausente). Guard PIT real existe para The Odds API. Mas 99,2% dos snapshots de odds no banco operacional citado (28/08) são `pre_match=0` — não elegíveis como preço PIT. Odds usadas nos grandes benchmarks retrospectivos são agregado sem bookmaker. |
| **L1 — Experimento válido** | Walk-forward real, sem leakage? | **SIM, com boa engenharia** — `PrequentialEvaluator` + guarda de bloco de kickoff, confirmados por leitura de código. Multiplicidade do processo de busca mais amplo é **parcialmente não reconstruível** (UNKNOWN RESEARCH SEARCH SPACE). |
| **L2 — Capacidade preditiva** | O modelo prevê melhor que um baseline trivial? | **SIM, fraco.** Bate climatologia prequential com IC95 não cruzando zero (Δ RPS pequeno). Não foi comparado de forma proeminente contra Elo puro nos relatórios mais recentes que revisei. |
| **L3 — Edge econômico** | O modelo bate o mercado (odds eficientes)? | **NÃO DEMONSTRADO — evidência aponta o contrário.** Perde do agregado Sofascore sem vig em RPS/Brier/log-loss em todas as 4 temporadas observadas (2021–2024), com desvantagem concentrada em baixa confiança. |
| **L4 — Edge capturável** | Existe mecanismo point-in-time e bookmaker nomeado para capturar qualquer edge? | **NÃO OPERACIONAL.** Coletor A1 (Pinnacle×soft) formalmente especificado mas `NOT_STARTED` de forma consistente em três checkpoints (24/08, 26/08, 28/08) e tarefas desligadas em 28/08. |
| **L5 — Resultado líquido** | Existe ROI líquido de fricção (vig, limites, slippage)? | **NÃO TESTADO.** Nenhuma execução real ocorreu; ROI contrafactual reportado é bruto de odds pós-jogo aproximadas, não líquido de fricção real. |
| **L6 — Robustez prospectiva / escalabilidade** | Existe validação prospectiva cega e plano de escala? | **NÃO.** H14/H15/H9/market05-a1-shadow são pré-registradas mas sem coorte iniciada no congelamento. 2025 (o único ano com resultado retrospectivo positivo) já não é mais holdout cego. |

**INFERENCE central desta auditoria:** o projeto nunca avançou além de L2
(capacidade preditiva mínima contra um baseline fraco) de forma sólida. Em
L3 há evidência ativa **contra** a tese (perde do mercado). L4–L6 são, no
melhor caso, aspiracionais e formalmente bloqueados por falta de execução
operacional (chave de API, tarefas agendadas desligadas), não por
impossibilidade teórica.

---

## 12. Checkpoint obrigatório — 13 perguntas

*Nota metodológica: o enunciado da tarefa referencia "as 13 perguntas" da
seção 54 de um documento-mestre da auditoria maior que não me foi fornecido
neste contexto (não está neste repositório). Reconstruí abaixo 13 perguntas de
checkpoint consistentes com a cadeia conceitual da Regra 6 e com o escopo
pedido nas seções 14-32/41/43, e respondi cada uma com o rótulo de evidência
apropriado. Isso deve ser tratado como minha melhor reconstrução, não como
citação literal de um documento que não tive acesso.*

1. **Os dados de entrada são corretos e point-in-time?**
   PARCIALMENTE CONFIRMADO para a fonte The Odds API (guard de código real);
   NÃO CONFIRMADO para o agregado Sofascore usado nos grandes benchmarks
   (99,2% dos snapshots não são pré-jogo, segundo auditoria interna de 28/08).

2. **O experimento evita vazamento temporal (leakage)?**
   CONFIRMADO por leitura de código (`PrequentialEvaluator` + guarda de
   bloco de kickoff). Ponto forte genuíno do repositório.

3. **As métricas de avaliação estão implementadas corretamente?**
   CONFIRMADO por verificação numérica independente (Brier, log-loss, RPS).

4. **Existe capacidade preditiva acima de um baseline razoável?**
   PARCIALMENTE CONFIRMADO — bate climatologia fraca; comparação proeminente
   contra Elo puro como baseline principal não foi encontrada nos documentos
   mais recentes revisados.

5. **Existe edge estatisticamente significativo contra o mercado?**
   INVALIDADO — modelo perde do agregado de mercado em todas as 4 temporadas
   observadas, de forma consistente e concentrada em baixa confiança.

6. **O "mercado" usado como referência é uma medida válida de eficiência de mercado?**
   NÃO — é agregado sem bookmaker nomeado, `DIAGNOSTIC_ONLY` por declaração do
   próprio projeto. Isso enfraquece tanto o claim de derrota quanto qualquer
   claim futuro de vitória baseado na mesma fonte.

7. **Existe algum edge (bruto) capturável com execução real (bookmaker nomeado, PIT)?**
   NÃO TESTADO — coletor A1 nunca operou; H9 nunca atingiu amostra mínima.

8. **O resultado, se houvesse edge, sobreviveria à fricção (vig, stake, slippage)?**
   NÃO APLICÁVEL — não há edge bruto validado a testar quanto à fricção.

9. **Existe validação prospectiva cega (não contaminada por olhar resultado antes)?**
   NÃO — H14/H15/H9/A1 pré-registradas mas sem coorte iniciada;
   2025 (o único ano com ROI retrospectivo positivo) foi explicitamente aberto
   e deixou de ser holdout cego por pedido do usuário em 26/08.

10. **O processo de pesquisa controla multiplicidade/graus de liberdade?**
    PARCIALMENTE — Holm aplicado a pares específicos (H14/H15) e grid
    fatorial fechado reportado por inteiro (sem seleção); mas "~80
    configurações" do funil OU2.5 até o recorte final não têm correção de
    multiplicidade formal reconhecida pelo próprio time. UNKNOWN RESEARCH
    SEARCH SPACE para a árvore completa de exploração informal.

11. **Resultados negativos foram registrados e receberam crédito, não escondidos?**
    CONFIRMADO — ledger com 29 hipóteses, maioria refutada/inconclusiva/
    substituída, com veredito explícito e reprodutível (IC95, MDE, permutação).

12. **As correções documentadas de bugs estão de fato implementadas no código atual (STALE check)?**
    CONFIRMADO para os itens verificáveis sem banco (rho/DixonColes,
    regressão à média do Elo). Não STALE nos pontos checados.

13. **Existe caminho operacional realista para capital, dado o estado atual?**
    NÃO — capital `LOCKED` em todos os documentos revisados; automação
    desligada por pedido explícito do usuário em 28/08; único mecanismo
    formalmente vivo (arbitragem estrutural A1) sem execução iniciada.

---

## 13. Recomendação preliminar

### **CONGELAR o caminho de edge de probabilidade pura (1X2/OU2.5/BTTS via Elo+NB+Dixon-Coles); MANTER+TESTAR o caminho de arbitragem estrutural (A1); MANTER o motor como baseline/componente de plataforma.**

Justificativa, seguindo a cadeia conceitual:

- **Dados (L0):** infraestrutura de coleta e contratos são de boa qualidade
  técnica, mas a fonte de odds usada nos maiores benchmarks retrospectivos não
  é adequada para medir edge econômico executável, e a fonte adequada (A1,
  bookmaker nomeado) nunca operou de fato. **Não há capital de dados
  suficiente hoje para sustentar qualquer decisão econômica.**
- **Experimento (L1):** genuinamente válido — walk-forward real, anti-leakage
  estrutural, ledger de hipóteses auditável. Este é o maior ativo do projeto e
  deve ser preservado como infraestrutura, independentemente do destino do
  modelo específico.
- **Capacidade preditiva (L2):** modesta e real contra baseline fraco
  (climatologia), mas não estabelecida contra Elo puro como comparação
  principal nos relatórios mais recentes.
- **Edge econômico (L3):** ativamente **contra** a tese — o modelo perde do
  mercado agregado, de forma consistente em 4 temporadas, concentrada
  justamente na região (baixa confiança) onde um edge precisaria existir.
  Continuar investindo esforço de pesquisa em variações do mesmo motor
  (mando escalar, temperatura, rho, ensemble xG, recalibração de saída — todos
  já tentados e sem sucesso, segundo o próprio ledger) tem retorno esperado
  baixo sem informação nova (PIT: escalação, lesões, técnico), que o projeto
  reconhece não possuir.
- **Edge capturável / líquido / prospectivo (L4–L6):** nenhum avançou além do
  estágio de especificação. O único mecanismo com racional econômico
  diferente (arbitragem estrutural Pinnacle × soft, que não depende do motor
  de probabilidade vencer o mercado) está formalmente pré-registrado com
  gates sensatos, mas paralisado operacionalmente há semanas por falta de uma
  chave de API rotacionada e por decisão explícita do usuário de desligar a
  automação.

**Recomendações específicas:**

1. **CONGELAR** novas variações do motor de probabilidade pura (1X2/OU2.5/BTTS
   via Elo+NB+DC) até que exista informação PIT genuinamente nova (escalação,
   lesões, técnico) — não mais varreduras de hiperparâmetro sobre os mesmos
   dados históricos, que já consumiram ~80 configurações no funil OU2.5 sem
   correção de multiplicidade formal e sem sinal robusto.
2. **MANTER+TESTAR** o caminho A1 (arbitragem estrutural Pinnacle×soft) como
   única aposta de pesquisa ativa, mas apenas se o operador retomar
   explicitamente: chave rotacionada, 7 dias de coleta real, auditoria manual
   de 50 eventos — os próprios gates já especificados, sem atalhos.
3. **NÃO reabrir** 2025 nem 2026 como holdout — ambos já estão consumidos/
   contaminados por decisão documentada do próprio usuário; qualquer validação
   futura precisa de dados genuinamente futuros ao momento da decisão.
4. **NÃO tratar** o resultado positivo de OU2.5/2025 (ROI +23,65%, IC95>0)
   como evidência de edge — é o resultado mais provável de aparecer por acaso
   numa busca sobre dezenas de configurações com odds agregadas pós-jogo, e o
   próprio time já rotula isso corretamente como não executável.
5. **REDUZIR** o volume de documentação prospectiva especulativa (H14, H15,
   contratos de rodadas futuras) até que exista pelo menos uma coorte real
   com dados coletados — pré-registrar hipóteses sem nunca coletar dados por
   várias iterações seguidas tem custo de manutenção sem gerar evidência.
6. **PRESERVAR** a infraestrutura de governança (ledger, `PrequentialEvaluator`,
   `ci_check.py`, harness de controle positivo) como ativo do ecossistema
   PREDICTORS mais amplo — é reutilizável e é o ponto mais forte deste
   repositório, independentemente do destino do modelo Brasileirão
   especificamente.

---

## 14. Lacunas desta auditoria (o que eu não consegui verificar)

- **MISSING EVIDENCE:** todos os números primários de RPS/Brier/log-loss/ROI
  citados nos docs — não tive acesso a `data/matches.db` nem a qualquer banco
  operacional; toda verificação numérica direta que fiz veio de artefatos
  JSON já commitados em `reports/`, não de reexecução do pipeline completo.
- **MISSING EVIDENCE:** nenhuma chave de API (`ODDS_API_KEY`, `ODDSPAPI_KEY`,
  `API_FOOTBALL_KEY`, `SPORTMONKS_API_TOKEN`) estava disponível; não pude
  testar nenhum provedor de dados ao vivo.
- **NÃO TESTADO:** não executei a suíte .NET (`dotnet/LineupWorker`) — exigiria
  SDK .NET não presente neste ambiente; a própria auditoria interna de 28/08
  também reportou o mesmo bloqueio (`DOTNET_NOT_INSTALLED`).
- **NÃO TESTADO:** cobertura de código (`coverage`) não pôde ser gerada com o
  plugin `pytest-cov` (ausente das dependências declaradas); usei apenas a
  contagem de testes passando/falhando.
- **UNKNOWN RESEARCH SEARCH SPACE:** não reconstruí a árvore completa de
  exploração informal por trás do funil de ~80 configurações do OU2.5 —
  apenas o que está formalmente registrado em `data/trials.json` e nos
  artefatos de grid fechado.
