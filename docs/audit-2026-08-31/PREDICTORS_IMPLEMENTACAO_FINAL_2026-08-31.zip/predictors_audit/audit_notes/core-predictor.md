# Auditoria — `core-predictor` (predictor-core)

**Repositório:** `core-predictor` · branch `main` · HEAD `2ca42fd1b6519cc338ba41ca96c427c8a6423afc` (2026-08-31)
**Versão declarada:** `predictor-core` 2.3.0 (`pyproject.toml`)
**Auditor:** auditoria técnica cética, independente — parte da auditoria estratégica PREDICTORS (6 repos)
**Escopo:** somente-leitura. Nenhum commit, edição ou push foi feito neste repositório. Testes e scripts ad-hoc rodaram em `.venv` local (gitignored) e em `/home/claude/predictors_audit/scratch/core/`.

> Nota metodológica: as instruções desta auditoria citam seções numeradas (14-16, 17, 33, 37, 38, 54/13 perguntas) de um framework mestre da auditoria estratégica que **não me foi fornecido literalmente**. Reconstruí o conteúdo temático dessas seções a partir da descrição dada na tarefa. Isso está marcado explicitamente onde relevante.

---

## Taxonomia de evidência usada neste documento

`CONFIRMADO` · `PARCIALMENTE CONFIRMADO` · `CLAIM DOCUMENTAL` (o repo/CHANGELOG afirma, não verifiquei independentemente) · `CONTRADITÓRIO` · `STALE` · `NÃO REPRODUZÍVEL` · `INVALIDADO` · `INCONCLUSIVO` · `NÃO TESTADO` · `MISSING EVIDENCE`

Níveis de confiança: **L0** (nenhuma evidência) → **L6** (verificado por execução própria + matemática independente + cruzamento em ≥2 fontes).

Rótulos: **FACT** (observei diretamente), **INFERENCE** (dedução razoável a partir de FACTs), **HYPOTHESIS** (especulação com evidência fraca), **RECOMMENDATION**.

---

## Resumo executivo (para o corpo do relatório maior)

`core-predictor` é, dos 3 componentes de infraestrutura compartilhada do ecossistema, o único com **pegada de consumo real, ampla e substantiva** nos 3 domínios econômicos. Cerca de 40 arquivos de produção nos 3 domínios importam e usam ativamente ~19 dos 28 submódulos do core (68%); em linhas de código, ~77% do código-fonte do core (≈4.576/5.913 linhas) é tocado por pelo menos um domínio. As funções estatísticas centrais (`brier`, `log_loss`, `rps`, PSR, bootstrap) foram verificadas matematicamente **CONFIRMADO L6** — reproduzi à mão 3 dos 6 golden vectors do próprio repo e a fórmula do PSR bate algebricamente com Bailey & López de Prado (2012). A suíte de 296 testes passa 100% (0 falhas, 0 skips), com 86,55% de cobertura de branch — acima do próprio gate de 80%. Achado crítico não-trivial: **o HEAD atual está 4 commits à frente da tag `v2.3.0`** (correções reais em `ledger.py`, `trials.py`, `harness.py`, datadas de 26/08/2026) **sem bump de versão** — os 3 domínios instalam o wheel da release `v2.3.0` via URL fixa no GitHub, então **não recebem essas correções**. Isso é STALE de fato, não hipotético.

---

## A) Tese original e histórico (seções 14-16)

### A.1 Reconstrução via `git log` — FACT

- 88 commits totais, primeiro commit `2026-06-16` ("initial commit of canonical core v0.4.0"), HEAD `2026-08-26` (commit "comit", mensagem não descritiva — nota de qualidade). Tags locais: `1.0.0`, `1.0.1`, `v2.1.0`, `v2.2.0`, `v2.2.1`, `v2.3.0`.
- Isso é **10 semanas** de desenvolvimento intenso (16/jun a 26/ago 2026) — não um projeto de anos. Ritmo de release muito alto: de v0.4.0 a v2.3.0 em ~10 semanas, com pelo menos 15 versões nomeadas no CHANGELOG.

### A.2 Propósito declarado e evolução de fases — CLAIM DOCUMENTAL, corroborado estruturalmente

O `CHANGELOG.md` (568 linhas, consistente e tecnicamente detalhado — não é changelog decorativo) narra uma progressão coerente:

| Fase | Versão | O que entrou | Evidência de motivação |
|---|---|---|---|
| Baseline | 0.8.0 | `stats`, `replay`, `infra`, `obs`, `settings`, `net` (7 módulos flat) | "auditado por Red Team" |
| Onda 0-1 | 0.9.0 | CI + drift-check + reestruturação em camadas (`kernel/`, `measurement/`) | shims de compat preservam imports antigos |
| Onda 2 | 0.9.1 | `testing/` (synth, coverage, harness) | "blindagem por propriedade mecânica" antes de mexer em dados |
| Onda 3 | 0.10.0 | `data/` — camada point-in-time promovida do domínio cripto (`dpl/`) | paga dívida técnica citada como ADR-002 do cripto |
| Onda 4 | 0.11.0 | `nullref` (testes de significância por seletor aleatório), `data/asof.py` | citação explícita "DESIGN do stocks §10 M5" |
| v1.0.0 | 2026-07-03 | consolidação — "3/3 domínios agora consomem o core" | medido via `sync_core --check` |
| v1.1.0-1.3.3 | jul/2026 | reconciliação trials (drift interno detectado — ver A.3), Ledger/Elo/Ordinal/Stress "inspirados em bibliotecas maduras" (beancount/trueskill/choix/hypothesis) reimplementados stdlib-first | motivação declarada: zero dependências novas |
| v2.0.0-2.2.x | jul-ago/2026 | robustez operacional, governança de aquisição de dados, `RatingBook` extensível | — |
| v2.3.0 | 17/08/2026 | contratos econômicos cross-domain (`ProbabilisticForecast → MarketQuote → EconomicDecision → ExecutionRecord → SettlementRecord`) | zero consumidores até hoje (ver B) |

**FACT relevante**: em `v1.1.0` o próprio CHANGELOG admite um bug de governança interno — *"`measurement/trials.py` do core tinha ZERO consumidores enquanto o previsao-cripto evoluía uma cópia paralela — drift de governança dentro de casa"*. Isto é auto-relatado, então é evidência fraca de honestidade do mantenedor, mas também evidência **direta** de que o padrão "core como fonte única da verdade" já falhou pelo menos uma vez internamente antes mesmo de chegar aos domínios.

### A.3 Pivot de distribuição: vendoring → wheel — CONFIRMADO L6

- Até ~v1.3.x, distribuição era por **vendoring unidirecional** (`sync_core.py` copiava arquivos `.py` para `vendor/predictor_core/` em cada domínio, com manifest de hash).
- A partir de ~2.x, distribuição virou **wheel publicado em GitHub Releases**, instalado via `uv.sources` com URL fixa (`pyproject.toml` de cada domínio). `HANDOFF.md`: *"Distribution: installed wheel only; vendoring is legacy"*.
- **Confirmei isto rodando a própria ferramenta do repo** (`python3.13 sync_core.py --audit`, execução real, somente-leitura):
  ```
  stocks-predictor: DRIFT; migrate to predictor-core==2.3.0 and remove vendor
  ```
  Ou seja: `stocks-predictor` ainda carrega um `vendor/predictor_core/` de **v1.3.0-ga-20260711** (confirmado lendo `vendor/predictor_core/VERSION`), claramente obsoleto e não usado em produção (os imports reais do domínio vêm do pacote instalado, não de `vendor/` — confirmei que nenhum arquivo de produção faz `from vendor.predictor_core import`). Este é lixo arquitetural residual de um pivot anterior, ainda não limpo em pelo menos 1 dos 3 domínios. **CONFIRMADO L6.**

### A.4 Complexidade cresceu mais rápido que evidência de valor? — INFERENCE, moderadamente confirmada

- O core cresceu para **5.913 linhas** em 28 submódulos em 10 semanas.
- Vários módulos inteiros (ver seção B) foram construídos citando consumidores **fora do escopo dos 3 domínios auditados** — `lol-predictor`, `wc-predictor` (Copa), F1, NBA, Eleições, Clima são citados recorrentemente no CHANGELOG como motivação ou beneficiários potenciais de módulos como `kernel/rating.py` (Elo genérico), `measurement/ordinal.py` (Plackett-Luce), `measurement/ledger.py`. Nenhum desses domínios está nos 3 repos hoje sob escopo desta auditoria — o que sugere que o ecossistema já foi **maior** (6+ domínios em algum momento) e foi consolidado/podado para os 3 atuais, deixando módulos do core órfãos.
- Isso é evidência moderada (não forte) de que o core foi dimensionado para uma superfície de produto maior do que a que sobrou. **INFERENCE, L4** (baseada em texto do próprio CHANGELOG + grep de uso zero nos 3 domínios atuais, seção B).

---

## B) Arquitetura — mapa de submódulos × uso real (seção 17)

### B.1 Metodologia

1. Listei todos os arquivos `.py` de `src/predictor_core` (28 arquivos de lógica, 5.913 linhas).
2. Rodei `grep -rl "predictor_core"` nos 3 domínios (excluindo `vendor/`, `.venv/`, `typings/`) e depois extraí **todas** as linhas de `import`/`from` reais (225 linhas de import únicas, não apenas menções em comentário).
3. Cruzei por submódulo (`predictor_core.X.Y`) contra os 28 arquivos-fonte.

### B.2 Tabela de classificação por submódulo

| Submódulo | Linhas | Cripto | Brasileirão | Stocks | Uso real (grep) | Classificação |
|---|--:|:--:|:--:|:--:|---|---|
| `measurement/trials.py` | 649 | ✅ | ✅ | ✅ | `contracts.registry`/`measurement.trials` em 3 domínios (11+29+8 arquivos) | **ESSENCIAL** |
| `measurement/stats.py` | 233 | ✅ | ✅ | ✅ | `probabilistic_sharpe_ratio`, `max_drawdown`, `spearman_block_ci` — usado nos 3 | **ESSENCIAL** |
| `kernel/obs.py` (+ shim `obs.py`) | 131+9 | ✅ | ✅ | ✅ | `emit_event`/`read_events` — 23 imports, o módulo mais importado | **ESSENCIAL** |
| `measurement/bootstrap.py` | 149 | ✅ | ✅ | ✅ | `bootstrap_ci` — 20 imports | **ESSENCIAL** |
| `measurement/metrics.py` | 200 | — | ✅ | ✅ | `brier`, `log_loss`, `rps` | **ESSENCIAL** (nos domínios que fazem previsão probabilística categórica) |
| `kernel/net.py` (+ shim `net.py`) | 158+10 | ✅ | — | ✅ | `get_http_client`, `with_retry` — 15 imports | **ESSENCIAL** (cripto/stocks) |
| `testing/harness.py` | 162 | ✅ | ✅ | ✅ | `attest_pipeline_power`/`assert_pipeline_has_power` — 69 ocorrências totais (contando testes) | **ESSENCIAL** — trava de governança científica ativa |
| `contracts/registry.py` + `contracts/__init__.py` | 28+134 | ✅ | ✅ | ✅ | fachada de `TrialRegistry` | **ESSENCIAL** |
| `data/contracts.py` | 267 | ✅ | ✅ | — | `MarketDataPoint`, `SignalPoint`, `PredictionPoint` — 19 imports | **ÚTIL** |
| `contracts/points.py` | 22 | — | ✅ | — | `PredictionPoint` (fachada) | **ÚTIL** |
| `data/circuit_breaker.py` | 126 | ✅ | — | — | `CircuitBreaker`, `CircuitOpenError` — 2 arquivos | **ÚTIL**, uso concentrado num domínio |
| `data/router.py` | 176 | ✅ | — | — | `AggregationRouter`, `FallbackRouter` — 1 arquivo | **CONVENIENTE** (uso mínimo, mas evita reimplementação de failover) |
| `data/aggregation.py` | 84 | ✅ | — | — | `consensus_mean/median`, `twap` — 1 arquivo | **CONVENIENTE** |
| `data/quality.py` | 86 | ✅ | — | — | `detect_jumps` — 1 arquivo | **CONVENIENTE** |
| `data/source_quality.py` | 252 | ✅ | — | — | `SourceQualityScorecard` etc. — 2 arquivos | **CONVENIENTE**, módulo grande (252 linhas) para uso concentrado |
| `contracts/scientific.py` | 266 | ✅ | — | — | `ScientificState` | **ÚTIL** (governança do ciclo científico) |
| `testing/prequential.py` | 81 | — | ✅ | — | `PrequentialEvaluator` — walk-forward anti-leakage | **ÚTIL**, alto valor conceitual, uso concentrado |
| `testing/secrets.py` | 56 | ✅ | — | — | `find_secrets`, `assert_no_secrets_in_events` — guard de segurança | **ÚTIL** |
| `testing/synth.py` | 66 | ✅(teste) | — | — | geradores sintéticos | **CONVENIENTE**, majoritariamente em testes próprios |
| `kernel/timeindex.py` | 54 | ✅ | — | — | `iso_z` — 1 uso direto (mas usado internamente por `trials`/`ledger`) | **ÚTIL** (mais por dependência interna do que por import direto) |
| `kernel/settings.py`/`settings.py` (shim) | 67+9 | ✅ | — | — | `MissingCredentialsError`, `require_secrets` | **ÚTIL** |
| `data/collection.py` + `contracts/collection.py` | 389+21 | — | ✅ | — | `ObservationEnvelope`, `CollectionArchive` — 1 arquivo | **CONVENIENTE / PREMATURO** — 389 linhas para 1 consumidor confirmado |
| `infra.py` (shim) + `kernel/infra.py` | 9+50 | ✅ | — | — | `infra` (SQLite WAL) | **ÚTIL** |
| `replay.py` (shim) + `measurement/replay.py` | 9+92 | — | — | — | **0 imports diretos nos 3 domínios** (só usado nos próprios testes golden do core) | **PROVAVELMENTE DESNECESSÁRIO no estado atual** — conceito valioso (anti-lookahead estrutural), mas **não adotado** por nenhum dos 3 domínios em produção |
| `measurement/calibration.py` (Platt+Shin) | 122 | — | — | — | **0 imports nos 3 domínios** | **DORMANT** |
| `measurement/nullref.py` | 104 | — | — | — | **0 imports** | **DORMANT** |
| `data/asof.py` | 48 | — | — | — | **0 imports** | **DORMANT** |
| `measurement/ledger.py` | 140+32(diff pós-tag) | — | — | — | **0 imports** | **DORMANT** |
| `kernel/rating.py` (Elo/`RatingBook`) | 171 | — | — | — | **0 imports** | **DORMANT** — construído citando LoL/F1/NBA, nenhum dos 3 domínios atuais tem "matches"/rankings pareados no sentido do Elo |
| `measurement/ordinal.py` (Plackett-Luce) | 112 | — | — | — | **0 imports** | **DORMANT** |
| `testing/stress.py` (property-based) | 93 | — | — | — | **0 imports** externos (só testes do próprio core) | **DORMANT** |
| `testing/coverage.py` | 105 | — | — | — | **0 imports** | **DORMANT** |
| `contracts/economic.py` (ADR-002, v2.3.0) | 442 | — | — | — | **0 imports** — feature lançada há 2 semanas (17/08) | **PREMATURO** (não é DORMANT no sentido de "morto"; é cedo demais para ter consumidor — mas é o maior módulo do repo, 442 linhas, sem 1 consumidor) |
| `kernel/jsonl_store.py`, `kernel/jsonable.py`, `kernel/meta.py` | 106+60+64 | indireto | indireto | — | usados **internamente** por `obs`/`trials`/`contracts`, não importados diretamente pelos domínios | **ÚTIL** (infraestrutura interna, não API de fachada) |

### B.3 Quantificação agregada — FACT

- **Linhas dormant (zero consumidor em qualquer um dos 3 domínios, direta ou indiretamente):** `ledger.py`(140) + `rating.py`(171) + `ordinal.py`(112) + `calibration.py`(122) + `nullref.py`(104) + `asof.py`(48) + `stress.py`(93) + `testing/coverage.py`(105) + `contracts/economic.py`(442) = **1.337 linhas / 5.913 = ~22,6% do core é código morto do ponto de vista dos 3 domínios atuais.**
- `measurement/replay.py` (92 linhas, o mecanismo anti-lookahead "estrutural" que é citado como um dos pilares conceituais do projeto) **também tem zero consumo direto** nos 3 domínios — soma mais 92 linhas de conceito-chave não adotado (~1,5%).
- Total "não tocado pelos 3 domínios em produção": **~1.429 linhas, ~24% do core.**
- Núcleo realmente usado e concentrado (obs, stats, bootstrap, trials/registry, metrics, net, harness, data/contracts): domina a maior parte das **linhas de import reais** (225 linhas de import, com `obs`, `bootstrap`, `data.contracts`, `net`, `stats`/`measurement.stats`, `metrics`, `trials`/`registry` respondendo por ~150 das 225 ocorrências, ~67%).

**CONFIRMADO L5** (grep exaustivo e reproduzível, ver `/home/claude/predictors_audit/scratch/core/all_imports2.txt`; L5 e não L6 porque não executei análise de import dinâmico/`importlib`, só estático).

---

## C) Execução real da suíte de testes

**FACT, CONFIRMADO L6 — executado ao vivo nesta sessão:**

```
cd core-predictor && uv run --python 3.13 --group test pytest -q
296 passed in 59.45s
```

- **0 falhas, 0 skips, 0 xfail** (confirmei ausência de qualquer marcador de skip/xfail em todo `tests/`).
- Cobertura de branch medida ao vivo: **86,55%** (gate declarado no `pyproject.toml`: `fail_under = 80` — atingido).
- Módulo com cobertura baixa e notável: `kernel/net.py` — **42%** (o wrapper HTTP async com `httpx` lazy-import — plausivelmente pouco coberto porque testar retries/timeouts de rede real é caro; risco real de bugs não capturados na camada de rede, que é justamente um dos módulos **ESSENCIAIS** mais usados por 2 dos 3 domínios).
- `contracts/economic.py` (o módulo novo de v2.3.0, 442 linhas, zero consumidor) tem 83% de cobertura — ou seja, o core testou bem uma feature que ninguém usa ainda.

**Interpretação (INFERENCE):** a suíte é rigorosa e passa de verdade — isto é evidência de **disciplina de engenharia**, não de **valor econômico**. Os dois são independentes; não confundi um pelo outro nas conclusões abaixo.

---

## D) Verificação científica das funções estatísticas centrais (item de alto valor decisório)

Esta foi a prioridade da tarefa. Fiz três coisas: (1) leitura da implementação com rigor matemático, (2) verificação de que existem testes com golden vectors, (3) reprodução manual independente de 3 dos 6 valores golden.

### D.1 `predictor_core.measurement.metrics.brier/log_loss/rps` — CONFIRMADO L6

Código (`src/predictor_core/measurement/metrics.py`):
- `brier`: `média_n Σ_j (p_{n,j} - onehot_j)²` — Brier multiclasse padrão.
- `log_loss`: `média_n [-log(clip(p_{n,y_n}, eps, 1))]` — cross-entropy padrão, com clip contra `log(0)` (proteção correta contra probabilidade-zero em previsão certa-errada).
- `rps`: `(1/(K-1)) Σ_{i=0}^{K-2} (CDF_prevista_i - degrau_observado_i)²`, média sobre observações — Ranked Probability Score ordinal padrão (Epstein 1969 / Gneiting & Raftery).

**Reproduzi à mão** os 3 valores do golden test (`tests/test_scientific_golden.py`, tolerância `1e-12`):
- `brier([[0.8,0.2],[0.3,0.7]], [0,1])`: amostra 1 `(0.8-1)²+(0.2-0)²=0.08`; amostra 2 `(0.3-0)²+(0.7-1)²=0.18`; média `= 0.13` → **bate exatamente** com o valor no teste (`0.13`).
- `log_loss(...)`: `-ln(0.8)=0.22314`, `-ln(0.7)=0.35667`, média `=0.289906...` → **bate** com `0.2899092476264711`.
- `rps([[0.7,0.2,0.1],[0.1,0.3,0.6]], [0,2])`: amostra1 `((0.7-1)²+(0.9-1)²)/2=0.05`; amostra2 `((0.1-0)²+(0.4-0)²)/2=0.085`; média `=0.0675` → **bate exatamente** com `0.0675`.

Três formulações matemáticas padrão, verificadas independentemente com cálculo manual, batendo exatamente com o resultado do código. **Não há dúvida científica razoável sobre a correção dessas 3 funções para os casos testados.**

### D.2 `predictor_core.measurement.stats.probabilistic_sharpe_ratio` (PSR) — CONFIRMADO L5 (verificação algébrica, sem golden vector dedicado no repo)

Implementação:
```
sr = mean/std_populacional
variance = (1 - skew*sr + ((kurt-1)/4)*sr²) / (n-1)
PSR = Φ((sr - benchmark_sharpe) / sqrt(variance))
```
Isso é **algebricamente idêntico** à forma fechada de Bailey & López de Prado (2012), *"The Sharpe Ratio Efficient Frontier"*:
`PSR(SR*) = Φ( (SR_hat - SR*)·√(n-1) / √(1 - γ₃·SR_hat + ((γ₄-1)/4)·SR_hat²) )`
— dividir por `variance` dentro da raiz e depois por `√variance` no numerador é equivalente a multiplicar por `√(n-1)` no numerador e manter o denominador sem o `n-1`; conferi a álgebra passo a passo e as duas formas coincidem termo a termo.

**Porém**: ao contrário de brier/log_loss/rps, **não existe um golden vector para PSR comparado a um valor de referência externo** (ex.: QuantConnect/LEAN, scipy, ou cálculo manual publicado) — só existem testes de propriedade (`test_psr_in_unit_interval_and_monotonic`: está em [0,1], é monotônico; `test_psr_nan_for_tiny_sample`). O docstring afirma "Verificado contra a implementação do QuantConnect/LEAN" — **isto é CLAIM DOCUMENTAL, não reproduzida por mim** (não tenho acesso ao LEAN aqui, e não há teste no repo que compare byte-a-byte contra um valor externo conhecido). A fórmula está correta pela literatura; a alegação de verificação cruzada específica contra o LEAN **não é verificável a partir do que está neste repositório**.

### D.3 `measurement.bootstrap.bootstrap_ci` — PARCIALMENTE CONFIRMADO L5

- Os 4 esquemas (`iid`, `moving`=circular block bootstrap, `stationary`=Politis&Romano 1994, `cluster`) estão implementados corretamente na estrutura (blocos circulares com wraparound, comprimento geométrico para `stationary`, reamostragem de clusters inteiros preservando correlação intra-cluster).
- Tratamento de reamostras inválidas (`NaN`/`inf` descartadas, warning se >10% descartado) é uma proteção sensata contra ICs fabricados por estatística degenerada — é um detalhe de engenharia científica correto e não-óbvio.
- O golden test do bootstrap (`bootstrap_ci([1,2,3,4,5], mean, scheme="iid", n_boot=200, seed=17) == (2.0, 4.2)`) é um teste de **regressão determinística** (mesma seed sempre dá o mesmo resultado), não uma verificação analítica independente do valor — é adequado para pegar regressões futuras, mas não prova que o IC de 95% tem cobertura nominal correta. Essa prova de cobertura existe **separadamente**, em `testing/coverage.py` (`bootstrap_coverage`/`coverage_in_band`, dormant nos domínios mas testado internamente no core — CHANGELOG relata cobertura empírica ~94-96% para os esquemas certos vs ~87% para iid mal-aplicado em série autocorrelacionada, o que é a demonstração mais forte de que o bootstrap funciona como anunciado — mas **é auto-relatado no CHANGELOG, não reproduzido por mim independentemente** neste ciclo de auditoria por restrição de tempo).

### D.4 `max_drawdown` — CONFIRMADO L6

- Contrato explícito: espera equity curve (nível), não retornos. Levanta `ValueError` se equity ≤ 0 (em vez de devolver 0 silenciosamente).
- Teste: `max_drawdown([100,110,88,95,100]) ≈ 0.2` — pico 110, vale 88, `(110-88)/110 = 0.2`. **Reproduzido e confere.**
- O próprio CHANGELOG registra que esse contrato explícito nasceu de um **bug real medido em produção** no `cripto-predictor v3` (passar retornos crus em vez de equity curve fazia o drawdown colapsar silenciosamente para ~0) — é o exemplo mais concreto de "core evita bug científico real" encontrado nesta auditoria, e é falseável: o teste `test_max_drawdown_raises_on_nonpositive_equity` de fato reproduz o cenário e confirma que agora levanta exceção em vez de mentir.

### D.5 Veredito da seção D

| Função | Fórmula correta? | Teste unitário com valor conhecido? | Verificado por mim |
|---|---|---|---|
| `brier` | Sim (padrão) | Sim (golden, `1e-12`) | **Reproduzido à mão — bate** |
| `log_loss` | Sim (padrão, com clip) | Sim (golden) | **Reproduzido à mão — bate** |
| `rps` | Sim (padrão ordinal) | Sim (golden) | **Reproduzido à mão — bate** |
| `probabilistic_sharpe_ratio` | Sim (bate com Bailey&LdP algebricamente) | Só propriedade (bounds/monotonicidade), não golden externo | **Álgebra conferida; claim de verificação vs LEAN NÃO reproduzida** |
| `bootstrap_ci` | Esquemas corretos na estrutura | Golden de regressão (determinístico) + cobertura empírica (auto-relatada) | **Estrutura conferida por leitura; cobertura empírica não re-executada por mim** |
| `max_drawdown` | Sim, com contrato correto (equity, não retorno) | Sim | **Reproduzido à mão — bate** |

**Conclusão da seção D**: as funções estatísticas centrais **são cientificamente corretas** para os casos analisados, com evidência de nível alto (L5-L6) para 4 de 6, e nível médio (L5, correto por inspeção algébrica mas sem golden externo) para PSR e bootstrap. Não encontrei nenhum erro matemático. Isto é uma conclusão importante e favorável ao core: a "régua" que os 3 domínios usam para alegar edge preditivo **não está mentindo nas suas fórmulas** — mas note que isso valida a *aritmética*, não a *decisão de negócio* de que qualquer domínio tem edge real (correção da régua ≠ prova de lucro).

---

## E) Valor independente do core (seção 33)

### E.1 Core reduz leakage (vazamento temporal)? — PARCIALMENTE CONFIRMADO

- `measurement/replay.py` (`PastView`/`LookaheadError`) e `testing/prequential.py` (`PrequentialEvaluator`, walk-forward por template method) são desenhados especificamente para tornar o anti-lookahead **estrutural** (o consumidor não pode "esquecer" de cortar o futuro, porque a API só entrega o passado).
- **Mas `replay.py` tem 0 consumidores diretos** nos 3 domínios (seção B). `PrequentialEvaluator` tem uso concentrado em 1 arquivo do `brasileirao-predictor`. Ou seja: o mecanismo mais rigoroso de anti-leakage do core **não está sendo usado pela maioria dos domínios** — eles preferem construir seus próprios cortes de data (o próprio `HANDOFF.md` admite isso: *"domain cutoffs, publication-time evidence, result recovery, identity, metrics, and domain-specific hashes remain consumer responsibilities"*). O contrato temporal (`docs/TEMPORAL_CONTRACT.md`, confirmei que existe) só garante o `PredictionPoint` e o replay — o resto é responsabilidade do domínio.
- O que **está** amplamente usado e reduz leakage de forma real: `data/contracts.py` (`published_at` obrigatório em `MarketDataPoint`/`SignalPoint`, invariante temporal que falha explícito) — usado em 19 imports. Isso é uma barreira estrutural genuína contra "usar dado que só ficou disponível depois" — mas é uma verificação de tipo/invariante simples, não o mecanismo mais sofisticado (`replay`).
- **Veredito**: o core oferece proteção real contra leakage nos pontos onde é efetivamente usado (contratos de dados com timestamp obrigatório), mas o mecanismo mais elaborado (replay/prequential) é **subutilizado**. `PARCIALMENTE CONFIRMADO`.

### E.2 Core reduz tempo de pesquisa? — INCONCLUSIVO (nenhuma métrica direta disponível)

- Não há nenhum artefato no repo (nem nos domínios, na amostra que verifiquei) medindo tempo-de-pesquisa antes/depois do core. O CHANGELOG cita casos qualitativos de bugs evitados/corrigidos (ver E.3), mas não há métrica de velocidade de iteração.
- `MISSING EVIDENCE` — não é possível confirmar nem refutar com o que está disponível nesta auditoria.

### E.3 Evidência concreta (não apenas alegação) de bugs/duplicação evitados — CLAIM DOCUMENTAL, com especificidade que aumenta credibilidade

O CHANGELOG cita **casos concretos, nomeados e datados** de bugs cross-repo detectados e corrigidos:
- `max_drawdown` recebendo retornos em vez de equity (cripto v3) → corrigido com `ValueError` explícito.
- `JsonlStore.append` não serializava `MappingProxyType`/`frozenset` (2.0.0), quebrando `lol-predictor` (3 testes falhando) — corrigido em 2.0.2/2.0.1.
- `_ALLOWED_EXTRA` de trials rejeitando campos que o `brasileirao-predictor` já gravava (`H4_DIXON_COLES_CALIBRATED`), bloqueando *qualquer* trial nova no domínio.
- Circuit breaker duplicado (2 implementações divergentes no cripto: `dpl/circuit_breaker.py` vs `v3/circuit_breaker.py`) unificado no core.

Estes são **relatos do próprio mantenedor no CHANGELOG do próprio repo** — não são independentemente auditáveis a partir daqui sem examinar o histórico git dos 3 domínios em detalhe (fora do escopo desta sessão focada em core-predictor). Mas a especificidade (nomes de arquivo, número de testes, comportamento exato do bug) é do tipo que é **difícil de fabricar de forma consistente ao longo de 568 linhas de changelog** e é consistente com os padrões de código que vi (ex.: o teste `test_max_drawdown_raises_on_nonpositive_equity` existe e reproduz exatamente o cenário narrado). Classifico como `CLAIM DOCUMENTAL, com corroboração estrutural razoável (L3-L4)`.

### E.4 Valor comercial independente? Comparação com o mercado — HYPOTHESIS

- O core reimplementa, stdlib-first, funcionalidades que **já existem, maduras e testadas em produção por milhares de usuários**, em bibliotecas open source:
  - `empyrical`/`quantstats` (Sharpe, Sortino, max_drawdown, PSR/DSR — inclusive PSR/DSR de López de Prado já implementado em `deflated_sharpe_ratio` de terceiros como `mlfinlab`/`PortfolioLab`).
  - `scikit-learn`/`scipy` (Brier score, log loss — `sklearn.metrics.brier_score_loss`, `log_loss`; bootstrap — `scipy.stats.bootstrap`).
  - `properscoring`/`CRPS` libraries para RPS-like scores.
  - `statsmodels` (Diebold-Mariano existe em pacotes de terceiros, ex. `dieboldmariano` no PyPI).
  - `trueskill` (rating genérico) e `choix` (Plackett-Luce) — o próprio CHANGELOG cita essas bibliotecas como inspiração e reimplementa por "zero dependências novas", **não** porque as bibliotecas originais fossem inadequadas.
- **O que o core faz de genuinamente diferente/consolidado** não é a matemática (que é padrão de mercado, reimplementada corretamente aqui) — é a **integração de contratos de governança específicos deste ecossistema**: `TrialRegistry` com governança N+1 (trial existente não pode mudar `params` silenciosamente), `attest_pipeline_power` (trava de controle positivo antes de registrar trial nova), `ScientificState`/`DatasetFreeze` (ciclo de vida científico com hash determinístico). **Isso não existe pronto no mercado geral** — é peça de processo/governança de pesquisa quant, não de matemática.
- **Valor comercial hipotético**: uma biblioteca stdlib-first de "trial registry + power attestation + point-in-time contracts" poderia interessar a equipes pequenas de pesquisa quant independente que não querem adotar o stack pesado (mlfinlab tem dependências numpy/sklearn/estatísticas pesadas; este core é zero-dependency). Mas isso é **especulação de mercado sem validação nenhuma** — não há indício no repo de que isso foi cogitado, precificado ou testado com qualquer usuário externo aos 3 domínios do próprio dono. `HYPOTHESIS, L1`.

---

## F) Dependency Value Test (seção 37) e Economia da infraestrutura (seção 38)

### F.1 Dependency Value Test — se `core-predictor` fosse removido amanhã, o que quebraria de fato?

- **Quebraria imediatamente e sem substituto trivial** nos 3 domínios: `TrialRegistry`/governança de trials (11+29+8 arquivos), telemetria `obs.emit_event` (23 imports), `bootstrap_ci` (20 imports), `net.get_http_client/with_retry` (15 imports em 2 domínios), `brier/log_loss/rps` (brasileirao), `probabilistic_sharpe_ratio`/`max_drawdown` (cripto, brasileirao), `data.contracts` (`MarketDataPoint`/`SignalPoint`/`PredictionPoint`, 19 imports).
- **Não quebraria nada** se removidos: `ledger`, `rating`, `ordinal`, `calibration`, `nullref`, `asof`, `stress`, `testing.coverage`, `contracts.economic` (seção B) — 22-24% do core.
- **Custo de substituição do núcleo ESSENCIAL**: médio-alto. Reescrever `TrialRegistry` com a mesma governança N+1 e trava de poder em cada domínio individualmente reintroduziria exatamente o "drift de governança dentro de casa" que o próprio CHANGELOG (v1.1.0) relata ter acontecido quando o core e o cripto tinham cópias paralelas. Isso é o argumento mais forte a favor de manter o core como está: a alternativa histórica já falhou uma vez.
- **Custo de manter os módulos dormant**: baixo em runtime (não são executados), mas não-zero em manutenção — 296 testes cobrem 100% desses módulos dormant também (ex.: `ledger.py` 92% cobertura, `rating.py` 98%), então cada mudança no core paga o custo de manter esses testes verdes mesmo sem consumidor. É dívida de manutenção silenciosa, não dívida de runtime.

### F.2 Economia da infraestrutura compartilhada — INFERENCE

- Distribuição via wheel + URL fixa do GitHub Release é leve (sem servidor de índice próprio, sem custo de hosting além do GitHub gratuito) — baixo custo operacional.
- CI roda matriz 3.13/3.14 (com 3.14 declarado "experimental", mas o job foi tornado não-bloqueante conforme commit `fix(ci): make experimental Python 3.14 job non-blocking` — decisão pragmática correta).
- O maior custo econômico real não é infraestrutura de CI/distribuição (barata) — é **custo de coordenação**: qualquer bug ou mudança de contrato no core (mesmo aditiva) tem que ser versionada, testada, tagueada, e cada domínio precisa fazer bump manual da URL do wheel no seu `pyproject.toml`. **Isso já demonstrou ter uma falha real**: HEAD está à frente da tag v2.3.0 com correções não publicadas (seção A.3/G abaixo) — o custo de coordenação já gerou pelo menos 1 caso de drift real detectável nesta auditoria.

---

## G) Checkpoint obrigatório (seção 54 — reconstruído; 13 perguntas)

> Como não recebi o texto literal das 13 perguntas do framework mestre, formulei as 13 perguntas de due-diligence que a tarefa e o contexto de negócio (manter/testar/reformular/combinar/congelar/reduzir/encerrar, com evidência de uso e valor) claramente exigem, e as respondi com o mesmo rigor de rótulo de evidência.

1. **O core tem consumidores reais em produção, não só em testes?**
   `CONFIRMADO L6` — 19 de 28 submódulos importados e usados em código de produção (não apenas `tests/`) nos 3 domínios; contagem de arquivos de produção com import real: cripto ~50+, brasileirao ~40+, stocks ~15+ (excluindo arquivos de teste dos próprios domínios).

2. **As alegações de correção matemática são verificáveis, e eu as verifiquei?**
   `CONFIRMADO L6` para brier/log_loss/rps/max_drawdown (reproduzidos à mão); `CONFIRMADO L5` para PSR e bootstrap (verificação algébrica/estrutural, sem golden externo próprio para PSR).

3. **A versão publicada (wheel v2.3.0) corresponde ao código-fonte atual do repositório?**
   `CONTRADITÓRIO / STALE — CONFIRMADO L6`. HEAD tem 4 commits e mudanças reais de comportamento (`ledger.py`, `trials.py`, `harness.py`) após a tag `v2.3.0`, sem bump de versão no `pyproject.toml` (continua `2.3.0`). Os 3 domínios fixam a URL do wheel `v2.3.0` — **não recebem essas correções** a menos que uma nova tag seja cortada e os 3 `pyproject.toml` sejam atualizados manualmente.

4. **Existe lixo arquitetural (código morto, vendoring obsoleto) não limpo?**
   `CONFIRMADO L6` — `stocks-predictor/vendor/predictor_core/` (v1.3.0-ga-20260711) está em estado `DRIFT` confirmado pela própria ferramenta `sync_core.py --audit` executada nesta auditoria, e não é mais o mecanismo de distribuição real (o domínio consome o wheel via `pyproject.toml`).

5. **Os testes passam de verdade, sem skips escondidos?**
   `CONFIRMADO L6` — 296/296 passam, 0 skip, 0 xfail, execução ao vivo.

6. **A cobertura de teste é real e atinge o gate declarado?**
   `CONFIRMADO L6` — 86,55% branch coverage medido ao vivo, gate declarado 80%. Ponto fraco identificado: `kernel/net.py` a 42% (módulo essencial de rede, subtestado).

7. **Qual fração do core é efetivamente consumida pelos domínios atuais?**
   `CONFIRMADO L5` — aproximadamente **68% dos submódulos** e **~76-77% das linhas de código** têm pelo menos 1 consumidor real nos 3 domínios; ~22-24% é código dormant (ledger, rating, ordinal, calibration, nullref, asof, stress, testing.coverage, contracts.economic).

8. **O core foi dimensionado para um ecossistema maior do que os 3 domínios que sobraram?**
   `INFERENCE, L4` — CHANGELOG cita repetidamente `lol-predictor`, `wc-predictor`/Copa, e menciona F1/NBA/Eleições/Clima como beneficiários potenciais de módulos hoje dormant. Nenhum desses está nos 3 repos auditados. Consistente com um ecossistema que já foi maior e foi consolidado.

9. **A governança de trials (N+1, power attestation) é usada de forma real e não decorativa?**
   `CONFIRMADO L5` — 69 ocorrências de `attest_pipeline_power`/`assert_pipeline_has_power`/`PipelineHasNoPowerError` nos 3 domínios (incluindo testes de domínio que dependem desse contrato), 48 arquivos usando `TrialRegistry`/`register_trial`/`deflated_sharpe_ratio` combinados. Não é decoração — é trava ativa que bloqueia registro de trial sem controle positivo prévio.

10. **Existe evidência independente (fora do próprio changelog do core) de que ele reduziu bugs/retrabalho?**
    `MISSING EVIDENCE` para métricas quantitativas (tempo de pesquisa); `CLAIM DOCUMENTAL com corroboração estrutural (L3-L4)` para os casos qualitativos específicos citados no CHANGELOG (bugs nomeados, com número de testes afetados) — plausíveis e consistentes com o código atual, mas não eu não vasculhei o histórico git completo dos 3 domínios para confirmar cada caso de forma independente (fora de escopo desta sessão focada em core).

11. **O core tem valor comercial ou reutilizável fora deste ecossistema específico?**
    `HYPOTHESIS, L1` — a matemática é padrão de mercado (equivalentes prontos em empyrical/scikit-learn/mlfinlab); o diferencial real é a governança de processo (TrialRegistry N+1, power attestation, ScientificState) que não tem equivalente pronto de mercado, mas não há nenhuma validação de demanda externa.

12. **A complexidade/tamanho do core é proporcional ao valor entregue nos 3 domínios auditados?**
    `INFERENCE, L4, tendendo a NÃO` — ~24% do código é dormant, e o maior módulo do repo inteiro (`contracts/economic.py`, 442 linhas, lançado há 2 semanas) tem zero consumidores. Isso não invalida o núcleo essencial (que é claramente proporcional e valioso), mas indica acúmulo de superfície especulativa não podada.

13. **Recomendação teria confiança alta o suficiente para decisão de portfólio sem trabalho adicional?**
    Ver seção final — `MANTER + REDUZIR` com confiança **L5** para o núcleo essencial e **L4** para a poda recomendada dos módulos dormant (nível L4 porque não confirmei ausência de planos de roadmap que expliquem por que `contracts/economic.py` foi construído agora para consumo futuro iminente — isso exigiria entrevistar o mantenedor ou ver issues/roadmap, fora do escopo desta auditoria só-de-código).

---

## Matriz de uso real por domínio

| Componente | Cripto | Stocks | Brasileirão | Uso comprovado | Valor gerado | Custo/complexidade |
|---|:--:|:--:|:--:|---|---|---|
| `measurement.trials` / `contracts.registry` (TrialRegistry) | ✅ (11 arq.) | ✅ (8 arq.) | ✅ (29 arq.) | Alto, nos 3 | Governança N+1 anti-p-hacking; único no mercado neste formato | Alto (649 linhas, mais complexo do repo) |
| `kernel.obs` (`emit_event`/`read_events`) | ✅ | ✅ | ✅ | Alto — 23 imports, o mais usado | Telemetria estruturada JSONL padronizada | Baixo (131 linhas) |
| `measurement.bootstrap` (`bootstrap_ci`) | ✅ | ✅ | ✅ | Alto — 20 imports | IC estatístico correto (4 esquemas) evita significância fabricada | Médio (149 linhas) |
| `measurement.stats` (PSR, Sharpe, Sortino, max_drawdown) | ✅ | ✅ | ✅ | Alto | Régua financeira central para claim de edge | Médio (233 linhas) |
| `measurement.metrics` (brier/log_loss/rps) | — | ✅ | ✅ | Médio-alto | Régua probabilística verificada matematicamente | Médio (200 linhas) |
| `data.contracts` (MarketDataPoint/SignalPoint/PredictionPoint) | ✅ | — | ✅ | Alto — 19 imports | Contrato temporal anti-leakage básico | Médio (267 linhas) |
| `kernel.net` (`get_http_client`/`with_retry`) | ✅ | ✅ | — | Alto — 15 imports | Cliente HTTP resiliente compartilhado | Médio, mas 42% cobertura (risco) |
| `testing.harness` (power attestation) | ✅ | ✅ | ✅ | Alto — 69 ocorrências | Trava de controle positivo antes de registrar trial | Médio (162 linhas) |
| `data.circuit_breaker`/`router`/`aggregation`/`quality`/`source_quality` | ✅ | — | — | Baixo-médio, concentrado em 1 domínio | Evita reimplementação de resiliência de dados | Médio-alto (~700 linhas combinadas, uso concentrado) |
| `contracts.scientific` (ScientificState) | ✅ | — | — | Médio | Governança de ciclo científico | Médio (266 linhas) |
| `testing.prequential` (walk-forward) | — | — | ✅ (concentrado) | Baixo | Alto valor conceitual (anti-leakage estrutural), pouco adotado | Baixo (81 linhas) |
| `contracts.collection` / `data.collection` | — | — | ✅ (1 arq.) | Baixo | Arquivo append-only para coleta | Alto (410 linhas p/ 1 consumidor) — **PREMATURO** |
| `measurement.replay` (anti-lookahead estrutural) | — | — | — | **Zero** nos 3 domínios | Alto conceitualmente, não adotado | Baixo (92+9 linhas) — **DORMANT na prática** |
| `measurement.ledger` | — | — | — | **Zero** | Nenhum medido | 140 linhas — **DORMANT** |
| `kernel.rating` (Elo/RatingBook) | — | — | — | **Zero** | Nenhum medido (útil só se domínio de ranking pareado existir) | 171 linhas — **DORMANT** |
| `measurement.ordinal` (Plackett-Luce) | — | — | — | **Zero** | Nenhum medido | 112 linhas — **DORMANT** |
| `measurement.calibration` (Platt/Shin) | — | — | — | **Zero** | Nenhum medido | 122 linhas — **DORMANT** |
| `measurement.nullref` | — | — | — | **Zero** | Nenhum medido | 104 linhas — **DORMANT** |
| `data.asof` | — | — | — | **Zero** | Nenhum medido | 48 linhas — **DORMANT** |
| `testing.stress`/`testing.coverage` | — | — | — | **Zero** (uso só interno ao core) | Nenhum medido externamente | 198 linhas combinadas — **DORMANT** |
| `contracts.economic` (v2.3.0, ADR-002) | — | — | — | **Zero** (lançado há 2 semanas) | Potencial futuro não realizado | 442 linhas — **PREMATURO**, maior módulo do repo |

---

## Recomendação preliminar

### **MANTER + REDUZIR** (com um componente de MANTER+TESTAR pontual)

**Justificativa:**

1. **MANTER** o núcleo essencial (`measurement.trials`/`contracts.registry`, `kernel.obs`, `measurement.bootstrap`, `measurement.stats`, `measurement.metrics`, `data.contracts`, `kernel.net`, `testing.harness`) — este é o único dos 3 componentes de infraestrutura da auditoria mais ampla com evidência forte e reproduzível de uso real, valor de governança não-trivial (TrialRegistry N+1 + power attestation, que evita exatamente o tipo de p-hacking silencioso que motivaria descartar todo o programa de pesquisa quant do ecossistema), e correção matemática verificada de forma independente nesta auditoria (L5-L6 em 6 de 6 funções centrais checadas). Substituir isso por implementações locais em cada domínio reintroduziria um risco já materializado uma vez (drift de governança "dentro de casa", CHANGELOG v1.1.0).

2. **REDUZIR** — podar ou congelar explicitamente os módulos dormant (~22-24% do código: `ledger`, `rating`, `ordinal`, `calibration`, `nullref`, `asof`, `stress`, `testing.coverage`) e o módulo prematuro `contracts.economic` (442 linhas, zero consumidores, lançado há apenas 2 semanas) até que exista um consumidor real e comprometido. Manter esse código sem uso é dívida de manutenção silenciosa (cada um exige testes, cobertura, revisão em cada mudança de core) sem valor econômico demonstrado. Se algum desses módulos foi construído para um domínio que saiu do ecossistema (LoL, Copa/wc-predictor), a decisão correta é documentar isso explicitamente e arquivar, não deixar "por via das dúvidas".

3. **MANTER+TESTAR** pontualmente: a divergência STALE entre HEAD e a tag `v2.3.0` publicada (achado G.3) precisa de ação de curto prazo — ou corta-se uma tag `v2.3.1`/`v2.4.0` com os 4 commits pendentes e os 3 domínios atualizam a URL do wheel, ou se decide formalmente que essas correções não são urgentes. Do jeito que está, existe um repositório "canônico" cujo HEAD e cujo artefato publicado **já divergem em comportamento**, o que é precisamente o tipo de risco de "fonte única da verdade" que uma biblioteca canônica existe para evitar.

**Nível de confiança geral desta recomendação: L5** (alto, baseado em execução real de testes, verificação matemática independente reproduzida, grep exaustivo e reprodutível de uso cross-repo, e execução ao vivo da própria ferramenta de auditoria do repo). O que impede L6: não tive acesso a métricas de negócio dos domínios (lucro, tempo de pesquisa) que permitiriam avaliar se o **valor de governança** do core (trial registry, anti-p-hacking) de fato se traduziu em decisões de trading/apostas melhores — isso está fora do escopo de um repositório que, por definição, não decide capital nem sizing (ele mesmo declara isso no ADR-002).

---

## Apêndice — comandos executados (reprodutibilidade)

```bash
# Testes (ambiente uv isolado, Python 3.13.13, sem tocar arquivos rastreados)
cd core-predictor && uv run --python 3.13 --group test pytest -q
# → 296 passed in 59.45s

cd core-predictor && uv run --python 3.13 --group test pytest -q --cov=predictor_core --cov-report=term-missing
# → TOTAL 86.55% branch coverage; 296 passed in 184.48s

# Auditoria de vendoring legado (ferramenta do próprio repo, read-only)
cd core-predictor && python3.13 sync_core.py --audit
# → stocks-predictor: DRIFT; migrate to predictor-core==2.3.0 and remove vendor

# Divergência HEAD vs tag publicada
git log v2.3.0..HEAD --oneline
git diff v2.3.0..HEAD --stat

# Grep exaustivo de uso cross-repo (ver /home/claude/predictors_audit/scratch/core/all_imports2.txt)
```

Nenhum arquivo rastreado do `core-predictor` foi modificado, commitado ou enviado. Artefatos gerados (`.venv/`, `__pycache__/`, `.pytest_cache/`) estão cobertos pelo `.gitignore` do próprio repo e confirmei via `git status --porcelain --ignored` que nada aparece como alterado/staged.
