# Auditoria — `cripto-predictor` (GarimpoInvestimentos + DPL)

**Auditor:** sessão independente de auditoria técnica/estatística/econômica, escopo único: repositório `cripto-predictor`.
**Repositório:** `/home/claude/predictors_audit/cripto-predictor`, branch `main`, HEAD `c2222586cfef0391e2360df970fed7a86f03027a`, congelado em 2026-08-31.
**Método:** leitura de código e documentos + execução real de `uv sync`, `pytest`, `attest_harness.py --dry-run`, `psr_nonoverlap.py`, `git log`. Nenhum arquivo rastreado foi editado; nenhum commit foi feito. Scripts auxiliares (nenhum necessário além dos comandos nativos do projeto) ficariam em `/home/claude/predictors_audit/scratch/cripto/` — diretório criado, não usado, pois os comandos nativos já bastaram para a verificação.

## 0. Escala de evidência (L0–L6) e taxonomia

| Nível | Significado |
|---|---|
| L0 | Nenhuma evidência — menção sem lastro |
| L1 | Claim documental (afirmado em HANDOFF/docs/README, não verificado por mim) |
| L2 | Código existe e implementa o mecanismo descrito (li o código) |
| L3 | Teste automatizado (unitário/sintético) passa, verificado por mim ao rodar a suíte |
| L4 | Reproduzido por mim com dados sintéticos/controle positivo (mecanismo comprovadamente funcional) |
| L5 | Reproduzido por mim com dados reais de mercado (não foi possível neste ambiente — ver §D) |
| L6 | Confirmado prospectivamente/em produção com dados coletados após o registro da hipótese (parcialmente possível via `h6_status.json`, mas não recalculável por mim) |

Taxonomia de veredito por claim: **CONFIRMADO** (reproduzi eu mesmo) · **PARCIALMENTE CONFIRMADO** · **CLAIM DOCUMENTAL** (só o repositório diz) · **CONTRADITÓRIO** (documentos divergem entre si) · **STALE** (verdadeiro no passado, hoje desatualizado) · **NÃO REPRODUZÍVEL** (faltam dados/ambiente) · **INVALIDADO** (o próprio projeto refutou) · **INCONCLUSIVO** · **NÃO TESTADO** · **MISSING EVIDENCE**.

Rótulos usados no texto: **FACT** (verificado por mim), **INFERENCE** (dedução minha a partir de fatos), **HYPOTHESIS** (conjectura minha, não verificada), **RECOMMENDATION**.

---

## A. Tese original e histórico real

**FACT (L2, CONFIRMADO por `git log`)** — 297 commits no histórico completo (`--all`), 279 na `main` linear até HEAD conforme enunciado; primeiro commit `40fd804` ("initial commit - Garimpo (cripto)"), consumindo `predictor_core` via vendor. Ritmo por semana ISO 2026: semana 24→22, 26→42, 27→32, 28→35, 29→19, 30→23, 31→32, 32→8, 33→52 (pico, fechamento de auditoria + PBO/CSCV + fator DSL), 34→14 (últimos commits, correções quantitativas). Ritmo extremamente alto para um projeto de pesquisa solo com IA como par de programação — compatível com "muito código, pouco tempo decorrido de mercado real".

**FACT (L1→L2, CONFIRMADO)** — O nome `GarimpoInvestimentos` (garimpo = prospecção artesanal de minério) é literal: o projeto nasceu (HANDOFF.md, pré-DPL, junho/2026) como pipeline CoinGecko+SerpAPI→Gemini→score→CSV ("Garimpo Fase 1"), e evoluiu por **sucessivas camadas de garimpagem de sinal**, cada uma abandonando ou revalidando a anterior:

1. **Fase 1 / LLM direto** (jun/2026): score do LLM sobre indicadores+notícias → CSV.
2. **Integração ao `predictor_core`** (16-17/06): Spearman+IC95%, carimbo do "Juiz", trava de credenciais.
3. **V3 quantitativa** (27/06): HMM de regimes + funding/OI + walk-forward. GO inicial (PSR 0,909) **pré-custos e pós kelly-sweep** — isto é, um resultado favorável nascido de uma varredura de parâmetros sem custo de transação, revertido dias depois.
4. **DPL — Data Provider Layer** (27-30/06): bitemporalidade, Feature Store, anti-lookahead, Circuit Breaker, fallback multi-fonte.
5. **Merge DPL+discovery, DSR, controle positivo, equivalência DPL-vs-direto** (01-02/07).
6. **V3 com custos completos → NO-GO líquido** (02/07): fecha a primeira família de hipóteses (funding/OI+HMM).
7. **H4/H5 — LLM prevê retorno D+7** (jul/2026, multi-provedor): NO-GO com IC negativo e significativo.
8. **H6 — inversão do sinal do LLM** (20/07-presente): pesquisa em coleta, imatura.
9. **H7 — calendário macro + DXY** (14/08): infraestrutura pronta, coleta nunca iniciada.
10. **Camada `trading/`** (14/08): execução, microestrutura, portfólio — construída **sem** nenhum edge validado, por decisão explícita do dono contra o próprio protocolo do projeto (ver §E).
11. **B9 — LLM como gerador de hipóteses (DSL de fatores) + B10 (PBO/CSCV)** (21/08): infraestrutura nova de meta-pesquisa, sem hipótese ainda registrada.
12. **Trend-following spot 4h e SMA200 diário** (17-27/08): duas hipóteses novas e mais simples, testadas retrospectivamente — **ambas rejeitadas no gate** (ver observation_reports).
13. **Correções quantitativas finais** (#63-#66, 27-28/08): stop-loss/take-profit (não testado contra dado real), correção de contabilidade de MaxDD/equity (dois ciclos de correção, o segundo revertendo um erro do primeiro), Sortino/Calmar.

**INFERENCE** — Este é um padrão de **pivô repetido dentro do mesmo domínio** (cripto), não um único experimento: pelo menos 4 famílias de hipóteses distintas (HMM+funding/OI; LLM+score D+7 direto; LLM+score D+7 invertido; trend-following técnico simples) foram tentadas em 2,5 meses, todas fracassando no critério líquido de custos ou não amadurecendo. Isso é coerente com "garimpo" — testar veios de minério até achar (ou não) um que compense escavar.

---

## B. Tabela de reconstrução de hipóteses (prioridade máxima desta auditoria)

Fonte primária: `docs/HYPOTHESES.md` + `GarimpoInvestimentos/trials.json` + `charters/scientific_state.json` + `observation_reports/*.json`. Contra-verificação: leitura de código e (onde possível) execução.

| Hipótese | Claim original | Evidência encontrada | Resultado reproduzido? | Edge bruto | Edge líquido | Prospectivo? | Estado após auditoria |
|---|---|---|---|---|---|---|---|
| **H1** — Funding/OI z-score × HMM prevê retorno 24h (BTC/ETH) | Desequilíbrio de alavancagem condicionado a regime prevê retorno spot 24h; PSR≥0,80 líquido de custos | `trials.json`: `v3-hmm-funding-oi-fr90`, n=3.958 OOS (BTC) | **NÃO REPRODUZÍVEL por mim** (dados brutos não estão no repo/ambiente); CLAIM DOCUMENTAL bem registrado, com reconfirmação independente citada (WFA re-rodado em base estendida 2021→jul/2026, `docs/RETROACTIVE_QUALITY_2026-08-27.md`, PSR 0,1546, IC −0,0944) | +0,44bps/sinal (versão original) | **−0,09bps/sinal** (BTC); ETH pior | Não — só retrospectivo | **INVALIDADO** (NO-GO, família congelada em `frozen_families`) |
| **H2** — Janela curta de funding (fr21) melhora sensibilidade | z-score 7d reage mais rápido a squeezes | `v3-hmm-funding-oi-fr21` | NÃO REPRODUZÍVEL (dado ausente); CLAIM DOCUMENTAL consistente com reexecução 2026-08-27 (PSR 0,2873) | +0,07bps/sinal | **−0,37bps/sinal**, MaxDD 25,8% | Não | **INVALIDADO** |
| **H3** — Horizonte 48h amortiza fricção fixa | Dobrar horizonte dobraria edge/sinal mantendo custo ~constante | `v3-hmm-funding-oi-fr90-h48` | NÃO REPRODUZÍVEL (dado ausente); reexecução 2026-08-27 confirma NO-GO (Spearman −0,0026, MaxDD 23,57% na reprodução; −0,35bps bruto na versão original) | **negativo** (edge bruto vira negativo) | **−0,75bps/sinal**, MaxDD 50,3% | Não | **INVALIDADO** — resultado informativo (aprendizado: sinal de vida curta, não esticar horizonte) |
| **H4** — Score LLM prevê retorno D+7 (Gemini único, DPL) | Correlação positiva score×retorno D+7 | `v2-dpl-gemini-h7`, n=5 | Coleta interrompida por decisão do dono (risco de estouro de cota) antes de maturar | n/d (n=5, imaturo) | n/d | Parcial (coleta real, mas insuficiente) | **NÃO TESTADO / amostra insuficiente** — corretamente rotulado como tal, não forçado a veredito |
| **H5** — Score LLM prevê retorno D+7, multi-provedor (partição fixa 4 juízes) | Idêntica à H4, agora com 4 LLMs | `v2-dpl-multi-h7`, n=440 (D+7 pooled) | CLAIM DOCUMENTAL detalhado (Spearman −0,166 [IC95 −0,266;−0,057], Sharpe/trade −0,312, DSR 0,00, acurácia direcional 45,2%, estratégia perde do buy&hold −6,80% vs +0,99%) — **não reproduzível por mim** (dados brutos da H5 estão **perdidos**, conforme o próprio projeto declara: `HISTORICAL_REPRODUCIBILITY=LIMITED`) | −0,166 IC fora de zero, **na direção oposta** à hipótese | **negativo e significativo** | Não (retrospectivo, coleta real mas já encerrada) | **INVALIDADO** — é a quarta encarnação da família LLM-score-D7 a terminar em correlação negativa ou nula (v1, H4, H5) |
| **H6** — Sinal **invertido** do LLM prevê D+7 | Score alto = queda; score baixo = alta (post-hoc a partir do padrão negativo da H5) | `h6-sinal-invertido-d7`; `h6_status.json` último commitado: `n=0` em 2026-08-24T07:01:23Z | CONFIRMADO que `n=0` no artefato versionado mais recente do repositório — não há evidência de maturação além disso | Sharpe auxiliar +0,3479 com **n=6** (não é veredito; gate exige n≥30) | n/d | **Prospectivo por desenho** (trava anti-data-snooping: só aceita `pred_date` posterior a `registered_at`) mas **imaturo, sem dado suficiente até a última leitura versionada** | **COLETANDO / IMATURO**. Risco de origem: a hipótese nasceu observando o resultado negativo da H5 — registrado como viés honesto, não eliminável por pré-registro do critério |
| **H7** — Calendário macro (FOMC/CPI/PPI) + DXY como regime exógeno | Eventos macro e DXY carregam informação sobre regime de risco cripto | Infraestrutura implementada (`dxy.py`, `macro_calendar.py`), CPI/PPI vazios, `fetch()` do DXYProvider nunca confirmado ponta-a-ponta em produção pelo auditor (só pelo dono, uma vez) | **Nenhum dado coletado.** Zero backtests, zero trial em `trials.json` | n/d | n/d | Não | **REGISTRADA, NÃO ATIVADA** — infraestrutura sem experimento |
| **Trend-following spot 4h** (BTC/ETH, MA de 42 barras) | Long acima da média móvel, cash abaixo | `charters/trend_following_spot_4h_v1.json` (DRAFT_NOT_REGISTERED) | Testada como pesquisa retrospectiva em 2026-08-27: bruto +54,2%, **líquido −62,0%**, Sharpe líquido −0,45, MaxDD 74,9% | +54,2% (2021-2026, bruto) | **−62,0%** | Não (retrospectivo; nunca virou trial) | **REJEITADO antes mesmo de registrar** — turnover destrói o candidato |
| **SMA200 diário long/cash** (`spot_daily_trend_long_cash_v1`) | Tendência de longo prazo simples | `observation_reports/spot-daily-trend-replication-v1-retrospective.json`, `status: RETROSPECTIVE_GATE_FAILED` | **CONFIRMADO por leitura direta do artefato JSON**: BTC líquido +94,7% vs buy&hold +103,9% (perde); ETH líquido +230,5% vs buy&hold +2,4% (ganha, mas ETH é outlier de período); ambos IC95 da média líquida cruzam zero; ambos MaxDD >30% (36,4%/38,5%) | Positivo em nível absoluto, mas **gate_passed: false** em ambos os ativos | Positivo nominal, **não significativo** | Não (retrospectivo; nota explícita "capital permanece não autorizado qualquer que seja o resultado") | **GATE FALHOU** — retorno economicamente "interessante" à vista, mas reprovado no critério pré-registrado (não bate buy&hold em BTC, IC cruza zero nos dois ativos, drawdown excessivo) |
| **Kelly-sweep (H1, pré-custos)** | Varredura de fração de Kelly melhoraria o resultado do H1 | Citada em HANDOFF-2026-07-02 ("GO histórico de 27/06, PSR 0,909, pré-custos e pós kelly-sweep") | Não é uma trial nomeada em `trials.json` — **não conta no denominador N=7 do DSR** | PSR 0,909 pré-custos (não confiável) | Não avaliado líquido nesta forma | Não | **SUPERADO/DESCARTADO** — o próprio projeto reconhece que era um resultado inflado por varredura de parâmetro sem custos; corrigido pelo NO-GO líquido de H1 |
| **B9 — LLM propositor de hipóteses (DSL de fatores) + hypothesis_loop** | LLM propõe, motor determinístico avalia (contra alpha decay) | `analyzers/factor_dsl.py`, `analyzers/hypothesis_loop.py` implementados; DSL com "prova de não-leakage" via teste de invariância | Infraestrutura existe e testes de invariância passam (rodei a suíte completa); **nenhum registro em `trials.json`, nenhum dado coletado** | n/d | n/d | Não | **INFRAESTRUTURA SEM EXPERIMENTO** — o próprio HYPOTHESES.md admite: "enquanto (3) e (4) não acontecerem, rodar o laço produz observação exploratória, não hipótese" |

**Observação sobre completude do espaço de busca:** os itens acima cobrem todas as hipóteses **nomeadas** que encontrei em `trials.json`, `HYPOTHESES.md`, `charters/` e `observation_reports/`. Não posso garantir que este é o espaço de busca **completo** de tudo que foi tentado informalmente (scripts ad-hoc, notebooks, experimentos em máquina do dono nunca commitados) — o próprio `HANDOFF-2026-08-14.md` menciona ambiente de desenvolvimento sem acesso à rede/dados reais em várias sessões, o que sugere que boa parte da exploração empírica ocorreu **fora deste ambiente auditável, na máquina do dono**, e chega ao repositório já resumida em documentos. **Rotulo isso explicitamente: UNKNOWN RESEARCH SEARCH SPACE — risco de overfitting elevado**, ainda que o mecanismo de DSR/trials.json seja honesto para o que **está** registrado. A varredura de kelly (H1) e o novo `run_threshold_grid` (commit #63, também não testado contra dado real) são evidência concreta de que buscas de parâmetros **internas a uma única trial nomeada** ocorrem e não são contadas no N do DSR — subestimando a correção por múltiplos testes.

---

## C. Reprodução de claims de maior valor — o que rodei de fato

**FACT (CONFIRMADO, L3)** — `uv sync --locked --extra test` instala corretamente em Python 3.13.13 (o ambiente tinha `uv` e Python 3.13/3.12 disponíveis além do 3.11 padrão). As wheels externas `predictor-core==2.3.0` e `predictor-ops==3.1.0` foram baixadas com sucesso das GitHub Releases do próprio autor — a rede do ambiente de auditoria permitiu isso (diferente do relatado nos HANDOFFs, onde sessões anteriores de Claude Code tinham rede bloqueada).

**FACT (CONFIRMADO, L3)** — `uv run pytest -q`: **832 passed, 2 skipped em 172,46s**. Os 2 skips são os mesmos historicamente citados (numpy/hmmlearn não instalados fora do extra `v3`). O número (832) é **maior** que qualquer contagem citada nos documentos (738 em 21/08, 811 em 27/08) — consistente com testes novos adicionados nos últimos commits (#63-#66: barreiras SL/TP, portfolio equity, Sortino/Calmar). **A suíte é genuinamente verde e reproduzível de forma independente**, não é um número inventado em documentação.

**FACT (CONFIRMADO, L4)** — `tests/test_positive_control.py`: 3/3 PASSED (controle positivo com edge conhecido → validado; ruído puro → "RUÍDO"; edge negativo → também detectado). Isto **prova que a metodologia estatística tem poder de detectar sinal quando ele existe** — é um sanity check da ferramenta de medição, **não é evidência de edge real em cripto**. Distinção que o próprio projeto também faz corretamente (B12 em HYPOTHESES.md).

**FACT (CONFIRMADO, L4)** — `python scripts/attest_harness.py --dry-run`: "sensibilidade e especificidade OK" para os dois juízes (V3/PSR e Fase1/Spearman). Reproduzi este resultado eu mesmo, de forma independente, sem escrever nenhum arquivo (usei `--dry-run` deliberadamente para respeitar a regra de somente-leitura).

**FACT (CONFIRMADO)** — Os atestados **commitados** (`trials.harness_attestation.json`, `trials.phase1_harness_attestation.json`) têm `expires_at: 2026-08-28T10:44:xxZ`. **Na data de congelamento desta auditoria (2026-08-31), esses atestados já estão expirados** pela própria regra do projeto (validade de 7 dias). Isto não invalida nenhum veredito já registrado (atualizar sharpe de trial existente não exige atestado), mas significa que, no estado exato do HEAD auditado, **nenhuma trial NOVA poderia ser legitimamente registrada sem antes rodar `attest_harness.py` de novo** — o que eu confirmei ser tecnicamente possível (rodei o dry-run com sucesso), mas não fiz porque geraria escrita em arquivo.

**FACT / MISSING EVIDENCE** — `scripts/psr_nonoverlap.py` requer `data/v3/BTCUSDT/wfa_returns.json`, que **não existe neste ambiente** (`data/` é gitignored; dados brutos vivem em `C:\predictor\data` na máquina do dono, conforme `docs/RETROACTIVE_QUALITY_2026-08-27.md`). **Nenhum dado bruto de mercado (OHLCV, funding, OI, previsões históricas) está presente neste repositório ou ambiente de auditoria.** Isto significa que **todos os números de PSR/Spearman/Sharpe/DSR reportados em `trials.json`, `HYPOTHESES.md` e nos `observation_reports/` são, para efeitos desta auditoria, CLAIMS DOCUMENTAIS de nível L1-L2 — não pude recalculá-los eu mesmo com os dados brutos.** O que pude confirmar independentemente foi (a) que o código que os produziria existe e passa em testes sintéticos, (b) que a metodologia estatística por trás tem poder comprovado em controle positivo, e (c) que os artefatos JSON versionados (h6_status.json, observation_reports) são internamente consistentes com o texto dos HANDOFFs e docs.

**Positive control ≠ prova de edge.** Reforço este ponto por ser central ao objetivo da auditoria: passar no `test_positive_control.py` e no `attest_harness.py` demonstra que, **se houvesse edge real, o pipeline o detectaria**. Isso NÃO é evidência de que o edge existe. Todos os vereditos NO-GO/refutado (H1-H5, trend-following, SMA200) são, portanto, interpretáveis como negativos genuínos (poder comprovado + resultado negativo = ausência de evidência de efeito), exceto onde o `n` é pequeno (H4, H6) — aí "RUÍDO"/imaturo é ausência de evidência, não evidência de ausência (ver §F/B12).

---

## D. Dados

**FACT (CONFIRMADO por leitura de código, L2)** — A arquitetura de dados (DPL — Data Provider Layer) é bitemporal por desenho: `published_at`/`event_at`/`ingested_at` separados, guard de integridade temporal na inserção (`dpl/feature_store.py:36,123-145`), Alignment Engine anti-lookahead, migrações aditivas nunca reescritas (ADR-017). Testes dedicados existem: `test_dpl_feature_store.py`, `test_timeindex.py`, `test_v3_hmm_no_lookahead.py`, `test_diagnose_h6_mechanism_pit.py` — todos verdes na minha execução.

**FACT (CONFIRMADO)** — Fontes usadas: Binance (spot/futures via `ccxt`/coletores próprios) com fallback CoinGecko, Kraken para consenso; FRED para DXY (trocado de stooq.com após bloqueio anti-bot, confirmado ao vivo pelo dono); calendário FOMC via WebSearch (fonte secundária, não primária).

**MISSING EVIDENCE / NÃO REPRODUZÍVEL** — Não pude verificar point-in-time correctness *empiricamente* contra dados reais (só os testes sintéticos de anti-lookahead, que passam). Não pude auditar survivorship bias no universo do `--discover` (top-100 CoinGecko + trending — sujeito a sobrevivência, mas o próprio projeto não faz claims fortes de generalização de universo).

**FACT (CONFIRMADO por leitura de código e docs)** — Custos de transação **são** modelados explicitamente nos vereditos que contam: V3 usa taker 10bps + slippage 5bps por perna + funding real; trend-following spot usa 15bps por transição (fixo, não walk-the-book); a camada `trading/microstructure.py` tem walk-the-book e impacto raiz-quadrada, mas **explicitamente marcado como não calibrado contra execução real** (HANDOFF-2026-08-14.md, docs/HYPOTHESES.md). Existem **dois modelos de custo não totalmente unificados** (`v3/costs.py` de bps fixo vs `trading/microstructure.py` de simulação de book) — o projeto argumenta que atendem a instrumentos diferentes (perp com funding × spot com walk-the-book) via `trading/cost_policy.py`, dispatcher que recusa modelo não calibrado como sustentação de veredito científico. **Isto é uma boa prática de engenharia, mas não substitui calibração empírica contra execução real, que não existe (não há venue real, `ExchangeAdapter` só tem implementação `SimulatedExchangeAdapter`)**.

---

## E. Edge econômico, backtests, e prospectivo vs retrospectivo

**FACT (CONFIRMADO por artefatos JSON)** — Toda evidência de edge encontrada é **negativa ou não significativa**, líquida de custos:
- H1-H3 (HMM+funding/OI): NO-GO, edge líquido negativo em todos os casos testados.
- H5 (LLM D+7 multi-provedor): correlação negativa e significativa (na direção **oposta** à hipótese original) — n=440, robusto em amostra.
- Trend-following 4h: líquido −62% (destruído por turnover/custos).
- SMA200 diário: retorno líquido positivo em nível absoluto mas **gate estatístico reprovado** (IC cruza zero, BTC não bate buy&hold, drawdown excessivo).
- H6 (inversão do LLM): única leitura com Sharpe auxiliar positivo (+0,3479), mas com **n=6**, explicitamente declarado pelo projeto como não-veredito.

**Existe ledger prospectivo/paper trading real?** **PARCIALMENTE.** A H6 tem desenho prospectivo genuíno (trava anti-data-snooping: só aceita `pred_date` posterior a `registered_at`, o que é metodologicamente correto), e existe infraestrutura de paper trading (`v3/paper_trader.py`, `v3/paper_report.py`, citada no commit #66 como já existente, não reconstruída). **Mas**: (a) o `n` real vive num banco de dados de produção (`feature_store.db`) que é gitignored e só sai do ambiente do dono via commit manual de `h6_status.json` — **não auditável diretamente por mim**; (b) o último valor commitado é `n=0` (2026-08-24), então não há evidência versionada de que a coleta prospectiva tenha avançado desde então até a data de congelamento (2026-08-31), um intervalo de 7 dias sem atualização visível no artefato oficial. **Isto é MISSING EVIDENCE sobre o estado atual real da H6** — não posso afirmar se há mais dado coletado do que o commitado, nem se há menos (o projeto documenta bem esse ponto: "a única via pela qual o `n` sai da máquina de coleta é este arquivo, commitado à mão quando muda").

**RECOMMENDATION implícita do próprio projeto, que endosso:** qualquer leitura da H6 antes de `n≈250` (poder ~80% para rho=0,2, medido pelo próprio projeto em B12) deve ser tratada como subdimensionada, mesmo que o gate formal só exija n≥30.

**Override de governança 2026-08-14 (achado crítico):** o dono do repositório **decidiu explicitamente construir a camada `trading/`** (contrato econômico, execução, microestrutura, portfólio) **antes de qualquer hipótese ter validado edge**, contra a própria regra do projeto (B8: "gestão de risco de um sinal que não existe é polimento de motor desligado"). Isto está documentado com honestidade pelo Claude Code que fez o trabalho (registrou a objeção antes de proceder), mas é **INFERENCE minha, não do repo**: construir 99% de cobertura de testes numa camada de execução sem sinal validado é **custo de oportunidade real** — meses de engenharia em algo que só terá valor se uma das hipóteses (H6, H7, ou futuras) eventualmente validar edge, o que até a data de congelamento **não aconteceu**.

---

## F. Multiple testing / risco de p-hacking

**FACT (CONFIRMADO)** — O projeto implementa **Deflated Sharpe Ratio** (`predictor_core.measurement.trials`) contra `N` = número de trials **nomeadas** em `trials.json` (N=7 até a última verificação, confirmando o texto do veredito H5: "SR0 0,447, N=7"). Também implementa **PBO/CSCV** (`analyzers/pbo.py`, B10) como camada complementar, e mediu formalmente o **poder do gate** (B12) — uma prática rara e valiosa (a maioria dos projetos nem mede se o teste tem poder suficiente para o `n` real).

**INFERENCE (risco identificado por mim)** — O denominador N=7 do DSR **não captura**:
1. A **varredura de Kelly** feita para o "GO" pré-custos de H1 (múltiplas frações testadas, só a melhor citada) — não é uma trial nomeada.
2. O novo `run_threshold_grid` (commit #63, `backtest_v3.py`) — varre grade de `fr_zscore_threshold` × `min_regime_confidence` rodando WFA completo por combinação. O próprio commit admite "nenhuma combinação foi validada contra dados reais nesta revisão". **Quando isso rodar contra dado real, cada combinação da grade é, na prática, uma tentativa — mas nada no código força o registro de N combinações em `trials.json`.** Este é um risco estrutural concreto para a próxima rodada de resultados da V3.
3. Exploração informal fora do ambiente auditável (ver §B, "UNKNOWN RESEARCH SEARCH SPACE").

**Avaliação:** o risco de overfitting/p-hacking é **moderado-baixo para os vereditos já fechados** (H1-H5 — todos NO-GO, e um resultado NO-GO sob risco de subestimação de N só reforça a conclusão, não a enfraquece) mas **moderado-alto para qualquer resultado futuro positivo da grade de thresholds da V3 ou de novas iterações de H6/H7**, que precisará de disciplina extra de registro para não repetir o padrão do kelly-sweep original.

---

## G. Resultados negativos — crédito onde é devido

Este é um dos pontos mais fortes do repositório e merece registro explícito, não apenas crítica:

- **H1, H2, H3 refutadas com aprendizado real registrado**: H3 não apenas falhou, mas gerou o aprendizado correto e usado depois ("sinal de vida curta; esticar horizonte destrói, não amortiza") — evitando repetir o erro.
- **H5 refutada com honestidade sobre viés de escolha de estrato**: o projeto reporta explicitamente que, se tivesse escolhido o estrato "input completo" em vez do pooled, o resultado não teria sido significativo — e declara por escrito que isso **não muda o veredito** porque o critério pré-registrado julgava o pooled. Isto é exatamente a disciplina que evita HARKing.
- **Kelly-sweep pré-custos corretamente descartado**: um resultado "bonito" (PSR 0,909) foi identificado como artefato de varredura sem custos e revertido — não foi usado para vender o projeto.
- **Trend-following 4h e SMA200 diário corretamente reprovados no gate**, mesmo com retornos absolutos "interessantes" (SMA200 ETH: líquido +230%) — o projeto resistiu à tentação óbvia de declarar vitória com um número grande e não-significativo.
- **`FINAL_AUDIT_2026-07-20.md` corrompido (arquivo binário vazio) foi mantido e documentado como perda, em vez de silenciosamente apagado ou recriado com conteúdo inventado.**
- **Dados brutos da H5 perdidos**: declarado como `HISTORICAL_REPRODUCIBILITY=LIMITED` em vez de ocultado.

**INFERENCE:** este padrão de auto-refutação documentada é estatisticamente mais crível do que a média de projetos de trading algorítmico que só publicam o que "funcionou". Isso **eleva minha confiança na honestidade dos vereditos NO-GO reportados**, mesmo sem poder recalculá-los eu mesmo com dados brutos (§C).

---

## H. Checkpoint obrigatório — 13 perguntas

1. **Os dados usados nos backtests são corretos e point-in-time (sem look-ahead)?**
   NÃO REPRODUZÍVEL empiricamente por mim (dados ausentes), mas L2-L4: arquitetura bitemporal existe, testes causais de anti-lookahead (HMM, feature store) passam na minha execução. CLAIM DOCUMENTAL bem sustentada por código+testes, não por dado real verificado por mim.

2. **O experimento (desenho estatístico) é válido?**
   SIM, com boa confiança (L4): pré-registro, walk-forward IS/OOS com purge, block bootstrap overlap-aware, controle positivo com poder comprovado, DSR. É um dos desenhos mais rigorosos que já vi documentado em um projeto deste porte.

3. **Existe capacidade preditiva demonstrada (correlação sinal×retorno)?**
   NÃO, nas famílias fechadas (H1-H5): correlação nula ou **negativa e significativa** (H5). H6/H7 imaturas — INCONCLUSIVO por amostra insuficiente, não "não" definitivo.

4. **Existe edge econômico bruto (antes de custos)?**
   Só transitoriamente e de forma não confiável (H1 pré-custos/pós-kelly-sweep, revertido; trend-following bruto +54,2%/SMA200 bruto positivo). Nenhum edge bruto sobreviveu a reexecução mais cuidadosa.

5. **Existe edge econômico líquido (depois de custos)?**
   NÃO em nenhuma hipótese fechada. CONFIRMADO documentalmente em todos os casos (H1-H3, H5, trend-following, SMA200).

6. **O edge, se existisse, seria capturável na prática (liquidez, slippage, latência)?**
   INCONCLUSIVO/NÃO TESTADO — não há edge para testar capturabilidade. Os modelos de custo/microestrutura existem mas são **explicitamente não calibrados contra execução real** (nenhum venue real conectado).

7. **Existe resultado líquido realizado (não simulado)?**
   NÃO. `capital_authorized: false` em todo o histórico auditado; nenhum trade real ocorreu.

8. **Existe robustez prospectiva (dado coletado depois do registro da hipótese, não reciclado)?**
   PARCIAL: H6 tem desenho prospectivo correto, mas **imatura** (n=0 no último artefato commitado, 2026-08-24, sete dias antes do congelamento). H4 teve coleta prospectiva real mas foi interrompida por decisão operacional antes de maturar.

9. **A escala é suficiente para conclusões estatísticas confiáveis?**
   NÃO ainda para nenhuma hipótese ativa. O próprio projeto mediu o poder do gate (B12): n=30 detecta rho=0,2 em ~14,7% das vezes; é preciso n≈250 para poder adequado. Isso é um achado de rigor incomum e deveria ser um padrão de referência.

10. **O projeto é escalável (mais capital/ativos sem degradar o edge)?**
    NÃO AVALIÁVEL — não há edge para escalar. Pergunta prematura no estado atual.

11. **Existe valor estratégico residual (aprendizado, infraestrutura reaproveitável) mesmo sem edge?**
    SIM, moderado a alto: a DPL (Data Provider Layer), o framework de trials/DSR/PBO, o harness de controle positivo, e a disciplina de pré-registro são ativos genuinamente reaproveitáveis — inclusive por outros repositórios do ecossistema PREDICTORS, segundo os próprios docs (partes já promovidas a `predictor_core`).

12. **O risco de múltiplos testes/data snooping foi adequadamente controlado?**
    PARCIALMENTE. DSR+PBO+medição de poder são exemplares para o que foi **registrado**; mas variações internas (kelly-sweep, threshold grid futuro) escapam do denominador N — risco real para resultados futuros, não fatal para os já fechados (que são todos negativos).

13. **A recomendação de manter/encerrar decorre de evidência ou de sunk cost / otimismo do time?**
    Pela leitura dos documentos, a decisão de continuar (H6, H7, camada trading) parece em parte movida por decisão explícita do dono **contra** o próprio conselho do projeto (override B8 documentado). Isso é um sinal de alerta de possível sunk-cost bias, ainda que mitigado pela disciplina de não autorizar capital sem gate.

---

## Recomendação preliminar

### **MANTER + TESTAR (com escopo reduzido), NÃO ESCALAR**

**Justificativa:**
- A infraestrutura científica (DPL, pré-registro, DSR/PBO, controle positivo, poder do gate) é de qualidade real e verificada por mim de forma independente (testes rodam, controle positivo passa, atestado funciona). Isso tem valor estratégico para o ecossistema PREDICTORS mesmo sem edge comprovado em cripto especificamente.
- **Nenhuma evidência de edge líquido real existe até a data de congelamento.** Todas as hipóteses fechadas (H1-H5, trend-following 4h, SMA200) foram corretamente invalidadas ou reprovadas no gate, líquidas de custos. **Confiança: ALTA de que não há edge nas famílias já testadas** (múltiplas confirmações independentes, incluindo reexecução em base estendida).
- **Não há evidência prospectiva madura** (H6 em n=0 no último artefato commitado; H7 sem nenhum dado coletado). **Confiança: BAIXA/INCONCLUSIVO sobre se H6 ou H7 poderão eventualmente validar** — não descartadas, apenas não testadas com poder suficiente ainda.
- **QUALQUER evidência de edge líquido real ou prospectivo?** — **NENHUMA**, com **confiança alta** nessa ausência para as famílias fechadas, e **MISSING EVIDENCE** (não INCONCLUSIVO forte, não NO-GO) para H6/H7, que ainda não acumularam amostra.
- A camada `trading/` (execução, microestrutura, portfólio) representa **custo de oportunidade não trivial** — engenharia sofisticada construída deliberadamente **antes** de qualquer edge validado, contra a própria política do projeto. **RECOMENDAÇÃO: congelar novo investimento em `trading/` até que H6 ou H7 (ou hipótese nova) produza um GO líquido de custos**, redirecionando esforço para: (a) terminar a coleta da H6 até n≈250 (não apenas n≥30), (b) completar CPI/PPI e validação end-to-end do DXYProvider para ativar H7 de fato, (c) fechar a lacuna de contagem de tentativas do `run_threshold_grid` antes de rodá-lo contra dado real.
- **Não recomendo ENCERRAR**: o padrão de descoberta é caro (2,5 meses, ~280 commits) mas a disciplina de auto-refutação é rara e valiosa — encerrar agora jogaria fora tanto o aprendizado negativo (que tem valor: eliminou 5+ hipóteses de forma crível) quanto a infraestrutura reaproveitável.
- **Não recomendo REFORMULAR agressivamente**: o desenho metodológico (pré-registro, custos, DSR, poder) está correto; o problema é ausência de sinal nas hipóteses tentadas, não desenho experimental defeituoso.

**Incertezas principais desta auditoria:**
- Não pude recalcular nenhum número (PSR/Spearman/Sharpe) com dados brutos — dependência total de CLAIMS DOCUMENTAIS para os valores numéricos exatos, ainda que a metodologia por trás seja verificável.
- Não sei o estado real de `n` da H6 além de 2026-08-24 (7 dias de silêncio no artefato até o congelamento) — pode ter avançado ou estagnado na máquina de produção do dono.
- Não posso avaliar se a exploração "fora do repositório" (máquina do dono, sessões sem acesso de rede neste ambiente) escondeu tentativas adicionais não contadas no DSR.
- Os atestados de poder commitados estão expirados na data de congelamento — tecnicamente nenhuma trial nova poderia nascer "legítima" agora sem nova execução.

**Custo de oportunidade:** ~280 commits / 2,5 meses de esforço de engenharia intensiva (parte relevante em `trading/`) não geraram, até aqui, nenhum resultado economicamente utilizável — o valor entregue é infraestrutrual e metodológico, não um sinal de trading. Continuar no ritmo atual sem elevar o `n` da H6 para poder adequado (≈250, não apenas 30) arrisca repetir o padrão: mais engenharia, mesmo vazio econômico.
