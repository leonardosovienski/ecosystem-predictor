# Auditoria — `stocks-predictor` (PREDICTORS)

**Auditor:** agente técnico independente · **Escopo:** somente-leitura, 1 repositório
**Repo:** `stocks-predictor` · branch `main` · HEAD `93a4d0ff1bb6b43cad87bf25377ef69a2091b267`
**Congelado em:** 2026-08-31 · 150 commits desde 2026-06-12
**Ambiente de verificação:** clonado localmente, ambiente real reconstruído via `uv sync --all-extras --python 3.13` (wheels oficiais `predictor-core==2.3.0` e `predictor-ops==3.1.0` baixados do GitHub Releases com sucesso — não usei o shim `vendor/`)

Convenções: **FACT** (observei diretamente: código, execução, git), **INFERENCE** (dedução lógica a partir de FACTs), **HYPOTHESIS** (possível, não confirmada), **RECOMMENDATION**.
Taxonomia de evidência: **CONFIRMADO**, **PARCIALMENTE CONFIRMADO**, **CLAIM DOCUMENTAL**, **CONTRADITÓRIO**, **STALE**, **NÃO REPRODUZÍVEL**, **INVALIDADO**, **INCONCLUSIVO**, **NÃO TESTADO**, **MISSING EVIDENCE**.
Níveis: **L0** dados/infra · **L1** experimento válido · **L2** capacidade preditiva · **L3** edge econômico bruto · **L4** edge capturável (custos/liquidez) · **L5** resultado líquido · **L6** robustez prospectiva/escalabilidade.

---

## 0. Resumo do que este repositório é, de fato

FACT — `stocks-predictor` contém **dois domínios distintos e não fundidos**:

1. **Domínio histórico "cross-sectional/fatores"** (H1 momentum 12-1, H2 baixa-vol, H4 sizing 1/vol, H5 reversão 21d, H6 momentum 6-1, H8 filtro duplo momentum∩baixa-vol) — universo top-60 B3 por liquidez, 2018-2026, testado com dado real (COTAHIST). **Todas as 6 hipóteses foram formalmente ENCERRADAS como "NÃO COMPROVADA"** entre 2026-07-12 e 2026-08-28 (CONFIRMADO via `reports/*.md`, `trials.json`, `HANDOFF.md`).
2. **Linha ativa "predictor-rj"** — a pergunta central deste repositório hoje. **"RJ" = Recuperação Judicial** (não "Rio de Janeiro" nem sigla de pessoa/produto). CONFIRMADO por `docs/RJ_DESIGN.md`, `config_rj.yaml`, `src/ingest_rj_universe.py`, `src/rj_episodes.py`, `src/rj_families.py`, `src/rj_judge.py`, `src/rj_outcomes.py`, e pela própria pergunta de pesquisa escrita no protocolo: "rallies especulativos (≥50%) em ações de empresas em recuperação judicial na B3".

A linha RJ está, no estado congelado, em **estágio M0: protocolo e maquinaria construídos e testados apenas com dados SINTÉTICOS; ZERO dado real de RJ foi coletado; nenhuma família foi julgada contra a realidade.** Isso é auto-declarado pelo próprio repositório (`STOCKS_CURRENT_STATE.md`, `config_rj.yaml`, `ecosystem_plugin.py`) e eu **confirmei de forma independente e reproduzível** (seção 3).

---

## 1. "RJ" — o que significa e o que implica (Tarefa D)

**CONFIRMADO.** `docs/RJ_DESIGN.md` §1: *"Existem condições, eventos ou padrões observáveis que aparecem repetidamente ANTES de rallies especulativos (≥50%) em ações de empresas em recuperação judicial na B3, e que sejam conhecíveis no momento da decisão?"* Isto é uma tese de **event-driven distressed/lottery investing**: apostar (ou ao menos tentar prever) rallies especulativos em ações de empresas quase-falidas em processo de reestruturação judicial — o nicho de maior risco/iliquidez do mercado acionário brasileiro.

**INFERENCE — origem narrativa da tese.** O próprio `RJ_DESIGN.md` §4 admite que a janela primária de 60 pregões foi calibrada para *"capturar o fenômeno explosivo que motivou o estudo (AMER3 +194% em poucos pregões)"*. AMER3 é a Americanas S.A., o caso de fraude contábil/RJ mais midiático da história recente da B3 (2023, fora da janela deste repo mas certamente na memória de quem desenhou o estudo). Isso é exatamente o padrão de risco que a **seção 3 do próprio protocolo** alerta contra ("nunca partir de uma lista de casos notáveis lembrados de memória — isso já é viés de seleção antes do primeiro cálculo") — só que aplicado à *pergunta de pesquisa em si*, não à lista de casos. O protocolo evita corretamente que o **universo de empresas** seja construído a partir de "casos notáveis" (usa snapshots + lista completa de RJ), mas não pode evitar que a **motivação de pesquisa** já tenha nascido de um evento extremo memorável. Isso não invalida o desenho estatístico subsequente (que é sólido — seção 4), mas é um viés estrutural de proveniência que nenhuma correção metodológica interna consegue remover.

**Implicações de risco que a auditoria trata com atenção redobrada, conforme solicitado:**

- **Liquidez/execução:** empresas em RJ tipicamente têm free-float reduzido, spreads largos e volume intermitente. O próprio config declara a família `liquidity` como `giro_diario_mediano_60p / free_float_estimado` — reconhece o problema, mas **nada no repositório testa capacidade de execução real** (tamanho de posição vs. profundidade de livro, impacto de mercado). MISSING EVIDENCE.
- **Poucos eventos dominam o resultado:** `rj_judge.leave_one_company_out` existe *precisamente* para isso — o docstring cita nominalmente o risco de "AMER3 ou OIBR3 sozinhas carregam o resultado" (FACT, `src/rj_judge.py:178`). É maquinaria correta, mas **nunca foi exercitada em dado real** — não há resultado real cujo LOCO eu possa reportar. NÃO TESTADO em produção.
- **Sobrevivência/delisting:** tratado explicitamente em `src/ingest_rj_universe.py` (snapshots datados append-only da lista de emissores em RJ, para não perder quem saiu por falência/deslistagem) — ver seção 3.
- **Tamanho do universo investível:** `src/rj_power.py`, rodado por mim (seção 3), mostra que mesmo com efeitos de 1 desvio-padrão (grande, para os padrões da literatura), o poder estatístico com N=20-40 empresas fica entre 2% e 68% — **abaixo do limiar de 80% convencional em todos os N testáveis em tempo hábil**. Isso é uma evidência forte, quantificada e reproduzida, de que **o universo de empresas em RJ na B3 é estruturalmente pequeno demais para gerar confiança estatística robusta**, mesmo antes de qualquer dado real entrar.

---

## 2. `predictor-ops` — confirmação da suspeita central (achado transversal para a auditoria de `predictor-ops`)

**CONFIRMADO com busca ampliada.** Repeti a busca solicitada incluindo `.yaml/.yml/.toml/.cfg/.ini/.sh/.bat/.ps1/Dockerfile*` em todo o repositório:

```
./.github/workflows/ci.yml:42-43   (só instala e faz smoke-import)
./tests/conftest.py:10,20          (só um assert "não veio do vendor")
./pyproject.toml:14,65             (declaração de dependência)
```

**Não há nenhum uso funcional de `predictor_ops` em `src/` ou `main.py`.** O pacote é declarado como dependência obrigatória (`predictor-ops>=3.1,<4`), instalado com sucesso via wheel oficial, importado num smoke-test de CI (`import predictor_ops`) e usado em `tests/conftest.py` apenas para um `assert "vendor" not in pathlib.Path(predictor_ops.__file__).parts` — isto é, o teste verifica que o pacote **não** foi carregado do diretório vendorizado, mas nenhum código de produção deste repositório chama qualquer função de `predictor_ops`. **Achado relevante para a auditoria paralela de `predictor-ops`: neste consumidor (`stocks-predictor`), a dependência é 100% decorativa/de infraestrutura de build — nenhuma capacidade funcional de `predictor-ops` é efetivamente consumida.**

---

## 3. Ferramentas de auto-diagnóstico (`audit_db.py`, `diagnose_universe.py`, `poc_leak.py`) — proveniência e execução real

**FACT — proveniência.** Via `git log`, os três scripts (e `trials.json`/`test_core_integrity.py`) foram introduzidos no commit `614f9aca` (2026-07-11), mensagem: *"wip(red-team): registra a auditoria de jun/2026 que estava nao commitada"* — descrita como "auditoria hostil (2026-06-25/29) encontrada NÃO COMMITADA... scripts de evidência (poc_leak, diagnose_universe, audit_db) da sessão de debug que havia AFROUXADO parâmetros H1-FROZEN". **Ou seja: estes três arquivos não são tooling de produção do projeto — são artefatos ad hoc de uma sessão de red-team/debug anterior**, preservados por disciplina de histórico, não desenhados como suíte de auditoria contínua. Isso não os torna menos úteis para a auditoria atual, mas recalibra a expectativa: são scripts de depuração pontuais, com estilo de código (emojis, prints diretos) destoante do resto do repositório.

**Execução real (reproduzida por mim):**

- **`audit_db.py`** — na primeira tentativa, falhou (`data/stocks.db` não existe no checkout — CONFIRMADO, `data/` só contém `.gitkeep`, `*.db` está no `.gitignore`). Depois de rodar a suíte de testes real (que recria o schema em `data/stocks.db` via `db.get_connection()` default), rodei de novo: **13 tabelas encontradas, TODAS com 0 linhas** (`prices_raw`, `rj_universe`, `rj_episodes`, `rj_events`, `rj_family_scores`, `rj_universe_snapshots`, `fundamentals`, etc. — todas zero). Isso **confirma de forma direta e reproduzível que este checkout não contém nenhum dado real de mercado ou de RJ** — é puramente o schema vazio.
- **`diagnose_universe.py`** — falhou com `sqlite3.OperationalError: no such table: prices_raw` antes da suíte rodar; depois rodou sem erro mas sobre uma base vazia (nenhum ticker retornado). Consistente com o achado acima.
- **`poc_leak.py`** — **rodou com sucesso e reproduziu um leak real.** O script demonstra que a barreira anti-lookahead pública de `predictor_core.measurement.replay.PastView.__getitem__` (que corretamente levanta `LookaheadError` para acesso a índice futuro) **pode ser contornada lendo o atributo interno `past._data`**, que é a tupla completa e não recortada de todos os eventos, incluindo o futuro. Reproduzi a leitura do código-fonte vendorizado (`vendor/predictor_core/measurement/replay.py`, linhas 18-50): `_data` é um atributo de instância comum (`__slots__`), sem qualquer ofuscação além da convenção de underscore único — **nenhuma proteção real de encapsulamento impede o acesso**. A saída real do script:
  ```
  [Passo 0] Estamos no evento 'Dia 1 (Mercado Calmo)'. Mas eu espiei a tupla e sei
  que no final vai acontecer um 'Dia 4 (CRASH GLOBAL)'!
  ```
  **CONFIRMADO e reproduzido nesta sessão.** Ressalva importante: `vendor/predictor_core` é descrito no próprio README como "artefato histórico de integridade... não é a dependência-alvo da arquitetura moderna" — a dependência real de produção é o wheel `predictor-core==2.3.0` baixado do GitHub Releases. Não testei se o mesmo padrão `_data` existe no wheel 2.3.0 publicado (está fora do escopo desta auditoria de `stocks-predictor`), mas **o padrão de design (`PastView` com atributo interno acessível) é idêntico em ambos por construção do Python** — vale como achado relevante para a auditoria de `predictor-core`, e como evidência de que a garantia "lookahead é estruturalmente impossível" (linha 7 do docstring de `replay.py`) é, na prática, apenas uma barreira de convenção contornável por qualquer código que decida ler um atributo "privado" — não uma garantia estrutural genuína em Python.

- **`trials.json`** — 6 entradas (h1-momentum-12-1, h2-lowvol-252, h4-invvol-sizing-252, h5-strev-21, h6-momentum-6-1, h8-mom-lowvol-double), registradas entre 2026-07-16 e 2026-08-28, todos com `sharpe` por-período muito próximo de zero (0.010–0.020, exceto H5 negativo em -0.011) e notas explícitas de "não comprovada". **CONFIRMADO como um registro honesto e append-only de tentativas, exatamente na função que o DSR precisa (descontar múltiplos testes).**
- **`trials.harness_attestation.json`** — 1 entrada, `edge_verdict: "COMPROVADA"`, mas a nota deixa claro que é um **controle positivo sintético do próprio pedágio de julgamento** ("séries sintéticas pareadas"), não um veredito de estratégia real. **Não confundir com evidência de edge econômico** — é um teste de que a régua funciona, não de que há sinal.

---

## 4. Reprodução técnica (Tarefa E)

**CONFIRMADO — ambiente real montado com sucesso.** `uv sync --all-extras --python 3.13` resolveu e instalou 22 pacotes, incluindo os wheels oficiais `predictor-core==2.3.0` e `predictor-ops==3.1.0` publicados no GitHub Releases do ecossistema (network real, sem shim).

**Suíte de testes:** `uv run pytest -q -v` → **242 passed em 95.41s, 0 falhas.** Bate exatamente com a contagem de `def test_` no repositório (242). Este resultado é **melhor** do que o relatado no último audit interno (`docs/audit/kimi_2026-08-24/...`: 211 passed/4 failed, mas aquelas 4 falhas eram do shim vendor, não dos wheels reais) — com os wheels reais, **zero falhas conhecidas remanescem**.

**`main.py` (CLI legado do domínio histórico) — comandos reais disponíveis** (via saída de erro amigável, não há `--help` formal):
```
python main.py                          # status (somente leitura)
python main.py ingest <COTAHIST.ZIP>    # M1
python main.py adjust                    # M2
python main.py universe <YYYY-MM-DD>     # M3
python main.py backtest                  # M5 (H1)
python main.py attest-power              # controle positivo + trials
python main.py backtest-h2/h4/h5         # H2/H4/H5
python main.py paper <YYYY-MM-DD>        # M6 forward
python main.py analyst [rótulo]          # briefing consultivo read-only
python main.py splits-review / splits-import
```
Não há comando `backtest-h6`/`backtest-h8` no `main.py` — essas duas hipóteses foram julgadas via chamada Python ad hoc (`python -c "import backtest; backtest.run_h6(...)"`), o que o próprio HANDOFF documenta como gap de rastreabilidade (`run_id: n/d` nos relatórios) — **CONFIRMADO, é um desvio de processo real, mas declarado com transparência, não escondido.**

**`src/rj_power.py --fast` (análise de poder prospectiva) — rodei com múltiplos N:**

| N empresas | efeito +0.5σ | efeito +1.0σ |
|---|---|---|
| 20 | 2% | 24% |
| 30 | 12% | 52% |
| 40 | — | 68% |

Nenhuma combinação testável em tempo hábil atingiu o limiar convencional de 80% de poder. **Este é, na minha avaliação, o achado quantitativo mais importante desta auditoria**: mesmo antes de qualquer dado real, a própria ferramenta do projeto mostra que o desenho é estatisticamente subdimensionado para o universo provável de empresas em RJ na B3 (tipicamente dezenas, não centenas).

---

## 5. Dados, survivorship, delisting, corporate actions (Tarefa C)

**INFERENCE positiva sobre o desenho (não posso confirmar com dado real, mas o código é coerente):**

- `src/cotahist.py`/`src/ingest_cotahist.py`: parser posicional fiel ao layout oficial da B3 (245 bytes, posições documentadas e comentadas como "VERIFICADAS — não de memória"). Segundo `HANDOFF.md`, foi validado contra registros reais (PETR4, VALE3, ITUB4) — **CLAIM DOCUMENTAL, não reproduzível por mim** (não há arquivo COTAHIST real neste checkout).
- **COTAHIST é, por natureza do formato, um arquivo histórico anual completo da B3** — inclui todos os papéis negociados naquele ano, não uma lista atual. Isso significa que, **se todos os anos relevantes forem de fato ingeridos**, o domínio histórico de fatores não sofre o survivorship bias clássico de "só ações que sobreviveram até hoje" — ações delistadas no meio do período aparecem nos anos em que negociaram. `src/universe.py` reforça isso corretamente: exclui papéis sem pregão recente na janela de liquidez (tratando-os como "deslistados/pararam de negociar"), sem forçar sobrevivência.
- **`src/ingest_rj_universe.py` trata explicitamente o survivorship do UNIVERSO de empresas em RJ** (não dos preços): a lista pública da B3 de "emissores em RJ" é um retrato do presente; o módulo grava snapshots datados append-only e usa o diff entre retratos para capturar quem SAIU (falência/encerramento/deslistagem) — exatamente o problema que a tarefa pediu para investigar. **Desenho correto**, mas **NÃO EXECUTADO**: não há nenhum snapshot real gravado (tabela `rj_universe_snapshots` com 0 linhas, confirmado na seção 3).
- **Corporate actions (desdobramentos/grupamentos/fusões):** `src/adjust.py` implementa detecção de saltos de preço + inferência de proporção de split + fila de quarentena para aprovação humana (nunca auto-resolve). CONFIRMADO como desenhado no HANDOFF: 57 de 263 saltos detectados como proporção redonda em dado real (na época); adjudicação manual de 15 splits de maior liquidez para a H1 (BBAS3, B3SA3, PRIO3, etc., nomeados com aprovador humano `approved_by=Superleo13`). Fusões/incorporações especificamente **não têm tratamento dedicado visível** — MISSING EVIDENCE quanto a esse subtipo de evento corporativo.
- **Achado do audit report interno (`docs/audit/kimi_2026-08-24/RELATORIO_AUDITORIA_RJ.md`), que verifiquei ser consistente com o código atual:** `censoring_horizon_trading_days = 756` (a censura por EMPRESA, i.e., empresas em RJ que nunca tiveram nenhum candidato a fundo) está **[RJ-FROZEN] no config mas morta no código** — nenhuma linha a lê; hoje essas empresas simplesmente desaparecem do denominador (`excluded`) em vez de contar como censura ou controle. Isso é um viés de denominador real e não resolvido, **auto-declarado no próprio `config_rj.yaml`** (comentário extenso citando o próprio relatório de auditoria). CONFIRMADO por leitura direta do código (`rj_episodes.py`, `rj_pipeline.py` não implementam essa regra).

---

## 6. Custos, impostos, edge bruto vs. líquido (Tarefa F)

**CONFIRMADO — modelo de custos existe e é tecnicamente correto para o que cobre:** `src/execution.py` implementa custo ida-e-volta (`roundtrip_cost = 2×(fee+slippage)`), execução em abertura de D+1 (evita lookahead de preço), e `equal_weight_turnover_cost`/`weighted_turnover_cost` corretamente normalizados (um bug de normalização documentado e corrigido no histórico, `M5` do relatório de auditoria interno). Os parâmetros usados nos trials: `b3_fee_pct=0.0003`, `spread_slippage_pct=0.0015`, `brokerage_pct=0.0` — plausíveis para emolumentos B3 + slippage conservador, mas **não há evidência de calibração empírica de slippage/spread contra livro de ofertas real**, especialmente crítico para o universo RJ (baixa liquidez). MISSING EVIDENCE quanto à adequação desse número para papéis ilíquidos de RJ.

**CONFIRMADO — impostos NÃO são modelados em nenhum lugar do repositório.** Busquei por "imposto", "tax", "capital gain", "DARF", "come-cotas" em todo `src/`, raiz e `docs/` — **zero ocorrências**. No Brasil, ganho de capital em ações fora de day-trade tem alíquota de 15% (com isenção para vendas mensais ≤ R$20.000 em ações no mercado à vista) e day-trade 20% — nenhum desses parâmetros aparece no `execution.py`, `backtest.py` ou `config.yaml`. Como os vereditos do domínio de fatores já são "não comprovada" (IC cruza zero) **antes** de impostos, esta omissão não muda o veredito atual (edge bruto ~zero → líquido de imposto também ~zero/negativo), mas é uma lacuna estrutural que se tornaria relevante no dia em que qualquer hipótese fosse "comprovada" no pedágio de Sharpe.

**Cadeia L0→L6 aplicada ao estado atual:**
- Domínio de fatores (H1-H8): **L1 atingido** (experimento válido, pré-registrado, testado com dado real declarado) → **L2 não atingido** (nenhuma capacidade preditiva estatisticamente distinguível de ruído: IC sempre cruza zero, DSR sempre < 0.95) → L3-L6 não aplicáveis (não há edge para discutir custo/liquidez/robustez).
- Linha RJ: **L0 não atingido** (nenhum dado real ingerido) → toda a cadeia L1-L6 é, no momento, protocolo de papel + maquinaria testada em sintético, não um resultado científico.

---

## 7. Multiple testing e crédito a resultados negativos (Tarefas G)

**CONFIRMADO — disciplina de múltiplos testes real e efetiva no domínio de fatores.** `trials.json` é versionado e append-only; `src/trials_gate.py` aplica DSR (Deflated Sharpe Ratio) contra o número de tentativas registradas; a trava de poder (`attest-power`) roda **antes** de qualquer hipótese ser julgada, com controle positivo/negativo sintético (`trials.harness_attestation.json`). H1 foi julgada isoladamente (DSR não obrigatório para N=1, decisão documentada e justificada); a partir de H2, o DSR é obrigatório. Um bug real foi encontrado e corrigido durante a auditoria interna (H6 julgada inicialmente com N=5 no denominador do DSR, deveria ser N=6 — corrigido, e a correção **piorou** o DSR da H6, não melhorou — evidência de que a correção não foi cosmética a favor do resultado).

**Crédito onde é devido:** as 6 hipóteses do domínio de fatores foram **formalmente encerradas como negativas**, sem repescagem de parâmetros, com critérios fixados antes da rodada (`[H1-FROZEN]` etc.), e o próprio texto declara explicitamente "resultado inconclusivo é válido e encerra a hipótese". Isso é boa prática científica genuína — **CONFIRMADO**, não é apenas retórica: os números batem (IC sempre cruzando zero, DSR sempre abaixo do limiar) e não houve reabertura de nenhuma delas.

**CONTRADITÓRIO — achado específico.** `src/report.py::build_markdown` imprime **incondicionalmente**, para toda hipótese, a linha *"Veredito real da {H} exige COTAHIST real da B3 — sintético só valida a máquina"* (linha 160-161 do código atual, `git log` mostra que este arquivo foi editado pela última vez no commit `00b2a5e`, "Corrige 10 achados de revisão de código"). Porém `HANDOFF.md` (por volta da linha 265) afirma que exatamente este texto **"tinha ficado obsoleto (já rodou com dado real)... Corrigido; relatórios REGERADOS ... para carregar o texto certo"** — atribuindo a correção ao mesmo commit `00b2a5e`. Ao ler o código-fonte atual e os relatórios `reports/h6_verdict_adhoc.md`/`h8_verdict_adhoc.md` regenerados por esse commit, **a linha "sintético só valida a máquina" continua lá, sem condicional**. Ou seja: **o HANDOFF afirma uma correção que, pela leitura direta do código e dos artefatos gerados, não foi de fato aplicada** (só o `_BIAS_NOTE` — a ressalva de viés de dividendos — foi corrigido, não o disclaimer de dado sintético). Isto é exatamente o tipo de divergência "o repositório diz X, mas o código faz Y" que esta auditoria foi instruída a caçar. **Efeito prático:** o texto remanescente é tecnicamente enganoso por *excesso* de cautela (sugere que H6/H8 podem não ter usado dado real), não por falta — mas é uma evidência concreta de que a documentação (HANDOFF) não é fonte confiável de verdade sobre o estado exato do código, mesmo quando descreve suas próprias correções.

**Sobre se H1-H8 realmente usaram dado real:** `HANDOFF.md` linha ~857 afirma textualmente "Backtest final rodado sobre a base atualizada (COTAHIST real, 11 anos, 2018→2026)" para a H1, com detalhes circunstanciais fortes (15 tickers nomeados, aprovador humano nomeado, `run_id` específico). O commit `21239df` que julgou H6/H8 chama-se "Reconstrói stocks.db real". **PARCIALMENTE CONFIRMADO** — circunstancialmente convincente, mas **NÃO REPRODUZÍVEL por mim**: o `data/stocks.db` não é versionado (por design, `.gitignore`), e não há arquivo COTAHIST bruto no repositório para eu re-derivar os números. Não consigo, nesta auditoria, confirmar de primeira mão que os Sharpes reportados vieram de preços B3 reais e não de alguma reconstrução sintética rotulada como real.

---

## 8. Tese original, fases e progresso científico real (Tarefa A)

**Linha do tempo reconstruída via HANDOFF.md + git log (FACT):**

1. **2026-06-12 — M0:** gênese do domínio "cross-sectional/fatores" (momentum, baixa-vol). Infraestrutura: parser COTAHIST, ajuste de corporate actions, universo point-in-time, backtest walk-forward, pedágio estatístico de 2 lentes (PSR + bootstrap).
2. **2026-07-04 a 2026-07-12 — M1-M6:** H1 (momentum 12-1) testada com dado real declarado, **encerrada NÃO COMPROVADA**. Pausa estratégica declarada em 2026-07-12: *"a ideação da H2 está PAUSADA por tempo indeterminado... prioridade do ecossistema é alocar recursos onde já existe sinal comprovado (Cripto/H5, Brasileirão/Modo Sombra)"* — evidência de que o operador estava avaliando `stocks-predictor` **contra outros domínios do ecossistema**, não apenas internamente.
3. **2026-07-16 a 2026-08-28:** a pausa não durou — H2, H4, H5, H6, H8 foram todas testadas e **todas encerradas NÃO COMPROVADAS**. Nenhum parâmetro `[H#-FROZEN]` foi ajustado após ver resultado (verificável nos commits — cada hipótese teve pré-registro em commit separado do julgamento).
4. **2026-08-23/24 em diante:** pivô para a linha RJ. `docs/RJ_DESIGN.md` é criado retroativamente (o próprio arquivo admite: *"faltava no pacote entregue... README.md e HANDOFF.md já o referenciavam... antes de ele existir"* — um caso confirmado de documentação canônica referenciada antes de existir, corrigido depois via auditoria externa).
5. **2026-08-24 a 2026-08-30:** três rodadas de auditoria/revisão de código (a externa "kimi_2026-08-24" com 3 críticos + 7 altos + 13 médios corrigidos; revisão pós-reconstrução do banco em 2026-08-28 com 10 achados; auditoria full-tree em 2026-08-30 com 3 achados + 1 escalado ao humano). Todas resultaram em correções reais e testadas (novos testes que reproduzem o bug antes da correção — boa prática confirmada por leitura de `tests/test_rj_audit_2026_08_24.py`, 30 funções de teste).

**INFERENCE — progresso científico real vs. troca de tese sem aprendizado:** É um **misto genuíno, não um caso puro de nenhum dos dois extremos**:

- **A favor de progresso real:** a infraestrutura (ingestão COTAHIST, ajuste de corporate actions, motor de bootstrap/permutação, disciplina de pré-registro, registro de tentativas com DSR/FDR) é **inteiramente reaproveitada** entre o domínio de fatores e a linha RJ — não foi descartada. O encerramento de H1-H8 seguiu critérios fixados a priori, sem repescagem, com FDR/DSR descontando múltiplas tentativas — isso é exatamente o oposto de p-hacking.
- **Contra "aprendizado acumulado" em sentido forte:** a linha RJ **não é uma refinação ou consequência lógica** da falha de momentum/baixa-vol — é uma hipótese de natureza totalmente diferente (evento discreto e idiossincrático vs. fator sistemático contínuo), motivada por um caso midiático específico (AMER3), não por uma inferência estatística do que os dados de fatores ensinaram. Em outras palavras: **a mudança de universo de ações (top-60 líquido → empresas em RJ, tipicamente ilíquidas) representa uma mudança completa de classe de risco**, não uma iteração dentro da mesma classe.

**Veredito da tarefa A:** houve **acúmulo real de infraestrutura e disciplina metodológica**, mas a **escolha da nova hipótese em si não decorre logicamente do aprendizado anterior** — é uma nova aposta, com seu próprio risco estrutural (universo pequeno, iliquidez, sobrevivência), que ainda não tem nenhum dado real por trás.

---

## 9. Tabela de hipóteses

| Hipótese | Claim original | Evidência encontrada | Resultado reproduzido? | Edge bruto | Edge líquido | Prospectivo? | Estado após auditoria |
|---|---|---|---|---|---|---|---|
| **H1** momentum 12-1 | Sharpe líquido > buy-and-hold, IC 95% exclui zero | `reports/h1_verdict_...md`, `HANDOFF.md`; claim de dado real (11 anos) | PARCIALMENTE (relatório lido e consistente; dado bruto não reproduzível por mim) | IC (−0.32, 0.29), cruza zero | N/A (não comprovado bruto) | Não | **INVALIDADO** (formalmente, corretamente) |
| **H2** baixa-vol 252 | Sharpe > benchmark, IC exclui zero, DSR≥0.95 | idem | PARCIALMENTE | IC (−0.29, 0.40); DSR 0.71 | N/A | Não | **INVALIDADO** |
| **H4** sizing 1/vol | Sharpe melhor + drawdown não pior | `trials.json` | NÃO REPRODUZÍVEL diretamente (sem dado bruto) | DSR<0.95 (claim) | N/A | Não | **INVALIDADO** (claim documental consistente) |
| **H5** reversão 21d | Sharpe > benchmark | `trials.json`, sharpe −0.011 | idem | Sharpe negativo | N/A | Não | **INVALIDADO** |
| **H6** momentum 6-1 | idem H1 | `reports/h6_verdict_adhoc.md` | idem | IC (−0.35, 0.33); DSR 0.457 | N/A | Não | **INVALIDADO** |
| **H8** momentum∩baixa-vol | idem, filtro duplo | `reports/h8_verdict_adhoc.md` | idem | IC (−0.15, 0.41); DSR 0.605 | N/A | Não | **INVALIDADO** |
| **predictor-rj** (linha ativa) | padrões conhecíveis antecedem rally ≥50% em ações de empresas em RJ | protocolo completo (`RJ_DESIGN.md`), maquinaria testada em sintético (242/242 testes verdes), poder estatístico simulado (N=20→2%, N=40→68% @ efeito 1.0σ) | **NÃO** — 0 linhas em todas as tabelas RJ do banco; M0 confirmado por execução real | N/A — nenhum dado real | N/A | **Não testado** | **NÃO TESTADO / M0** — protocolo pronto, dado zero |

---

## 10. Checkpoint obrigatório — as 13 perguntas (seção 54)

1. **A tese sobreviveria a um teste out-of-sample verdadeiramente prospectivo (dado nunca visto)?** Domínio de fatores: já foi encerrado negativamente dentro da própria amostra de teste — não há tese viva para testar. Linha RJ: impossível responder, não há sequer um teste in-sample real ainda. **INCONCLUSIVO** para RJ; **N/A** (já invalidada) para fatores.
2. **O resultado depende de poucos eventos/observações extremas?** Estruturalmente, sim, por desenho: `rj_power.py` mostra N tipicamente pequeno; `leave_one_company_out` existe exatamente por essa preocupação, mas nunca foi exercitado em dado real. **HYPOTHESIS forte, não testável ainda.**
3. **Há vazamento de informação futura (lookahead)?** Múltiplos vetores foram corretamente identificados e corrigidos em auditorias internas (C1: fallback `known_at or event_date`; M12: ajustes com `ex_date > asof`). O `poc_leak.py` mostra que a barreira estrutural do `predictor_core` é contornável por acesso a atributo interno — **risco residual de design, não de uso atual observado**. CONFIRMADO como classe de risco; não observei exploração real dele no pipeline de produção.
4. **O backtest usa preços executáveis (não teóricos/de fechamento indevido)?** Sim — execução em abertura D+1, documentada e testada (`execution.py`, `next_open_after`). CONFIRMADO para o domínio de fatores.
5. **Custos de transação e slippage são realistas?** Modelados, mas não calibrados empiricamente contra livro de ofertas real, especialmente problemático para o universo de baixa liquidez de RJ. MISSING EVIDENCE quanto à calibração para RJ.
6. **Impostos foram considerados?** Não, em nenhum lugar. CONFIRMADO como lacuna.
7. **Há correção para múltiplos testes?** Sim, de forma robusta e efetiva (DSR no domínio de fatores; BH-FDR entre 8 famílias pré-registradas na linha RJ). CONFIRMADO.
8. **A amostra é grande o suficiente para o efeito procurado?** Não, pela própria simulação de poder do projeto (RJ). Para o domínio de fatores, sim (2.092-2.131 pregões pareados), mas o resultado foi negativo mesmo assim.
9. **O universo de teste sofre survivorship bias?** Desenho correto para ambos os domínios (COTAHIST anual completo; snapshots datados da lista de RJ), mas **não posso confirmar execução real** — o desenho existe, a execução com dado real não.
10. **Resultados negativos foram registrados e não escondidos?** Sim, de forma exemplar — 6/6 hipóteses do domínio de fatores encerradas como negativas, sem repescagem, documentadas em relatórios versionados. CONFIRMADO.
11. **Há evidência de "story mining" (ajustar a narrativa ao resultado após o fato)?** A motivação da linha RJ nasce de um caso midiático (AMER3) — viés de proveniência da pergunta de pesquisa, não do desenho estatístico subsequente (que é rigoroso). HYPOTHESIS razoável, não uma acusação de má-fé — é um padrão comum e reconhecido na literatura de finanças comportamentais aplicada à própria pesquisa.
12. **O "edge" seria capturável no mundo real dado o tamanho de capital/liquidez do nicho?** Para RJ, há razão estrutural para duvidar (universo pequeno, iliquidez, spreads) — mas **não há dado para responder com números**. MISSING EVIDENCE.
13. **Existe algum mecanismo de guarda contra decisão real de capital prematura?** Sim, explícito e reforçado em múltiplas camadas: `ecosystem_plugin.py` publica `capital_permission: "FORBIDDEN"`, `predictive_status: "NOT_TESTED_REAL_DATA"`, `scientific_status: "M0"`; `STOCKS_CURRENT_STATE.md` reafirma isso textualmente. CONFIRMADO — é o ponto mais forte deste repositório do ponto de vista de governança de risco.

---

## 11. Recomendação preliminar

### **MANTER + TESTAR** (linha RJ) combinado com **CONGELAR** (domínio de fatores, já formalmente encerrado)

**Justificativa:**

- O **domínio de fatores** não precisa de nenhuma ação além de permanecer congelado como está: 6 hipóteses testadas com rigor real (pré-registro, DSR/FDR, execução D+1, custos), todas honestamente encerradas como negativas. Não há edge a proteger nem a aprimorar — reabri-lo sem uma mudança estrutural de sinal (nova fonte de dado, não novo parâmetro) seria repescagem disfarçada, que o próprio HANDOFF proíbe explicitamente.
- A **linha RJ** tem um protocolo cientificamente sério (separação ex-post/point-in-time, censura por episódio, FDR pré-registrado, LOCO, trava de poder) e uma maquinaria 100% verde em teste sintético (242/242) — isto é infraestrutura de qualidade real, não teatro. Mas ela está em **M0 absoluto**: zero linhas em toda tabela de dado real, confirmado por execução direta minha. Não há, hoje, nenhum edge científico, econômico ou de qualquer outro tipo a avaliar nesta linha — só um desenho experimental pronto para rodar.
- **Antes de qualquer rodada real da linha RJ**, dois riscos estruturais autoreconhecidos pelo próprio projeto deveriam ser resolvidos, não porque eu exijo, mas porque o próprio código já os documenta como bloqueadores de interpretação: (a) a censura por empresa (`censoring_horizon_trading_days`) está morta no código, o que enviesaria o denominador do primeiro julgamento real; (b) a análise de poder já mostra que mesmo com efeitos grandes (1σ), N≈40 dá só 68% de poder — isto é, **mesmo um resultado "significativo" na primeira rodada real terá de ser lido com ceticismo adicional dado o tamanho de amostra estruturalmente pequeno do fenômeno**, um limite que nenhuma correção de código resolve (é uma restrição do próprio universo de empresas em RJ na B3, não um bug).
- Dada a natureza de altíssimo risco/iliquidez do nicho RJ e o fato de que, mesmo em caso de "sinal preditivo confirmado", a distância até "edge capturável líquido de custos, impostos e slippage real em papéis ilíquidos" é enorme e não endereçada por nenhum código atual — **capital real permanece corretamente proibido** (`capital_permission = FORBIDDEN`), e nada nesta auditoria sugere que essa trava deva ser flexibilizada tão cedo.

**Não recomendo ENCERRAR** a linha RJ: o desenho é bom o suficiente para merecer a próxima etapa (dado real), e o custo de já ter construído a maquinaria está afundado — mas a expectativa deve ser calibrada para baixo dado o problema de poder estatístico, e o veredito de "M0, nada julgado" deve continuar sendo tratado como o estado real do projeto, não como um detalhe temporário.

---

## Apêndice — comandos executados nesta auditoria (reprodutibilidade)

```bash
uv sync --all-extras --python 3.13                 # ambiente real, wheels oficiais
uv run pytest -q -v                                  # 242 passed em 95.41s, 0 falhas
uv run python main.py --help                         # lista de comandos reais (erro amigável)
uv run python src/rj_power.py --n-companies 20 30 --effects 0.5 1.0 --fast
uv run python src/rj_power.py --n-companies 40 --effects 1.0 --fast
python3 audit_db.py / diagnose_universe.py / poc_leak.py   # (com uv run após montar venv)
git log --oneline -- audit_db.py diagnose_universe.py poc_leak.py trials.json ...
git show --stat 614f9ac / 93a4d0f
```
