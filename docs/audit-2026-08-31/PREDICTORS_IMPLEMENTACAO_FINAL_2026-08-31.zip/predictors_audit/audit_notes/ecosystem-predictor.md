# Auditoria — `ecosystem-predictor`

**Escopo:** somente este repositório. **HEAD auditado:** `e690594e51543b608bea83b2ec71228e539dfc07` (branch `main`, merge de `docs/final-reconciliation-2026-08-24`). **Data de congelamento:** 2026-08-31. **Auditor:** cético, independente, evidence-first.

## 0. Metodologia e taxonomia

**Rótulos de afirmação:**
- `FACT` — observado diretamente (arquivo, git log, execução).
- `INFERENCE` — conclusão lógica a partir de FACTs.
- `HYPOTHESIS` — hipótese não testada, formulada para investigação futura.
- `RECOMMENDATION` — recomendação de ação.

**Taxonomia de evidência:** CONFIRMADO · PARCIALMENTE CONFIRMADO · CLAIM DOCUMENTAL · CONTRADITÓRIO · STALE · NÃO REPRODUZÍVEL · INVALIDADO · INCONCLUSIVO · NÃO TESTADO · MISSING EVIDENCE.

**Níveis de verificação (definidos por este auditor, aplicados de forma consistente):**
- **L0** — claim sem nenhuma checagem.
- **L1** — lido em um único documento do próprio repo (claim documental pura).
- **L2** — inspecionado estaticamente no código-fonte/config (grep/leitura), sem execução.
- **L3** — inferido de metadados objetivos (git log, datas, contagem de commits/linhas).
- **L4** — executado dentro do próprio ambiente de teste do repo (fixtures/mocks/monkeypatch — prova o mecanismo, não a integração real).
- **L5** — reproduzido localmente com pelo menos uma dependência real, mas cenário parcial.
- **L6** — reproduzido de ponta a ponta com artefatos reais de produção (wheels reais do GitHub Releases, os três pacotes de domínio reais instalados juntos, execução real do código não modificado).

Todas as afirmações relevantes para a decisão de portfólio abaixo trazem o nível entre colchetes, ex. `[L6]`.

**O que foi efetivamente executado nesta auditoria (não apenas lido):**
- `git log`/`git show` completos sobre `src/ecosystem/registry/__init__.py` e `docs/adr/0001-plugin-protocol-v1.md`.
- Criação de dois venvs Python 3.13 reais (`/home/claude/predictors_audit/scratch/ecosystem/.venv*`) com `uv`.
- Instalação real, via `uv pip install -e`, de `ecosystem-predictor`, `cripto-predictor`, `brasileirao-predictor` e `stocks-predictor` **juntos no mesmo ambiente** — incluindo download real dos wheels `predictor_core-2.3.0` e `predictor_ops-3.1.0` do GitHub Releases citados no `pyproject.toml`.
- Execução real de `ecosystem.registry.Registry.discover()` contra os três `entry_points` reais dos três domínios (não fixtures).
- Execução real da suíte de testes (`pytest`/`coverage`) em ambiente isolado (só `ecosystem-predictor[dev]`) e em ambiente combinado (com os três domínios instalados).

Este nível de reprodução (`[L6]`) não está registrado em nenhum documento do repositório para os três domínios canônicos atuais — o único precedente documentado (ADR 0001, 2026-08-03) reproduziu o mecanismo apenas contra `lol-predictor`, um repositório hoje fora do escopo canônico.

---

## A. Tese original e histórico real (seções 14–16)

### A.1 O repositório não nasceu como software

`FACT` [L3] O primeiro commit (`982b258`, 2026-07-17, "Initial commit: workspace governance documentation") não contém nenhuma linha de código de aplicação. A mensagem do commit descreve explicitamente o repositório como "a dedicated repository for cross-project governance docs and config that don't belong to any single domain project", e seu próprio `.gitignore` exclui deliberadamente os diretórios de todos os projetos-irmãos ("tools", "predictor_core", "f1-predictor", "e o resto"). O primeiro arquivo de código de produção (`src/ecosystem/...`) só aparece no commit `9d53e53`, 2026-08-02 — **16 dias e ~30 commits depois**, sob o título "feat: scaffold ecosystem-predictor aggregator platform (Fase 5)".

`FACT` [L3] Dos 140 commits do repositório, apenas **8** tocam `src/`; **110** tocam arquivos Markdown.

`FACT` [L3] Contagem de linhas no HEAD: `src/` = 918 linhas; `tests/` = 906 linhas; Markdown na raiz = 6.734 linhas; Markdown em `docs/` = 748 linhas. Razão documentação:código de produção ≈ **8,1 : 1** (contando só a raiz) ou ≈ **7,4:1** somando `docs/`.

`INFERENCE`: a tese original do repositório, tal como o próprio histórico de commits a demonstra, não foi "construir uma plataforma agregadora" — foi consolidar documentação de auditoria/governança de um workspace multi-repositório muito mais amplo (a versão mais antiga fala em "2 camadas canônicas — `tools/`, `predictor_core` — 5 consumidores vivos e 3 projetos protegidos (PARKED)", ver `ECOSYSTEM_FINAL_CLOSURE.md` linha 11). O código (`registry`/`gateway`/etc.) foi adicionado depois, como uma "Fase 5" dentro desse processo de governança já em andamento, não como ponto de partida.

### A.2 A definição de "escopo canônico" mudou pelo menos 4 vezes na vida do repositório

`FACT` [L3, cronologia por `git log`]:
1. **2026-07-17** (`ECOSYSTEM_FINAL_CLOSURE.md`): ecossistema descrito como 2 camadas (`tools/`, `predictor_core`) + 5 "consumidores vivos" + 3 "PARKED".
2. **2026-08-02/03** (ADR 0001, docstring de `registry/__init__.py`): 5 domínios ativos — `lol-predictor`, `cs-predictor`, `cripto-predictor`, `f1-predictor`, `brasileirao-predictor` — nenhum deles é `stocks-predictor`.
3. **README.md, linha 113**: menciona um "snapshot de nove repositórios de 2026-08-17" (`ECOSYSTEM_CURRENT_STATE.md`), preservado como histórico.
4. **2026-08-23** (`ECOSYSTEM_CHARTER.md`, decisão humana explícita): 6 repositórios canônicos — `ecosystem-predictor`, `core-predictor`, `predictor-ops`, `cripto-predictor`, `brasileirao-predictor`, `stocks-predictor`. `lol-predictor`, `cs-predictor`, `f1-predictor`, `wc-predictor`, `nba-predictor` "não fazem parte dos seis projetos canônicos atuais".

`INFERENCE`: o escopo do "ecossistema" é ele mesmo uma variável em constante redefinição — não uma arquitetura estável sendo documentada, mas um objeto ainda sendo decidido enquanto o código é escrito. Isso por si só é evidência relevante para a decisão de portfólio: não houve um período estável em que a composição atual (6 repos, 3 domínios econômicos) existisse por mais de ~8 dias antes do congelamento desta auditoria (Charter em 23/08, HEAD em 24/08, congelamento em 31/08).

### A.3 "Fechamentos finais" recorrentes que nunca são finais

`FACT` [L1/L3] O repositório contém pelo menos 6 documentos com "final"/"fechamento"/"closure" no nome ou no corpo, todos declarando encerramento formal em datas diferentes: `ECOSYSTEM_FINAL_CLOSURE.md` (17/07, "**Veredito: PASS FINAL COM PENDÊNCIAS NÃO BLOQUEANTES**"), `FINAL_DOCUMENTATION_CLOSURE.md` (18/07), `FECHAMENTO_2026-07-26.md`, `CODEX_FINAL_HANDOFF.md`, `FINAL_FORENSIC_REVIEW.md`, `FINAL_REMEDIATION_REPORT.md`, `TCC_EVIDENCE_CLOSURE.md`. Cada um se posiciona como o documento definitivo de encerramento de um ciclo.

`FACT` [L2] O **último commit do repositório antes do congelamento** (`3658604`, 24/08/2026, "docs: add clean-slate Codex audit prompt") não é um fechamento — é `CODEX_AUDIT_FROM_ZERO_2026-08-24.md`, um **prompt para iniciar uma nova auditoria "do zero"**, que instrui explicitamente: *"Não quero que você presuma que README, HANDOFF, comentários, nomes como 'canonical/source of truth', testes verdes ou conclusões anteriores estejam corretos."*

`INFERENCE`: o próprio dono do ecossistema, na última ação registrada neste repositório, trata todas as "conclusões anteriores" (incluindo os múltiplos "FINAL"/"fechamento" listados acima) como não confiáveis o suficiente para servir de base a uma nova auditoria. Isso é a evidência mais forte disponível de que os "fechamentos" anteriores não fecharam nada de fato — cada um foi seguido por reaberturas (ex.: `dd10761` "docs: record predictor-stocks reopening across canonical documents", 19/07; `PENDENCIAS_ABERTAS.md` linha 1: "Esta seção substitui a antiga alegação de que a lista de 2026-07 permanecia integralmente corrente"). Este é um padrão de **auditoria recorrente sem convergência**, não um processo de maturação linear.

`RECOMMENDATION`: qualquer novo ciclo de auditoria/governança sobre este ecossistema deveria vir acompanhado de um critério de saída objetivo e crível (ex.: N dias sem novo achado P0/P1, ou entrega de valor econômico verificável) — caso contrário, o padrão observado (auditoria → fechamento declarado → reabertura → nova auditoria) tende a se repetir indefinidamente e é, ele mesmo, um custo de portfólio a ser contabilizado (ver seção D).

### A.4 O resultado econômico de fundo, na última contagem auditável

`FACT` [L1] `VEREDITOS_2026-07-26.md`: das 42 hipóteses registradas nos 6 repositórios de domínio da época (incluindo os hoje fora de escopo), **8 COMPROVADA** (qualidade de previsão, não lucro), **12 REFUTADA/NO-GO**, **5 INCONCLUSIVA**, resto diverso. Citação direta: *"Hipóteses econômicas aprovadas para capital: zero."*

`FACT` [L6, reproduzido nesta auditoria] O `capability_snapshot()` real, obtido instalando e executando os três domínios canônicos atuais, retorna `capital_permission=CapitalPermission.FORBIDDEN` para os três (`cripto`, `brasileirao`, `stocks`) — consistente com o veredito de 26/07 ainda valendo em 24/08, sem nenhum domínio promovido a capital habilitado.

`INFERENCE`: não há, em nenhum documento datado até o congelamento, evidência de lucro líquido auditável demonstrado por nenhum dos 3 domínios econômicos. O objetivo declarado no Charter ("expectativa de lucro líquido positivo de forma prospectiva e auditável") permanece, pela própria contabilidade interna do ecossistema, não alcançado.

---

## B. Arquitetura (seção 17)

Mapa de `src/ecosystem/`:

| Componente | O que faz (FACT, leitura direta) | Classificação | Evidência/nível |
|---|---|---|---|
| `registry/` | Descoberta de plugins via `importlib.metadata.entry_points(group="predictor.plugins")`; fail-closed por design (plugin quebrado vira "degraded", nunca cai silenciosamente) | **ESSENCIAL** (é a única função que de fato diferencia este repo de "só documentação") — mas ver §C para os limites reais do que essa "essencialidade" garante | [L6] mecanismo funciona; integração multi-domínio real tem bug (§C.2) |
| `contracts/v1.py` | Modelos Pydantic (`PluginV1`, `HealthReport`, `CapabilityManifest`, enums de estado) | **ÚTIL** — vocabulário compartilhado real, 100% coberto por teste, usado pelos 3 domínios reais na prática | [L6] `capability_snapshot()` validou de fato contra os 3 pacotes reais |
| `gateway/` (FastAPI app, rotas `domains`/`health`, auth JWT) | HTTP wrapper fino sobre o registry; `/healthz`, `/readyz`, `/v1/domains`, dispatch de `predict()` | **ÚTIL, mas nunca operado com tráfego real** — nenhuma evidência de deploy real (ver §B.2) | [L4] só testado via `TestClient` in-process contra fixture |
| `cache/` (Redis) | Cliente Redis genérico (`get`/`set`/`delete`/`ping`) | **PREMATURO / DORMANT** — classe existe, 100% coberta em teste isolado, mas **nunca é instanciada em `create_app()`/nenhuma rota** | [L2] `grep` confirma zero uso fora do próprio módulo e dos testes |
| `storage/` (S3/MinIO) | Cliente S3-compatível (`put`/`get`/`exists`) | **PREMATURO / DORMANT** — mesmo padrão: existe, testado isoladamente, nunca chamado pela aplicação | [L2] idem |
| `db/` (SQLAlchemy + Alembic) | Uma única tabela (`RequestAudit`) + CLI de migração | **PREMATURO / DORMANT** — `database_url` é campo obrigatório (app recusa subir sem Postgres configurado), mas nenhuma rota grava nela; `db/models.py` tem **0% de cobertura de teste** | [L5, reproduzido: `coverage report` real mostrou `db/models.py … 0%`] |
| `scheduler/` | `probe_domains_job` — wrapper fino que delega a `predictor_ops.run_job` | **CONVENIENTE, mas não comprovado em produção** — testado só com `run_job` mockado (`unittest.mock.patch`), nunca uma execução real de subprocesso/job runner | [L4] `tests/unit/test_scheduler.py` usa mock, não subprocess real; `scheduler/cli.py` e `scheduler/probe.py` têm **0% de cobertura** |
| `telemetry/` | Configuração idempotente de OpenTelemetry tracing | **CONVENIENTE** — pequeno, testado, mas sem OTLP endpoint real configurado em nenhum ambiente observado (exporta pro console em teste) | [L4] |

### B.1 A infraestrutura pesada é, hoje, majoritariamente decorativa

`FACT` [L2/L5] `compose.yaml` provisiona **Postgres, Redis, object-storage (MinIO), um coletor OTel e um serviço `migrate`**, além do gateway. `Settings` (`src/ecosystem/settings.py`) declara `database_url`, `redis_url` e `object_storage_bucket` como campos **obrigatórios** (sem default) — o processo recusa subir sem eles.

`FACT` [L6, reproduzido] `create_app()` (`gateway/app.py`) só instancia `Settings`, `Registry` e o tracer no lifespan. Não há nenhuma instância de `CacheClient`, `ObjectStorage`, engine SQLAlchemy ou sessão de banco em nenhum lugar do caminho HTTP. `healthz` declara explicitamente no docstring que "does not touch the registry, Redis, Postgres, or any domain"; `readyz` só consulta o registry em memória.

`INFERENCE`: a plataforma exige, para simplesmente **subir**, um Postgres e um bucket S3 configurados — mas nenhum desses dois sistemas é lido ou escrito por nenhum caminho de código exercitado pelos testes ou pelas rotas HTTP reais. Isso é o padrão clássico de infraestrutura construída **antes** da necessidade (a hipótese de trabalho do usuário para esta auditoria), não decorrente dela. A única tabela definida (`request_audit`) nunca recebe uma linha em nenhum teste ou rota.

`RECOMMENDATION`: antes de qualquer decisão de "manter", medir concretamente se Postgres/Redis/S3 são de fato necessários para o próximo passo real (ex.: auditoria de requisições) ou se podem ser removidos do `compose.yaml`/`Settings` sem perda, reduzindo a superfície operacional a gateway + registry + telemetry, que são as três partes com uso demonstrado.

### B.2 Testes: execução real desta auditoria

`FACT` [L5, executado nesta sessão em ambiente isolado, `uv venv` Python 3.13.13, só `ecosystem-predictor[dev]` + `fakeredis`]:
```
70 passed in 8.41s
coverage: 83% (459 statements, 75 missed)
```
Módulos com 0% de cobertura: `db/models.py`, `gateway/__main__.py`, `scheduler/cli.py`, `scheduler/probe.py`. Isso contradiz (não de forma maliciosa, apenas por estar desatualizado) o número registrado em `docs/GO_CHECKLIST.md` ("47 passed… 81%", 02/08/2026) — o número mudou porque a suíte cresceu (47→70 testes), mas o próprio `GO_CHECKLIST.md` nunca foi atualizado após 02/08.

`FACT`: comandos oficiais do README (`uv run ruff check`, `uv run pyright`, `uv run coverage run -m pytest -q`) foram parcialmente reproduzidos (pytest/coverage, sim; ruff/pyright não foram executados nesta sessão por não serem centrais à decisão de portfólio — **NÃO TESTADO**, e não é assumido que passariam).

---

## C. Utilização real (seções 35–37)

### C.1 Nenhum teste do próprio repositório usa um domínio real

`FACT` [L2] Todos os testes de `tests/contract/`, `tests/unit/test_registry.py` e `tests/e2e/` usam `tests/fixtures/reference_plugin` (uma implementação de brinquedo) ou `EntryPoint`s monkeypatchados manualmente. Nenhum teste versionado neste repositório instala `cripto-predictor`, `brasileirao-predictor` ou `stocks-predictor` de verdade.

`FACT` [L2] O único precedente documentado de reprodução real do mecanismo de descoberta contra um pacote de domínio de verdade é a atualização de 03/08/2026 do ADR 0001, contra **`lol-predictor`** — um repositório que, pelo Charter de 23/08, está **fora do escopo canônico atual**. Não existe, em nenhum lugar do repositório, um registro equivalente para `cripto-predictor`, `brasileirao-predictor` ou `stocks-predictor`.

### C.2 Reprodução real feita nesta auditoria — achado central

`FACT` [L6, reproduzido de ponta a ponta nesta sessão, não documentado em nenhum lugar do repositório]:

Instalei os três domínios canônicos reais (`cripto-predictor==1.0.0`, `brasileirao-predictor==0.1.0`, `stocks-predictor==0.1.0`) junto com `ecosystem-predictor` no mesmo ambiente Python 3.13 e rodei `Registry.discover()` sem modificar nada:

```
entry_points(group="predictor.plugins"):
  stocks      -> src.ecosystem_plugin:PLUGIN   (dist: stocks-predictor)
  cripto      -> GarimpoInvestimentos.plugin:PLUGIN (dist: cripto-predictor)
  brasileirao -> src.ecosystem_plugin:PLUGIN   (dist: brasileirao-predictor)

Registry.discover().list_domains() -> ['brasileirao', 'cripto', 'stocks']
todos os três: loaded=True, error=None  (nenhum degradado)

>>> registry.get('stocks').instance is registry.get('brasileirao').instance
True
```

**O plugin registrado sob o nome `stocks` é, de fato, o mesmo objeto Python do plugin `brasileirao`.** `health_snapshot()['stocks']` retorna `domain='brasileirao'`, e `capability_snapshot()['stocks']` retorna os dados de capacidade do Brasileirão, não de Stocks.

**Causa raiz confirmada:** `brasileirao-predictor` e `stocks-predictor` empacotam seu adapter sob o **mesmo nome de pacote de topo, literal e não-namespaced, `src`** (`tool.hatch.build.targets.wheel.packages = ["src", ...]` em ambos os `pyproject.toml`). Quando os dois são instalados juntos (editable ou wheel), o Python resolve `import src` para um único caminho — nesta reprodução, o diretório de `brasileirao-predictor` "vence" (as entradas `.pth` de instalação editável são processadas em ordem alfabética: `_editable_impl_brasileirao_predictor.pth` antes de `_editable_impl_stocks_predictor.pth`), e a importação `src.ecosystem_plugin:PLUGIN` do entry-point `stocks` acaba carregando o módulo de `brasileirao-predictor`. O nome `src.ecosystem_plugin` é idêntico nos dois `pyproject.toml` — inclusive **visível lado a lado no próprio `README.md` deste repositório** (linhas 107–108: `brasileirao = src.ecosystem_plugin:PLUGIN` / `stocks = src.ecosystem_plugin:PLUGIN`) e na tabela de `ECOSYSTEM_MECHANICAL_STATE.md` — sem que ninguém tenha sinalizado a colisão, porque o "estado mecânico" é gerado lendo texto de `pyproject.toml` via API do GitHub (`scripts/sync_canonical_ecosystem_facts.py`), **nunca instalando e executando o código real**.

`INFERENCE`: o design "fail-closed" do registry (documentado extensivamente no docstring e no ADR 0001 como sua principal garantia de segurança) **não cobre este caso**. Fail-closed protege contra "plugin não carrega" ou "plugin não implementa o protocolo" — mas aqui o plugin carrega com sucesso, implementa o protocolo com sucesso, e devolve dados errados silenciosamente. Isso é um "sucesso incorreto", estruturalmente invisível ao próprio mecanismo de proteção que o repositório mais enfatiza.

`FACT` [L6, segunda colisão real encontrada] Ao rodar a suíte de testes do próprio `ecosystem-predictor` num ambiente onde `brasileirao-predictor` também está instalado, a coleta de testes **falha**:
```
ImportError: cannot import name 'sync_ecosystem_facts' from 'scripts'
(.../brasileirao-predictor/scripts/__init__.py)
```
Causa raiz: mesmo padrão — `brasileirao-predictor` empacota um segundo pacote de topo genérico chamado `scripts` (com `__init__.py`, portanto um pacote Python de verdade), que colide com o diretório `scripts/` do próprio `ecosystem-predictor` (que não é um pacote — não tem `__init__.py` — e depende de resolução de path local). Com `brasileirao-predictor` instalado, `import scripts` resolve para o pacote de `brasileirao-predictor`, não para o diretório local, e `tests/test_ecosystem_facts.py` quebra na coleta.

`FACT` [L2] O workflow de CI (`.github/workflows/ci.yml`) só faz `actions/checkout` deste repositório e `uv sync` das suas próprias dependências (que incluem `predictor-core`/`predictor-ops` via wheel, mas **não** os três domínios). CI nunca instala os três domínios juntos com `ecosystem-predictor`; por isso, nenhuma das duas colisões acima é ou seria detectada pela pipeline atual.

`INVALIDADO`: a afirmação em `ECOSYSTEM_MECHANICAL_STATE.md` ("os três agora expõem um adapter pelo mesmo entry-point group `predictor.plugins`, tornando a superfície de descoberta **mecanicamente verificável**") é tecnicamente verdadeira sobre o nome do grupo, mas **enganosa sobre o resultado prático**: a superfície é *legível*, mas quando de fato *verificada* (o que esta auditoria fez e o repositório nunca fez), o resultado é um dos três domínios silenciosamente substituído por outro.

### C.3 Classificação de utilização real por componente

| Componente | Classificação | Evidência |
|---|---|---|
| `registry` (mecanismo de descoberta) | **ACTIVE, mas com defeito real não coberto por teste** — os 3 domínios reais o satisfazem individualmente [L6]; juntos, colidem [L6] | ver C.2 |
| `contracts` (vocabulário Pydantic) | **ACTIVE** — validado de ponta a ponta contra os 3 pacotes reais [L6] | `capability_snapshot()` real |
| `gateway` HTTP | **DECLARED** — código real, testado em isolamento, **sem evidência de nenhuma requisição HTTP real em produção** | MISSING EVIDENCE de deploy |
| `cache`/`storage`/`db` | **DORMANT** — código existe e é testado isoladamente, mas zero uso em qualquer caminho exercitado pela aplicação real | grep + coverage 0%/50% |
| `scheduler` | **DECLARED** — desenhado para se apoiar no job runner do `predictor-ops`, nunca executado como subprocesso real nesta auditoria nem, pelas evidências disponíveis, em nenhum lugar registrado | mock-only tests, 0% cobertura no CLI |
| Os 3 domínios em relação ao `ecosystem-predictor` | **UNIDIRECTIONAL / INDIRECT** — nenhum domínio importa `ecosystem`/`ecosystem_predictor` em código de produção (achado prévio, não questionado por esta investigação); a única ponte é o entry point, que funciona parcialmente (ver C.2) | grep prévio + confirmado |

### C.4 Teste contrafactual — "o que quebraria se `ecosystem-predictor` desaparecesse amanhã?"

`INFERENCE`, com base em tudo acima: **nada nos três domínios econômicos quebraria em nível de código** — nenhum deles importa este pacote, e nenhum deles depende dele para rodar. O que se perderia seria:
1. A capacidade teórica (nunca operada com tráfego real observável) de um gateway HTTP único que dispatcha para os três domínios.
2. O vocabulário compartilhado de estados (`ScientificStatus`, `PredictiveStatus`, etc. em `contracts/v1.py`) — mas isso é ~70 linhas de Pydantic, replicável em qualquer um dos outros repositórios (ex.: `core-predictor`, que já é a dependência efetivamente compartilhada pelos três domínios) sem a bagagem de Postgres/Redis/S3/scheduler.
3. Um repositório de governança/documentação — mas essa função poderia, em princípio, viver em qualquer um dos outros 5 repositórios ou num repo de documentação puro, sem 918 linhas de código de aplicação nem infraestrutura de container.

`RECOMMENDATION`: tratar a pergunta "o gateway HTTP algum dia será realmente necessário, dado que hoje nada o chama e os domínios já se comunicam via entry point in-process (sem rede)?" como uma pergunta central antes de investir mais nele.

---

## D. Economia da infraestrutura (seção 38)

`FACT` [L3]:
- **Custo de manutenção documental:** 40+ arquivos Markdown de auditoria/fechamento/handoff na raiz do repositório, somando >7.400 linhas — mais de 7x o volume do código de produção que supostamente documentam.
- **Custo de retrabalho:** pelo menos 4 redefinições de escopo canônico em ~40 dias de histórico (§A.2); pelo menos 6 "fechamentos finais" declarados, nenhum definitivo o suficiente para impedir uma auditoria "do zero" no dia seguinte ao último fechamento (§A.3).
- **Custo de infraestrutura provisionada sem uso demonstrado:** Postgres + Redis + object storage (MinIO) + coletor OTel, todos exigidos para o processo sequer iniciar (`Settings` obrigatório), com 0%–50% de cobertura de teste nos módulos que os usam e nenhum caminho de aplicação real que os toque (§B.1).
- **Custo de staleness não detectada:** pelo menos 3 artefatos correntes no HEAD (docstring de `registry/__init__.py`, ADR 0001, `.env.example`, `docs/GO_CHECKLIST.md`) descrevem um ecossistema de 5 domínios anterior ao Charter, incluindo `ECOSYSTEM_REQUIRED_DOMAINS=lol,cs` **ainda presente no `.env.example` do HEAD** — referenciando dois domínios que o próprio Charter (23/08) classifica como fora do escopo canônico. Nenhum desses arquivos foi tocado desde 03/08/2026, apesar da reconciliação P0/P1 de 23–24/08 ter reescrito o escopo canônico.

`INFERENCE`: o benefício demonstrável hoje é estreito e específico — um vocabulário de estados compartilhado (`contracts/v1.py`) e um mecanismo de descoberta de plugins que funciona em teste isolado mas tem um bug real e não detectado quando os três domínios reais são combinados. O custo — em complexidade de infraestrutura provisionada, em volume documental a manter consistente, e em ciclos de auditoria recorrentes sem convergência — é desproporcional a esse benefício, dado que nenhum dos três domínios depende deste repositório para funcionar e nenhum deles tem hipótese econômica aprovada para capital.

---

## E. Hipóteses de monetização alternativa (seções 35, 49) — não testadas, apenas formuladas

`HYPOTHESIS` H-ECO-1: Se algum dia mais de um domínio precisar rodar simultaneamente sob um único gateway HTTP autenticado (ex.: um painel único de operação humana para os 3 predictors), o `gateway`+`registry`+`contracts` têm valor real — **mas isso pressupõe corrigir primeiro a colisão de módulos (§C.2)**, testável objetivamente instalando os 3 domínios juntos em CI.

`HYPOTHESIS` H-ECO-2: O vocabulário de estados (`scientific_status`/`predictive_status`/`economic_status`/`capital_permission`) tem valor de governança independente do resto da infraestrutura — testável avaliando se ele sobreviveria como um pequeno pacote adicionado a `core-predictor` (que já é consumido de verdade pelos 3 domínios) sem Postgres/Redis/S3/scheduler/gateway em volta.

`HYPOTHESIS` H-ECO-3: Não há evidência de qualquer cliente/usuário externo a este ecossistema de propriedade única; portanto, um modelo de "control plane como produto" (SaaS de agregação de predictors para terceiros) não tem nenhuma evidência de demanda no repositório — não deve ser assumido sem validação externa explícita.

`MISSING EVIDENCE`: não há, em nenhum documento lido, qualquer registro de usuário, cliente ou operador além do próprio dono do ecossistema.

---

## F. Matriz de contradições internas

| # | Claim A | Fonte A (data) | Claim B | Fonte B (data) | Mais recente | Classificação |
|---|---|---|---|---|---|---|
| 1 | Grupo canônico de entry point é `predictor.plugins`; cripto usa `ecosystem_predictor.plugins` (grupo diferente); f1/brasileirao não declaram entry point algum | docstring de `registry/__init__.py` + ADR 0001 (02–03/08/2026) | Os 3 domínios econômicos atuais (cripto/brasileirao/stocks) declaram `predictor.plugins` de forma uniforme | `ECOSYSTEM_MECHANICAL_STATE.md`, `pyproject.toml` dos 3 domínios (23–24/08/2026), confirmado por `[L6]` nesta auditoria | B | **STALE** — A nunca foi atualizado após a reconciliação P1; A também cita domínios (`lol`, `cs`, `f1`) hoje fora do escopo canônico do Charter |
| 2 | `ECOSYSTEM_REQUIRED_DOMAINS=lol,cs` | `.env.example` (03/08/2026, nunca alterado depois) | Domínios canônicos são `cripto`, `brasileirao`, `stocks` | `ECOSYSTEM_CHARTER.md` (23/08/2026) | B | **STALE** — arquivo de configuração de exemplo, presente no HEAD, referencia domínios fora de escopo |
| 3 | "Essa integração comprova apenas compatibilidade arquitetural/descoberta" (implicando que a descoberta, ao menos, funciona) | `README.md` linha 111 (24/08/2026) | Instalando os 3 domínios reais juntos, `stocks` carrega de fato o objeto `brasileirao` (colisão de módulo `src`) | Reprodução desta auditoria `[L6]`, nunca documentada no repositório | Reprodução (31/08/2026) | **CONTRADITÓRIO / INVALIDADO** — a "descoberta mecanicamente verificável" nunca foi de fato verificada com os 3 pacotes reais juntos; quando verificada, falha silenciosamente |
| 4 | "47 passed… coverage 81%" | `docs/GO_CHECKLIST.md` (02/08/2026) | 70 passed, coverage 83% | Execução real desta auditoria (31/08/2026) | reprodução | **STALE** (não é uma contradição factual — a suíte cresceu — mas o documento nunca foi atualizado e pode ser lido como número corrente) |
| 5 | Pelo menos 6 documentos se declaram "FINAL"/fechamento definitivo entre 17/07 e 26/07/2026 | `ECOSYSTEM_FINAL_CLOSURE.md`, `FINAL_DOCUMENTATION_CLOSURE.md`, `FECHAMENTO_2026-07-26.md`, etc. | Último commit do repositório (24/08/2026) é um prompt para recomeçar a auditoria "do zero", instruindo a não confiar em nenhuma conclusão anterior | `CODEX_AUDIT_FROM_ZERO_2026-08-24.md` | B (mais recente e mais autoritativo por ser a última ação do próprio dono) | **CONTRADITÓRIO** — "final" foi declarado repetidamente sem nunca de fato encerrar o ciclo |
| 6 | Postgres/Redis/S3 são dependências obrigatórias de configuração (`Settings` sem default) | `settings.py` (código, atual) | Nenhum caminho de aplicação real (rotas HTTP, registry) lê ou escreve nesses sistemas | Leitura de código + `coverage report` real (`db/models.py` 0%) | ambos atuais, não há "mais recente" — é uma tensão estrutural, não temporal | **CONTRADITÓRIO** (design vs. uso real, não staleness) |

---

## Checkpoint obrigatório (seção 54)

`MISSING EVIDENCE`: o texto exato das 13 perguntas da "seção 54" do documento-mãe da auditoria não estava disponível para este agente (apenas a referência foi passada, não o conteúdo). As perguntas abaixo são a reconstrução de boa-fé de um checklist de triagem de portfólio consistente com o resto do mandato desta auditoria (manter/testar/reformular/combinar/congelar/reduzir/encerrar), respondidas com o mesmo rigor de evidência do resto deste documento. Se o documento-mãe tiver perguntas com redação diferente, este bloco deve ser tratado como resposta ao espírito, não à letra, das 13 perguntas originais.

1. **Este repositório resolve um problema real hoje, comprovado por uso?**
   Não de forma completa. `contracts`/`registry` funcionam tecnicamente [L6], mas nenhum consumidor real usa o `gateway` HTTP, e a integração multi-domínio real (o problema que o registry supostamente resolve) está quebrada quando testada de verdade (§C.2).

2. **Algum domínio econômico depende dele para operar?**
   Não. `[FACT, confirmado por grep prévio e não contestado]` Nenhum dos 3 domínios importa este pacote em código de produção.

3. **O mecanismo central (plugin registry) funciona de ponta a ponta com os 3 domínios reais?**
   Parcialmente. Individualmente sim [L6]; em conjunto, não — um dos três (`stocks`) é silenciosamente substituído pelo outro (`brasileirao`) por colisão de nome de módulo (§C.2). **Este é o achado mais importante desta auditoria.**

4. **A infraestrutura provisionada (Postgres/Redis/S3/OTel) é necessária hoje?**
   Não, pela evidência disponível — nenhum caminho de aplicação real a utiliza (§B.1). É PREMATURA em relação ao uso demonstrado.

5. **Existe evidência de lucro ou de valor econômico direto atribuível a este repositório?**
   Não. O objetivo econômico é dos 3 domínios, não do control plane; e mesmo nos domínios, hipóteses aprovadas para capital = zero (§A.4), confirmado ainda válido no `capability_snapshot()` real (`capital_permission=FORBIDDEN` nos 3).

6. **O volume de documentação de auditoria/fechamento é proporcional ao valor entregue?**
   Não — razão de ~7–8:1 documentação:código de produção (§A.1, §D), com múltiplos ciclos de "fechamento final" que não convergiram (§A.3).

7. **Os "fechamentos" anteriores implementaram suas próprias recomendações?**
   Parcialmente e de forma inconsistente. Ex.: a recomendação do ADR 0001 (renomear o grupo de entry point de `cripto-predictor`) foi implementada — os 3 domínios hoje usam `predictor.plugins` — mas a documentação que descreve esse estado (o próprio ADR, o docstring do registry, `.env.example`, `GO_CHECKLIST.md`) nunca foi atualizada para refletir a correção (Contradição #1, #2).

8. **Há dependência circular ou acoplamento perigoso entre este repo e os domínios?**
   Não — o acoplamento é unidirecional (ecosystem descobre os domínios; nenhum domínio importa ecosystem), o que é uma decisão de design defensável e efetivamente verificada [L6].

9. **O time/pessoa consegue operar isso sem a documentação (i.e., o código se sustenta sozinho)?**
   Parcialmente — código com boa cobertura de teste (83% real) e comentários adequados, mas a suíte quebra em ambiente combinado com um domínio real instalado (§C.2, segunda colisão), o que não é coberto por nenhum runbook.

10. **Existe algum caminho de baixo custo para corrigir o achado mais crítico (colisão `src`/`scripts`)?**
    Sim, em princípio — renomear os pacotes de topo de `brasileirao-predictor`/`stocks-predictor` para nomes namespaced (ex. `brasileirao_predictor.ecosystem_plugin`) resolveria a colisão. **Isso está fora do escopo desta auditoria (não fazer correções) e fora do escopo deste repositório** (mudança pertence aos repositórios de domínio), mas é um achado de portfólio relevante porque nenhum dos 6 repositórios documentou ou testou esse risco.

11. **A composição canônica de 6 repositórios é estável o suficiente para justificar investimento continuado no control plane?**
    Não demonstrado — 4 redefinições de escopo em 40 dias (§A.2), a mais recente com apenas ~8 dias de vida até o congelamento desta auditoria.

12. **Que evidência mudaria a recomendação preliminar?**
    (a) Uma correção real e testada da colisão de módulos com um teste de CI que instale os 3 domínios juntos; (b) qualquer domínio econômico atingindo `capital_permission` diferente de `FORBIDDEN` com evidência prospectiva auditável; (c) uso real e observável do gateway HTTP por um consumidor (humano ou automatizado) fora dos testes.

13. **Qual é o risco de simplesmente encerrar/congelar este repositório hoje?**
    Baixo para os 3 domínios econômicos (não dependem dele — §C.4). Médio para a governança documental (perde-se um local único de charter/contrato, mas o conteúdo poderia migrar para `core-predictor`, que já é a dependência real compartilhada). O maior risco de **não agir** é continuar provisionando infraestrutura (Postgres/Redis/S3) e ciclos de auditoria sem que o mecanismo central (registry multi-domínio) funcione de fato.

---

## Recomendação preliminar

**REDUZIR** (com um componente específico marcado para **MANTER+TESTAR** antes de qualquer novo investimento).

### Justificativa

1. O valor real e verificado deste repositório hoje se resume a duas coisas pequenas: (a) o vocabulário de estados em `contracts/v1.py` (~70 linhas, 100% testado, validado contra os 3 domínios reais) e (b) o mecanismo de descoberta via `entry_points`, que funciona individualmente mas **falha silenciosamente quando os 3 domínios reais são combinados** — o único cenário em que um "control plane agregador" tem razão de existir. Este é o achado com maior confiança e maior impacto de decisão desta auditoria: `[L6]`, reproduzido de ponta a ponta, não documentado em nenhum lugar do repositório.

2. Toda a infraestrutura pesada (Postgres, Redis, object storage, scheduler via subprocess, coletor OTel) está provisionada e obrigatória para o processo iniciar, mas **sem nenhum uso demonstrado em nenhum caminho de código real exercitado** (0%–50% de cobertura nos módulos correspondentes, zero chamadas a partir do `gateway`). Isso corresponde exatamente à hipótese de "infraestrutura construída antes da necessidade" levantada no mandato desta auditoria.

3. Nenhum domínio econômico depende deste repositório para operar (confirmado, não apenas herdado da investigação prévia). O teste contrafactual (§C.4) não encontra quebra funcional imediata em nenhum dos 3 domínios se este repositório desaparecesse amanhã.

4. O padrão histórico do próprio repositório — 4 redefinições de escopo, 6+ "fechamentos finais" não convergentes, terminando na própria véspera do congelamento com um pedido de auditoria "do zero" que descarta explicitamente as conclusões anteriores — é evidência comportamental de um processo de governança que consome esforço desproporcional ao valor entregue (razão documentação:código ≈ 7–8:1).

5. **Não é ENCERRAR** porque o vocabulário de contratos e o próprio mecanismo de registry, uma vez corrigida a colisão de módulos e coberto por um teste de integração real com os 3 domínios instalados juntos em CI, têm um caso de uso concreto e barato de manter (o gateway HTTP para dispatch multi-domínio). **Não é MANTER como está** porque isso significaria continuar operando Postgres/Redis/S3/scheduler sem uso demonstrado e sem ter corrigido o bug central que invalida a premissa "descoberta mecanicamente verificável entre os 3 domínios reais".

### Ação concreta recomendada (fora do escopo de execução desta auditoria, mas registrada como recomendação)
- Reduzir a superfície a `registry` + `contracts` + `gateway` (dropar `cache`/`storage`/`db`/`scheduler` do `compose.yaml` e de `Settings` até haver um consumidor real de cada um).
- Antes de qualquer novo trabalho de feature: adicionar um teste de CI que instale os 3 domínios reais (`cripto-predictor`, `brasileirao-predictor`, `stocks-predictor`) junto com `ecosystem-predictor` e rode `Registry.discover()` contra eles — exatamente o que esta auditoria fez manualmente e que teria capturado a colisão de módulos antes de qualquer promoção de "mecanicamente verificável".
- Sincronizar `.env.example`, `docs/GO_CHECKLIST.md`, o docstring de `registry/__init__.py` e o ADR 0001 com o escopo canônico atual do Charter, ou marcá-los explicitamente como históricos (a política de `STALE` já existe no próprio Charter — §7 — mas não foi aplicada a esses 4 arquivos).

### Nível de confiança desta recomendação

**Alto** para os achados factuais centrais (§A.1, §C.2, §B.1) — todos reproduzidos com `[L6]`/`[L3]` diretos, não dependentes de interpretação. **Médio** para a recomendação de portfólio em si (REDUZIR vs. REFORMULAR), porque a decisão final depende de informação fora do escopo desta auditoria (prioridades de negócio do dono, custo real de operar Postgres/Redis gerenciados, e se um gateway HTTP multi-domínio é de fato um requisito de produto futuro ou apenas conveniência arquitetural antecipada).
