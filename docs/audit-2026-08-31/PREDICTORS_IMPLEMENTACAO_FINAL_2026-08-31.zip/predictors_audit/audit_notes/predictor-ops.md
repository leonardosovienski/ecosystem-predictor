# Auditoria técnica — `predictor-ops`

**Repositório:** `predictor-ops` (isolado, 1 de 6 no ecossistema PREDICTORS)
**HEAD auditado:** `c2f2ee0e03c5e37a2a379df2e27be0ae9e4c56e3` (branch `main`)
**Versão declarada:** `3.1.0` (pyproject.toml, confirmado)
**Data do congelamento:** 2026-08-31
**Auditor:** agente técnico independente (leitura + execução; zero commits/edições)
**Regra de leitura:** repositório tratado como somente-leitura; nenhum arquivo rastreado foi alterado. Scripts auxiliares de verificação viveram em `/home/claude/predictors_audit/scratch/ops/` (não foi necessário criar nenhum além do diretório).

---

## Taxonomia de evidência usada neste documento

| Rótulo | Significado |
|---|---|
| CONFIRMADO | Verificado por mim, diretamente (execução, leitura de código, grep exaustivo) |
| PARCIALMENTE CONFIRMADO | Verificado em parte; resto é plausível mas não testado |
| CLAIM DOCUMENTAL | Só README/CHANGELOG/docs afirmam; não testei |
| CONTRADITÓRIO | Documento e código (ou dois documentos) se contradizem |
| STALE | Documento descreve um estado que já não é verdade (plano vencido, prazo passado) |
| NÃO REPRODUZÍVEL | Tentei reproduzir e não consegui (ambiente, dependência ausente) |
| INVALIDADO | Testei e o claim é falso |
| INCONCLUSIVO | Evidência mista, não dá para decidir |
| NÃO TESTADO | Poderia ter testado mas não foi prioritário/possível no escopo |
| MISSING EVIDENCE | Não há como verificar com o que está disponível (ex.: máquina Windows real de produção) |

Níveis de confiança: **L0** (nenhuma evidência) a **L6** (reproduzido de ponta a ponta, múltiplas vezes, em produção real). A maior parte deste relatório atinge **L4–L5** (execução real neste ambiente, código lido linha a linha) — nunca L6, porque não tenho acesso à máquina Windows de produção do dono nem aos runtimes reais dos 3 domínios.

Rótulos de análise: **FACT** (fato observado), **INFERENCE** (dedução razoável a partir de fatos), **HYPOTHESIS** (especulação plausível não confirmável aqui), **RECOMMENDATION** (ação sugerida).

---

## A) Tese original e histórico (git log, CHANGELOG, README)

**FACT [CONFIRMADO, L5]** `git log` mostra 91 commits, autor único humano (`Leonardo Sanches Sovienski`, 3 variantes de identidade git — mesma pessoa) mais commits automáticos do `dependabot[bot]` (8) e 3 commits co-autorados por "Claude". **Bus factor = 1.** Não há segundo contribuidor humano em nenhum commit.

**FACT [CONFIRMADO, L5]** O primeiro commit (`b24e283`, 2026-07-15) chama-se "Version operational tooling" e já assume uma base de código pré-existente chamada `tools/` — um módulo **flat, não instalável, consumido via `sys.path` compartilhado de um workspace-raiz** com 5 domínios irmãos. Isso foi confirmado lendo `git show d0accd6:HANDOFF.md` (arquivo depois deletado no commit de reescrita `56b78b4`), que descreve o estado de `tools/` em 2026-07-18:

> "Prover a 5 consumidores vivos (brasileirao-predictor, cs-predictor, f1-predictor, lol-predictor, previsao-cripto) primitivas operacionais genéricas... **Sem instalação via pacote** — decisão consciente... consumo é por `sys.path` compartilhado do workspace-raiz."

**INFERENCE [L4]** O ecossistema PREDICTORS tinha, em algum ponto anterior a este congelamento, **pelo menos 5 domínios ativos** (incluindo `cs-predictor`, `f1-predictor`, `lol-predictor`, que não constam entre os 3 domínios atuais do escopo desta auditoria: cripto-predictor, brasileirao-predictor, stocks-predictor). Isso é uma descoberta relevante para a auditoria estratégica maior: **o ecossistema encolheu de ~5 domínios para 3**, e nomes mudaram (`previsao-cripto` → `cripto-predictor`; `stocks-predictor` não existe nessa lista de 2026-07-18, sugerindo que é mais recente que `cs`/`f1`/`lol`, que por sua vez parecem ter sido descontinuados). Não tenho evidência direta de quando/por que `cs`, `f1`, `lol` saíram — **MISSING EVIDENCE** (fora do escopo deste repo; recomendo cruzar com `ecosystem-predictor`).

**FACT [CONFIRMADO, L5]** O commit `56b78b4` ("modernize predictor operations platform (#3)") é uma reescrita completa: deleta `operational_runner.py`, `secret_redaction.py`, `tools_provenance.py`, `release_manifest.py`, `run_hidden.py`, `release_check.py`, `vendor_byte_audit.py` e toda a suíte `tests/` (13 arquivos, incluindo testes com nomes de domínios específicos: `test_brasileirao_operational_entrypoint.py`, `test_cs_operational_entrypoint.py`, `test_lol_operational_entrypoint.py`) e cria do zero `src/predictor_ops/` + `tests_v2/`. **Isso explica o nome "tests_v2": não é iteração de teste, é o marco literal da reescrita v1→v2** (de módulo flat "tools" para pacote instalável "predictor_ops"). CHANGELOG confirma: "2.0.0 — Replace the workspace-bound `tools` tree with the installable `predictor_ops` package... Remove sibling-repository contracts, workspace-root configuration, domain names, and PowerShell schedulers."

**FACT [CONFIRMADO, L5]** A pasta `migration/` (e sua contraparte `docs/removed-operations-migration-plan.md`, `docs/legacy-behavior-migration-matrix.md` com 149 linhas de testes históricos rastreados um a um) existe para governar essa transição de arquitetura: workspace-relativo/sys.path/PowerShell → wheel instalável/CLI portátil. **"Migration" = migração da geração 1.x (`tools/`, acoplada a Windows e a um workspace multi-repo) para a geração 2.x/3.x (`predictor_ops`, instalável, cross-platform).**

**FACT [CONFIRMADO, L5]** README e CHANGELOG (3.0.0) documentam uma segunda reformulação arquitetural importante, dentro da própria era `predictor_ops`: separação de `RunStatus` (operacional) vs `scientific_state` (opaco, nunca interpretado pela lib) — commit `3ca6995` "feat!: separação operacional/científica, RunStatus expandido". E a 3.1.0 adiciona um schema v2 completo com "chave econômica canônica", 8 tipos de job, kill-switch fail-closed, idempotência de execução e log de auditoria encadeado (hash chain) — claramente motivado por um caso de uso de **execução de capital real** (só existe em `cripto-predictor`, ver seção E).

**RECOMMENDATION:** cruzar a saída de "5 domínios → 3" com `ecosystem-predictor` para confirmar quando/por que `cs-predictor`, `f1-predictor`, `lol-predictor` desapareceram — é um dado importante para a decisão estratégica sobre o ecossistema como um todo (histórico de mortalidade de domínios).

---

## B) Arquitetura (`src/predictor_ops`)

Mapa completo (14 módulos, 1517 linhas de código de produção):

| Módulo | Linhas | Função real (lida linha a linha) |
|---|---|---|
| `models.py` | 166 | Modelos Pydantic: `JobConfig`, `RunStatus`, `JobType`, `EconomicJobKey`, `KillSwitchLimits`, `RiskSnapshot`, `RuntimeConfig`. Validação fail-closed extensa (`extra="forbid"`, NUL em comandos, unicidade de `economic_key`, `capital_permission` só em `EXECUTION`). |
| `runner.py` | 306 | Núcleo: `run_job()`. Spawna subprocesso, isola em process-group próprio, drena stdout/stderr em thread separada com redação em tempo real, heartbeat periódico com refresh de lock, timeout, terminação de árvore de processos completa (POSIX: SIGTERM→SIGKILL em process group; Windows: `taskkill /T /F`), cleanup determinístico de handles/streams mesmo em exceção. |
| `runtime.py` | 227 | Backends de coordenação: `LocalBackend` (lock via arquivo com `O_CREAT|O_EXCL`, detecção de dono morto via `os.kill(pid,0)`/`OpenProcess`, quarentena de lock obsoleto) e `RedisBackend` (`SET NX PX` + `WATCH/MULTI` para refresh/release seguro contra concorrência). Escrita atômica de JSON (`os.replace` com retry para `PermissionError` do Windows) e append de JSONL com lock de arquivo próprio + fsync. |
| `audit.py` | 117 | `AppendOnlyAuditLog`: cadeia de hash (SHA-256 encadeado) para o ciclo `snapshot→forecast→decision→order→fill→settlement`, com validação de transição de estágio e verificação de corrupção antes de cada append (a cadeia inteira é re-verificada a cada `append()` — O(n), ver nota abaixo). |
| `operations.py` | 68 | `retry_action()` (mapa de estado de ordem → ação de retry) e `kill_switch_reasons()` (checagem fail-closed de limites de risco antes de abrir posição). |
| `redaction.py` | 80 | Redação determinística de segredos via regex (Bearer, `key=value`, querystring, flags de CLI), com piso de tamanho mínimo (12 chars) documentado explicitamente contra falsos positivos por substring. |
| `provenance.py` | 101 | Verifica hash SHA-256 de cada arquivo do wheel instalado contra `RECORD`; falha fechado para instalação editável ou incompleta; modo `--source-root` para checkout git limpo. |
| `health.py` | 55 | Avalia heartbeat + status do scheduler para decidir se um job está saudável (stale, ausente, falhou). |
| `windows.py` | 80 | Adapter isolado e explicitamente "transitional" para Windows Task Scheduler (consulta via PowerShell). Nunca importado pelo runtime portátil (confirmado por grep — só `health.py` e testes importam). |
| `cli.py` | 75 | `predictor-ops run/validate/provenance`. |
| `config.py` | 48 | Fontes de config: arquivo local e HTTP (HTTPS-only). |
| `observability.py` | 56 | Log JSON estruturado + OpenTelemetry opcional. |
| `compat/legacy.py` | 57 | Tradutor de flags do runner 1.x para `JobConfig` — usado apenas nos testes de contrato de consumidor (`tests_v2/test_consumer_contracts.py`), gera `DeprecationWarning`. |
| `compat/vendor_audit.py` | 49 | Auditoria byte-a-byte genérica de árvores de arquivos (substitui o antigo `vendor_byte_audit.py` acoplado a nomes de domínio). |

### Classificação por componente

| Componente | Classificação | Justificativa |
|---|---|---|
| `runner.py` (execução, locks, timeout, cleanup de processo) | **ESSENCIAL** | É o único componente com uso funcional real e não-trivial confirmado em produção (cripto-predictor, `jobs.py`). Reimplementar corretamente terminação de árvore de processo + redação em tempo real + locks com detecção de dono morto é trabalho não-trivial que `cron` sozinho não oferece. |
| `redaction.py` | **ÚTIL** | Consumido por 2 dos 3 domínios de forma direta (`cripto-predictor/security/redaction.py`, `brasileirao-predictor/scripts/sombra_diaria_payload.py`). Lógica pequena (80 linhas) e replicável, mas evita reinventar regex de segredos em cada domínio. |
| `models.py` (schema v2, `EconomicJobKey`, kill-switch, idempotência) | **ÚTIL para 1 domínio, PREMATURO para os outros 2** | Todo o aparato de `capital_permission`/`kill_switch_limits`/`RiskSnapshot`/`OrderState` só faz sentido para execução real de capital — **hoje isso só existe de fato em `cripto-predictor`** (ver seção E). Em `brasileirao-predictor` e `stocks-predictor` não há execução de capital nenhuma; o schema v2 completo é peso morto para eles. |
| `audit.py` (hash-chain) | **PROVAVELMENTE DESNECESSÁRIO hoje / PREMATURO** | Feature sofisticada (cadeia de hash com verificação O(n) a cada append) que não encontrei sendo consumida por nenhum domínio nos greps (nenhuma ocorrência de `AppendOnlyAuditLog` fora de `predictor-ops` e seus próprios testes). Parece ter sido construída em antecipação a um caso de uso de auditoria financeira formal que ainda não existe operacionalmente. |
| `provenance.py` (verificação de wheel/RECORD) | **ÚTIL** | Usado ativamente por `cripto-predictor/scripts/verify_installed_wheels.py` e pelo próprio CLI (`predictor-ops provenance`), e citado no CI de todos os 3 domínios como smoke-test de instalação. Testei e funciona corretamente (ver seção D). |
| `runtime.py` backend Redis | **CONVENIENTE / DORMANT em produção observável** | Código correto (testei com Redis real, 3/3 passaram), mas não encontrei nenhum domínio configurando `backend: "redis"` em produção — os `jobs*.json` reais usam todos `"backend": "local"`. Feature construída, testada, mas sem consumidor confirmado. |
| `windows.py` (Task Scheduler adapter) | **LEGACY / TRANSITIONAL (auto-rotulado)** | O próprio README chama de "transitional Windows adapter" e diz que o runtime portátil "never imports" esse módulo. Só é usado por `health.py` (opcionalmente) e pelos testes `windows_integration/` (não executáveis neste ambiente Linux). |
| `compat/legacy.py` | **DORMANT / LEGACY morrendo** | Só existe para os testes internos de "contrato de consumidor" que emulam o 1.x. Nenhum consumidor real (`cripto`, `brasileirao`, `stocks`) importa `predictor_ops.compat` — confirmado por grep nos 3 repositórios. É andaime de teste, não código de produção consumido. |
| `compat/vendor_audit.py` | **DORMANT** | Nenhum uso encontrado nos 3 domínios (grep exaustivo, ver seção C/E). Existe para o cenário "consumidor vendoriza `predictor_core` e eu audito" — `stocks-predictor` de fato tem `vendor/predictor_core` (confirmado em `STOCKS_CURRENT_STATE.md`), mas usa checagem própria (`gitleaks`/hash manual), não esta função. |
| `migration/windows/*.ps1` (5 scripts, 392 linhas) | **LEGACY, formalmente vencido** | Ver achado crítico abaixo. |
| `posix_integration/`, `windows_integration/`, `integration_tests/` | **ÚTEIS mas de execução condicional** | Nomes descrevem a natureza da suíte (testes que precisam de SO/serviço real), não uma hierarquia de depreciação. `posix_integration` roda e passa neste ambiente; `windows_integration` não roda (esperado — ver seção D); `integration_tests` (Redis) só roda com `PREDICTOR_OPS_TEST_REDIS_URL` setado — eu configurei um Redis real e rodei, passou. |
| `tests_v2/` | **Nome histórico, não indica problema de qualidade** | "v2" é literalmente a versão 2 da arquitetura (ver seção A), não um sinal de suíte malfeita relançada. |

### Achado crítico: prazo de remoção formalmente vencido

**FACT [CONFIRMADO, L5]** `migration/windows/README.md` declara:

> "Removal condition: every referenced scheduled task invokes the installed `predictor-ops` CLI and has passed two cadences plus its consumer-owned wheel contract. **Target removal: 3.0.**"

A versão atual é **3.1.0**. `docs/removed-operations-migration-plan.md` também marca cada um dos 5 scripts como `TRANSITIONAL` com condições de remoção específicas ("remove after Windows task migration", "TRANSITIONAL until each known consumer no longer vendors core", etc.), nunca atualizadas para `REMOVED`.

**STALE.** O plano de remoção documentado não foi cumprido no prazo que o próprio projeto se deu. Isso é consistente e explicado por outro achado desta auditoria: **a condição de remoção depende de todos os consumidores terem migrado completamente — e isso não aconteceu** (`stocks-predictor` não usa a lib operacionalmente de verdade; `brasileirao-predictor` mantém tarefas "legacy" explicitamente desabilitadas em vez de removidas, ver seção E). O próprio `docs/audit-evidence.md` do repositório é honesto sobre isso: "Consumer-owned repositories were not edited or executed by instruction... each consumer must still install the built wheel and pass its own CI before its transitional adapter and retained PowerShell rollback assets can be removed." O status formal que o próprio repo se atribui é **`READY_WITH_BLOCKERS`**, não `READY` — isso é uma autoavaliação inusitadamente honesta para um projeto solo.

---

## C) Overlap com ferramentas existentes / baseline de complexidade

**Comparação concreta e honesta, funcionalidade por funcionalidade encontrada no código (não no marketing do README):**

| Funcionalidade real (confirmada no código) | Airflow/Prefect/Dagster fariam isso? | `cron` + script Python faria isso? |
|---|---|---|
| Executar um comando, capturar stdout/stderr | Sim, nativamente | Sim, trivialmente |
| Timeout + terminação de toda a árvore de processos (não só o filho direto) | Sim (Airflow/Prefect têm isso) | **Não out-of-the-box** — precisa de `subprocess.run(..., timeout=...)` + `killpg`, ~20-30 linhas |
| Lock distribuído com detecção de dono morto (evitar dupla execução) | Sim (via executor/scheduler central) | **Não out-of-the-box** — precisa de arquivo de lock + PID check, ~30-40 linhas |
| Heartbeat/lease periódico | Sim (heartbeat de worker) | **Não** — precisa implementar |
| Redação de segredos em stdout/stderr/logs/JSON | Não nativamente (Airflow tem *connections* mas não redige texto livre de output) | **Não** — precisa implementar (mas é pequeno: ~80 linhas, como aqui) |
| Escrita atômica de estado (heartbeat.json, JSONL) com fsync | Parcial (depende do backend) | **Não** — precisa implementar |
| Verificação de proveniência do pacote instalado (hash do wheel) | Não é isso que essas ferramentas fazem | **Não**, é um problema diferente (supply-chain), não de orquestração |
| Kill-switch de risco/capital antes de abrir posição | Não (é lógica de negócio, nenhuma dessas ferramentas tem isso nativamente) | **Não** — é lógica de domínio, teria que ser escrita de qualquer forma, em qualquer stack |
| Log de auditoria em cadeia de hash (append-only, anti-corrupção) | Não nativamente | **Não** — mas também não encontrei uso real disso (ver seção B) |
| Agendamento (schedule, cron, DAG, retries automáticos entre execuções) | **Sim — é o core dessas ferramentas** | Sim (via `cron`) |
| UI de observação, histórico de execuções, alertas | **Sim — vantagem grande dessas ferramentas** | Não |

**INFERENCE [L4]:** `predictor-ops` **não é um orquestrador/scheduler** — ele explicitamente delega agendamento para "systemd, Kubernetes, Nomad, cron, etc." (citação literal do README) ou para o Windows Task Scheduler nativo. Ele é uma **biblioteca de wrapper de execução single-job** (lock + heartbeat + timeout + redação + terminação de processo + verificação de proveniência), não um orquestrador de DAGs. Isso significa que a comparação correta não é "predictor-ops vs. Airflow completo", mas sim "predictor-ops vs. a fatia de Airflow/Prefect que trata de *task execution hardening*" — que é uma fatia pequena dessas ferramentas.

**RECOMMENDATION / resposta à pergunta da seção 18 (baseline de complexidade):** **Parcialmente sim, mas não totalmente.** Um `cron` + um script Python "hardened" de ~150-250 linhas (timeout com `killpg`, lock de arquivo com PID check, wrapper de redação reaproveitando `redaction.py` como está — ele já é pequeno e autocontido) provavelmente cobriria 70-80% do valor real hoje consumido (o que `cripto-predictor` usa: `run_job`, `JobConfig`, `RunStatus`, heartbeat, redação). Os 20-30% que ficariam de fora seriam: verificação de proveniência de wheel (que tem valor de supply-chain real, mas é um problema ortogonal a "rodar jobs"), o backend Redis (não usado em produção observável), e o schema v2 econômico completo com kill-switch e hash-chain de auditoria (usado só por 1 domínio, e mesmo lá não confirmei consumo do hash-chain). **Não escolheria nem o extremo "reescrever tudo em Airflow" nem "é indispensável e insubstituível"** — a arquitetura atual (biblioteca fina, sem servidor, sem scheduler próprio) já é, na verdade, uma escolha de baixa complexidade relativa comparada a adotar Airflow/Dagster/Prefect (que exigiriam infraestrutura de servidor, banco de metadados, worker pool) para um ecossistema de 3 domínios rodando via Task Scheduler local. O ponto fraco não é "framework pesado demais", é **"peso morto acumulado dentro de uma lib que em si é enxuta"** (schema v2 econômico, hash-chain, backend Redis, compat/vendor_audit, migration/windows — tudo construído, testado, mas sem consumidor confirmado).

**Valor como ferramenta externa (fora do ecossistema PREDICTORS)?** **HYPOTHESIS [não testável aqui]:** o núcleo (`runner.py` + `redaction.py` + `runtime.py`) é genérico o bastante (100% domain-neutral, sem nenhuma referência a nomes de domínio nem a `predictor_core`) para ser útil como lib standalone para "rodar comandos com lock/heartbeat/redação/timeout" em qualquer contexto de scheduled-task Windows/Linux. Mas o schema v2 econômico (kill-switch, `EconomicJobKey`, hash-chain) é claramente acoplado ao caso de uso de trading/apostas e não teria apelo genérico. Não há nenhuma evidência de uso fora do ecossistema PREDICTORS (não está no PyPI público — README confirma: "They are not on public PyPI", distribuído só via GitHub Releases dos 3 consumidores conhecidos).

---

## D) Execução da suíte de testes (resultado real, reproduzido por mim)

Ambiente: Python 3.13.13 (via `uv`), `uv sync --all-extras` bem-sucedido sem intervenção.

| Suíte | Comando | Resultado real observado |
|---|---|---|
| `tests_v2/` (suíte principal) | `uv run pytest --cov --cov-report=term-missing` | **80 passed** em 40.46s; **cobertura total 88.02%** (gate exige ≥80%, passou) |
| `posix_integration/` | `uv run pytest posix_integration -v` | **1 passed** (`test_sigterm_reaches_cli_and_kills_child`) |
| `integration_tests/` (Redis) sem servidor | `uv run pytest integration_tests -v` | **1 skipped** (corretamente — exige `PREDICTOR_OPS_TEST_REDIS_URL`) |
| `integration_tests/` (Redis) **com servidor real** | subi `redis-server` local na porta 6399 e setei `PREDICTOR_OPS_TEST_REDIS_URL` | **3 passed** — fui além do que o `docs/audit-evidence.md` do próprio repo reporta ("Not run" nesse checkout), e **confirmei independentemente que o backend Redis funciona de verdade** (dois processos, um vencedor; TTL/refresh/release; desconexão/reconexão) |
| `windows_integration/` | `uv run pytest windows_integration -v` | **1 failed, 1 error** — `FileNotFoundError: powershell.exe` e `assert os.name == 'nt'` falha. **Limitação de ambiente esperada e documentada aqui**, não defeito de código: este ambiente é Linux, os testes verificam integração real com Windows Task Scheduler via PowerShell, que não existe aqui. Não é possível validar esses testes neste ambiente. |
| `ruff check` / `ruff format --check` | — | Ambos passam ("All checks passed!", "43 files already formatted") |
| `pyright` (modo standard) | — | **0 erros, 0 avisos** |
| CLI smoke real (`predictor-ops run --job-id smoketest ...`) | executei manualmente | **Funciona de ponta a ponta**: heartbeat.json e events.jsonl escritos corretamente, `run_status: SUCCEEDED`, `library_provenance` corretamente reportado como `UNVERIFIED` (esperado — instalação editável, não wheel) |
| `predictor-ops provenance --source-root .` | executei manualmente | Retornou `identity_status: VALIDATED` no commit `c2f2ee0...`, worktree limpo — correto |

**Conclusão sobre D:** os números que o próprio `docs/audit-evidence.md` afirma (80 passed, 87.87% cobertura) são **CONFIRMADOS de forma independente** por mim (obtive 88.02%, diferença mínima plausível por ambiente/timing, mesma ordem de grandeza). Isso é incomum e positivo: a maior parte dos repositórios que auditei documentalmente costuma exagerar; aqui o autodiagnóstico bateu com a reexecução real. **Este é um dos poucos repositórios do ecossistema em que a suíte de testes é executável, passa de verdade, e o autorrelato de evidência resistiu à reverificação independente.**

Limitação honesta: **não pude validar `windows_integration/` neste ambiente (Linux)** — não há evidência independente de que a integração real com Windows Task Scheduler funciona hoje, apenas a suíte de código que a testaria. **MISSING EVIDENCE** para esse pedaço específico.

---

## E) Dependency Value Test — o que quebra se `predictor-ops` sumir amanhã?

Grep exaustivo (todos os tipos de arquivo, não só `.py`) nos 3 domínios, confirmando/aprofundando o achado central fornecido:

### cripto-predictor — quebra funcional real (CONFIRMADO)

Arquivos que importam ou dependem operacionalmente: `GarimpoInvestimentos/jobs.py` (`from predictor_ops import JobConfig, RunResult, RunStatus, run_job` — é o wrapper de execução de todos os jobs operacionais do domínio), `contracts.py` (`RunStatus as OperationalStatus`), `security/redaction.py` (redação de logs construída sobre `predictor_ops.redaction`), `trading/execution.py` (comentário referenciando explicitamente a garantia de idempotência do `predictor_ops`), 3 watchdogs (`watchdog.py`, `phase1_watchdog.py`, `observation_watchdog.py` — leem `PREDICTOR_OPS_STATE_DIR` e o `heartbeat.json` produzido pelo runner para decidir se um job está saudável), scripts `.ps1` de produção (`run_daily.ps1`, `run_daily_v3_payload.ps1`), e 6 arquivos de teste dedicados (`test_jobs_operations.py`, `test_ops_hardening.py`, `test_watchdog_paths.py`, etc.).

**FACT:** Se `predictor-ops` sumisse amanhã, `cripto-predictor` **quebraria de forma funcional real e imediata**: o próprio mecanismo de execução de jobs (`jobs.py`), a detecção de saúde via watchdog, e a redação de segredos em produção dependem diretamente da lib. Isso não é conveniência — é infraestrutura crítica do único domínio que aparenta ter execução de capital real (o schema v2 com `capital_permission`/`kill_switch_limits` do predictor-ops v3.1.0 foi, pela cronologia do CHANGELOG, claramente desenhado para este consumidor).

### brasileirao-predictor — uso real mas parcial, mais raso do que a colocação "capital" sugere, e com sinais de abandono parcial do caminho `predictor_ops` (achado que REFINA a hipótese inicial)

**Achado de correção em relação à premissa fornecida:** a caracterização "usa apenas en passant em 2 scripts (`sombra_diaria.py`, `sombra_diaria_payload.py`) para versão/redação" **estava incompleta**. Encontrei uso mais substancial, mas também descobri que parte dele já foi **desativada**:

1. **FACT [CONFIRMADO]:** `scripts/install_windows_scheduler.ps1` tem uma função `Install-PredictorTask` que aponta diretamente para `.venv\Scripts\predictor-ops.exe` e monta o comando `run --config jobs.market-research.example.json --job <ID> --runtime-root ...`. Essa função é chamada em loop sobre **todos os 11 jobs** do manifesto `jobs.market-research.example.json` (coleta de mercado, fixtures, snapshots de fechamento, e até os jobs do funil H9 de sombra), mais um alias `brasileirao-market-research`. Isso é uso real do runner via CLI, não apenas leitura de versão.
2. **FACT [CONFIRMADO]:** O mesmo script `.ps1`, mais abaixo, desabilita explicitamente tarefas legadas via `Disable-ScheduledTask`, incluindo **`brasileirao-sombra-manha`** e **`brasileirao-sombra-noite`** — que são exatamente as tarefas que o entrypoint `sombra_diaria.py` (o único caminho que invoca `python -m predictor_ops run` via subprocess) foi desenhado para servir. **Ou seja: o caminho mais "canônico" de uso do CLI predictor-ops (`python -m predictor_ops run`) parece estar desativado/legado**, substituído por chamada direta ao executável `predictor-ops.exe` a partir do PowerShell.
3. **CONTRADITÓRIO [confirmado por leitura cruzada, não por execução real]:** os **mesmos scripts Python** dos jobs H9 (ex.: `scripts/emit_h9_shadow.py`) aparecem **duas vezes** no instalador de tarefas agendadas — uma vez via `Install-PredictorTask` (nome `brasileirao-h9-emit-shadow`, disparado pelo loop sobre o manifesto JSON, envolvido pelo runner com lock/heartbeat) e uma segunda vez via `Install-ScriptTask` (nome diferente, `brasileirao-h9-emit`, chamando `python.exe` diretamente, sem o wrapper). Isso é uma inconsistência estrutural real do repositório `brasileirao-predictor` (**não posso confirmar se isso causa dupla execução em produção real — MISSING EVIDENCE, não tenho acesso à máquina Windows do dono** — mas a duplicação de tarefas agendadas apontando para o mesmo script é verificável estaticamente e é, no mínimo, um sinal de arquitetura não resolvida).
4. `docs/MODERNIZATION.md` afirma "new scheduling uses `predictor_ops` and is portable" — mas o funil H9 (que parece ser a lógica de decisão mais atual/importante do domínio, conforme nomeação e cadência de 15 min) é instalado via `Install-ScriptTask`/`Install-PythonModuleTask`, **sem** passar pelo wrapper `predictor-ops.exe`. Isso é uma **contradição parcial** entre o que o documento afirma sobre a arquitetura-alvo e o que o script de instalação realmente faz.

**INFERENCE [L3]:** o valor real hoje de `predictor-ops` para `brasileirao-predictor` é: (a) genuíno para os jobs de coleta/mercado (`COLLECTION_ONLY`), que rodam via `predictor-ops.exe` com lock/heartbeat; (b) **residual/legado** para os antigos jobs "sombra" diária, que foram desabilitados; (c) **ausente** no caminho crítico atual (funil H9), que roda como script Python puro sob Windows Task Scheduler nativo, reimplementando parcialmente retry (`RestartCount 3`) e timeout (`ExecutionTimeLimit`) fora do predictor-ops. Se `predictor-ops` sumisse amanhã, o dano seria: **perda de conveniência real nos jobs de coleta** (perderia lock/heartbeat/redação — teria que reimplementar ou aceitar risco de dupla execução), mas o **funil de decisão H9 continuaria rodando sem alteração nenhuma**, porque já não depende dele.

### stocks-predictor — achado central CONFIRMADO por grep exaustivo

Busquei em **todos** os arquivos do repositório (não só `.py`): `.sh`, `.bat`, `.ps1` (nenhum existe no repo), `.yml`/`.yaml`, `Dockerfile*` (não existe), `config*.yaml`, `.cfg`/`.ini`. Resultado:

| Arquivo | Natureza do uso |
|---|---|
| `pyproject.toml` | Declara dependência (`predictor-ops>=3.1,<4`) + URL do wheel |
| `.github/workflows/ci.yml` | Um único smoke test: `python -c "import predictor_core, predictor_ops, src.rj_episodes, src.rj_judge"` — **apenas verifica que o import não quebra**, não exercita nenhuma função |
| `tests/conftest.py` | `assert "vendor" not in pathlib.Path(predictor_ops.__file__).parts` — verificação de que o pacote **não** veio de um vendor (checagem de proveniência de packaging, não uso funcional) |
| `README.md`, `HANDOFF.md`, `STOCKS_CURRENT_STATE.md`, relatório de auditoria externa (`docs/audit/kimi_2026-08-24/...`) | Menções documentais |
| **`src/` e `main.py`** | **Zero ocorrências** |

**FACT [CONFIRMADO — grep exaustivo, todos os tipos de arquivo, incluindo binários de script que poderiam indicar chamada externa ao CLI]:** não existe `Dockerfile`, `.sh`, `.bat` ou `.ps1` em `stocks-predictor` — logo não há ENTRYPOINT de container nem cron/scheduler externo que pudesse invocar o CLI `predictor-ops` "por fora" do grep de import Python. **A hipótese alternativa levantada na tarefa (uso indireto via subprocess/CLI/scheduler) foi ativamente descartada por ausência de qualquer artefato que a sustentasse.**

Evidência adicional que corrobora, vinda de um relatório de auditoria **externo e independente** presente no próprio repositório (`docs/audit/kimi_2026-08-24/RELATORIO_AUDITORIA_RJ.md`, de outro agente/auditor, tratado aqui como **CLAIM DOCUMENTAL de terceiro**, não verificado por mim, mas coerente com o que confirmei de forma independente): "wheels predictor-core/ops indisponíveis → shim `vendor/predictor_core` + shim local `predictor_ops` via `STOCKS_ALLOW_VENDOR_SHIM=1`... 211 passed / 4 failed". Ou seja, **até um auditor terceiro precisou usar um shim falso no lugar do `predictor_ops` real para rodar a suíte inteira, e a suíte inteira passou mesmo assim** — confirmação indireta forte de que nada em `stocks-predictor` depende operacionalmente do comportamento real da lib.

**CONCLUSÃO DA SEÇÃO E (achado de alto valor decisório, CONFIRMADO):** Se `predictor-ops` sumisse amanhã:
- **cripto-predictor: quebra funcional real** (execução de jobs, watchdogs, redação de segredos param de funcionar).
- **brasileirao-predictor: perda de conveniência real nos jobs de coleta** (lock/heartbeat perdidos, mas substituíveis por Task Scheduler nativo com esforço moderado); **nenhum efeito** no funil de decisão H9, que já não usa a lib.
- **stocks-predictor: praticamente nenhum efeito.** Bastaria apagar 1 linha do `pyproject.toml`, ajustar 1 linha de CI e 2 linhas de `conftest.py`. **Nenhuma linha de lógica de negócio seria afetada.**

---

## F) Economia da infraestrutura / valor como ferramenta externa

**FACT [CONFIRMADO]:** custo de manutenção observável é baixo em termos absolutos — 1517 linhas de produção, 1451 linhas de teste (razão teste:código ~0.96:1, alta para um projeto solo), CI com Dependabot automatizado (8 dos 91 commits são bumps automáticos), pre-commit configurado, cobertura real de 88%. O projeto **não está "puxando peso morto de complexidade de framework"** (não há servidor, não há banco de metadados, não há UI) — seu custo de operação real é próximo de zero (é uma lib instalada via wheel).

**FACT [CONFIRMADO]:** custo de manutenção **de escopo** é mais alto do que sugere o tamanho absoluto: há acúmulo real de funcionalidade construída, testada, documentada e **sem consumidor confirmado** — hash-chain de auditoria (`audit.py`), backend Redis, `compat/vendor_audit.py`, e 392 linhas de PowerShell "transitional" em `migration/windows/` com prazo de remoção formalmente vencido (3.0 → estamos em 3.1.0). Isso é custo de manutenção contínuo (superfície de teste, superfície de CI, superfície cognitiva) pago por uma funcionalidade cujo valor real hoje é, na melhor hipótese, **antecipatório** (para um cenário de execução de capital mais amplo que ainda não existe fora de `cripto-predictor`) e na pior, **especulativo/gold-plating**.

**Valor como ferramenta externa (fora do PREDICTORS):** não há evidência de uso fora do ecossistema (não está no PyPI, é distribuído só via GitHub Release para 3 consumidores conhecidos e nomeados). O núcleo genérico (`runner.py`+`redaction.py`+`runtime.py`) **poderia** ter valor como lib standalone de "task runner hardened" para deploys Windows/Linux sem orquestrador — isso é **HYPOTHESIS**, não FACT; não há sinal de que isso tenha sido tentado ou validado com qualquer usuário fora do ecossistema do próprio autor.

---

## Matriz de uso real (consolidada)

| Componente | Cripto | Stocks | Brasileirão | Uso comprovado | Valor gerado | Custo/complexidade |
|---|---|---|---|---|---|---|
| `run_job`/`JobConfig`/`RunStatus` (runner core) | Uso direto e extenso (`jobs.py`) | Nenhum | Uso via CLI (`predictor-ops.exe run`) para coleta; **não** usado no funil H9 (caminho de decisão mais atual) | CONFIRMADO (cripto e brasileirão-coleta); INVALIDADO (stocks) | Alto (cripto); Médio (brasileirão-coleta); Nulo (stocks) | Médio (306+227 linhas, bem testado) |
| `redaction.py` | Uso direto (`security/redaction.py`) | Nenhum | Uso direto (`sombra_diaria_payload.py`) | CONFIRMADO (2/3) | Médio | Baixo (80 linhas, autocontido) |
| Heartbeat/state dir (`PREDICTOR_OPS_STATE_DIR`) | Uso direto (3 watchdogs leem) | Nenhum | Não encontrado watchdog equivalente | CONFIRMADO (cripto) | Alto (cripto) | Baixo (já parte do runner) |
| `provenance.py` (verificação de wheel) | Uso direto (`verify_installed_wheels.py`) + CI dos 3 domínios | Uso só em CI (smoke import) | Uso em CI | CONFIRMADO (cripto); PARCIAL (CI-only nos 3) | Médio (supply-chain, não operação) | Baixo (101 linhas) |
| Schema v2 econômico (`EconomicJobKey`, `capital_permission`, `kill_switch_limits`, `RiskSnapshot`, `retry_action`) | Provável uso (motivou a versão 3.1.0, mas não confirmei consumo linha-a-linha no domínio) | Nenhum | Nenhum | PARCIALMENTE CONFIRMADO (cripto); INVALIDADO (stocks, brasileirão) | Alto se usado por cripto, mas não 100% confirmado; Nulo nos outros 2 | Alto (166 linhas de modelo + validação complexa) |
| `AppendOnlyAuditLog` (hash-chain) | Nenhum uso encontrado em nenhum domínio | Nenhum | Nenhum | NÃO CONFIRMADO em nenhum domínio | Nulo (observável) | Médio-alto (117 linhas + complexidade O(n) por append) |
| Backend Redis | Nenhum `backend: redis` encontrado em configs reais | Nenhum | Nenhum (`jobs.market-research.example.json` usa `"backend": "local"`) | NÃO CONFIRMADO em produção; CONFIRMADO funcionar tecnicamente (testei) | Nulo (observável) | Médio (código correto, mas dormant) |
| `windows.py` (Task Scheduler adapter) | Não encontrado uso direto (cripto usa `.ps1` mas não `inspect_scheduled_task` diretamente, por grep) | Nenhum | Não encontrado uso direto | INCONCLUSIVO | Indeterminado | Baixo (80 linhas, isolado) |
| `compat/legacy.py`, `compat/vendor_audit.py` | Nenhum | Nenhum | Nenhum | NÃO CONFIRMADO em nenhum domínio (só testes internos) | Nulo | Baixo mas puro custo (106 linhas) |
| `migration/windows/*.ps1` (5 scripts) | Não referenciados fora de si mesmos | Nenhum | Não referenciados | NÃO CONFIRMADO uso ativo; prazo de remoção vencido | Nulo hoje | Baixo em LOC (392 linhas) mas alto em dívida de processo (promessa não cumprida) |

---

## G) Checkpoint obrigatório — 13 perguntas

1. **O que o repositório afirma fazer bate com o que o código realmente faz?**
   Sim, majoritariamente. É um dos repositórios mais honestos que se pode auditar por código: README descreve exatamente o que `runner.py`/`redaction.py`/`runtime.py`/`provenance.py` fazem, sem inflar. A única lacuna é que o README não deixa claro o quão **desigual** é a adoção real entre os 3 consumidores — isso só aparece auditando os consumidores, não o próprio repo.

2. **A suíte de testes é executável e passa de verdade?**
   Sim — CONFIRMADO por execução real neste ambiente (80 passed, 88.02% cobertura; +1 posix; +3 integration com Redis real que eu mesmo subi; pyright e ruff limpos). `windows_integration` não pôde ser validado aqui (limitação de ambiente, não falha do código).

3. **Existe uso real em produção, ou é só infraestrutura teórica?**
   Existe uso real e crítico em pelo menos 1 domínio (`cripto-predictor`). Uso real mas parcial em 1 domínio (`brasileirao-predictor`, e em recuo — o caminho de decisão mais atual, H9, não usa a lib). Uso nominal/decorativo em 1 domínio (`stocks-predictor`).

4. **O achado "stocks não usa predictor-ops de verdade" se sustenta sob investigação exaustiva?**
   Sim, plenamente confirmado — grep exaustivo em todos os tipos de arquivo, ausência de Dockerfile/.sh/.ps1/.bat, e corroborado por um relatório de auditoria externo já presente no próprio repositório `stocks-predictor` que rodou a suíte inteira com um *shim* falso no lugar do pacote real, sem quebrar nada.

5. **`predictor-ops` poderia ser substituído por `cron` + script simples sem perda relevante?**
   Parcialmente — cobriria ~70-80% do valor hoje realmente consumido (o subconjunto usado por cripto/brasileirão-coleta), a um custo de implementação bem menor que adotar Airflow/Prefect/Dagster, mas maior que "só cron" puro (precisaria reimplementar lock+timeout+terminação de árvore+redação, que juntos são ~150-250 linhas). Não é uma escolha óbvia de "sim, jogue fora" nem de "não, é insubstituível" — é uma escolha de trade-off moderado.

6. **Há sinais de over-engineering / gold-plating?**
   Sim, localizados: hash-chain de auditoria sem consumidor confirmado; backend Redis sem uso em produção observável; schema v2 econômico completo (kill-switch, risk snapshot) construído para 1 domínio só, e mesmo lá não 100% confirmado linha-a-linha. Isso não domina o repositório (o núcleo runner/redaction é enxuto e bem focado), mas é uma fração real e crescente do código.

7. **Há dívida de processo não fechada (planos, prazos, promessas)?**
   Sim — o plano de remoção de `migration/windows/*.ps1` tinha alvo explícito na versão 3.0 e continua presente na 3.1.0. O próprio repositório se autoavalia como `READY_WITH_BLOCKERS`, não `READY`, de forma honesta.

8. **Qual o risco de key-person (bus factor)?**
   Bus factor = 1. Único autor humano em 91 commits (mais bot e assistência de IA). Isso é um risco estrutural para qualquer decisão de "manter" — não há segunda pessoa capaz de dar manutenção hoje.

9. **A arquitetura é reversível/decomponível, ou tudo-ou-nada?**
   Altamente decomponível. O núcleo (`runner`+`redaction`+`runtime`) é domain-neutral e poderia sobreviver isolado de tudo o resto (schema econômico, hash-chain, Redis, Windows adapter, compat) sem quebrar sua própria API pública mínima. Isso é uma qualidade arquitetural real e favorece qualquer decisão de "reduzir" em vez de "manter tudo" ou "encerrar tudo".

10. **Existe evidência de valor econômico real gerado pelo uso de `predictor-ops`?**
    Não posso confirmar valor econômico (lucro) — está fora do escopo verificável neste repositório e o próprio `docs/audit-evidence.md` do repo é explícito sobre isso: "no predictive metric, coverage estimate, confidence interval or economic-edge claim is supported by this audit." O que posso confirmar é **valor operacional** (jobs rodam, heartbeats existem, segredos são redigidos) em cripto-predictor — não confundir com valor econômico.

11. **A suíte de testes documentada bate com a suíte reexecutada de forma independente?**
    Sim, com folga pequena (80 passed / 87.87% documentado vs. 80 passed / 88.02% reexecutado por mim). Incomum e positivo em relação a outros repositórios tipicamente auditados por documentação.

12. **Há contradição entre documentos, ou entre documento e código, dentro do próprio repositório?**
    Sim, uma: `docs/removed-operations-migration-plan.md`/`migration/windows/README.md` prometem remoção na 3.0; estamos na 3.1.0 e os arquivos continuam. (A contradição "MODERNIZATION.md diz que H9 usa predictor_ops" pertence tecnicamente a `brasileirao-predictor`, não a este repositório, mas foi verificada cruzando os dois.)

13. **Qual a confiança geral desta auditoria (L0–L6)?**
    **L4-L5** para a maior parte das seções (execução real, leitura completa de todo o `src/`, grep exaustivo nos 3 consumidores, testes reexecutados incluindo Redis real). **L2-L3 (INCONCLUSIVO/MISSING EVIDENCE)** apenas para: comportamento real em produção Windows (não tenho a máquina), efeito real da duplicação de tarefas H9 em brasileirao-predictor (é uma observação estática, não um teste em produção), e a razão histórica exata do encolhimento de 5→3 domínios (fora do escopo deste repo).

---

## Recomendação preliminar

### **MANTER + REDUZIR** (combinação — ver justificativa)

Não é uma escolha única e limpa entre as 7 opções, porque a evidência aponta para conclusões diferentes em partes diferentes do mesmo repositório:

- **MANTER** o núcleo (`runner.py`, `redaction.py`, `runtime.py` local backend, `provenance.py`, `models.py` v1/collection): tem uso real, crítico em 1 domínio, testado de forma confiável, e o custo de reescrever de forma equivalente em `cron`+script não é claramente menor o suficiente para justificar a migração — ROI de "manter" é positivo aqui.
- **REDUZIR** (podar) o que não tem consumidor confirmado: `AppendOnlyAuditLog`/`audit.py`, o backend Redis (a menos que haja um plano concreto e datado para usá-lo), `compat/vendor_audit.py`, e — mais urgente — **cumprir ou revisar formalmente o prazo de remoção vencido de `migration/windows/*.ps1`** (392 linhas de PowerShell morto que o próprio projeto já classificou como candidato a remoção há uma versão inteira).
- **NÃO ENCERRAR**: seria desproporcional dado que há uso funcional real e crítico confirmado em `cripto-predictor` (watchdogs e execução de jobs dependem dele hoje).
- **stocks-predictor especificamente**: a decisão sobre a dependência declarada em `stocks-predictor` (remover a dependência não-usada, ou de fato integrá-la operacionalmente) pertence à auditoria de `stocks-predictor`, não a este repositório — mas o achado é relevante o bastante para ser repassado à síntese do ecossistema como um todo: **hoje, 1 dos 3 "clientes" declarados de `predictor-ops` não gera nenhum valor real para a lib, e isso infla artificialmente a aparência de adoção do ecossistema.**

**Nível de confiança da recomendação: MÉDIO-ALTO (L4).** Alto para as partes verificadas por execução direta (testes, CLI, uso real em cripto/stocks). Médio para a avaliação de brasileirao-predictor (a duplicação de tarefas H9 e o abandono do caminho `sombra_diaria` são leituras estáticas de `.ps1`, não observações de produção real) e para qualquer inferência sobre valor econômico (fora de escopo verificável).

**Risco a monitorar independentemente desta decisão: bus factor = 1** em todo o ecossistema aparente (mesmo padrão de autor único observado aqui provavelmente se repete nos outros 5 repositórios) — isso deveria pesar tanto ou mais que a decisão técnica sobre esta lib específica na síntese estratégica final.
