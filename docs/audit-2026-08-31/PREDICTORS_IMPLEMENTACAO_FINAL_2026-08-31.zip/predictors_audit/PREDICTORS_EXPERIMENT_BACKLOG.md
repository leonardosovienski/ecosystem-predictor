# Backlog de Experimentos — Ecossistema PREDICTORS

Ordenado por valor da informação / custo / tempo (maior prioridade primeiro). Regra aplicada: nenhum item aqui é "construir mais para descobrir depois" — cada um reduz uma incerteza específica e nomeada, com critério de PASS/FAIL definido antes.

---

### Experimento 1 — Corrigir e testar a colisão de módulos em `ecosystem-predictor`

- **Hipótese**: o mecanismo de descoberta de plugins funciona corretamente com os 3 domínios reais instalados juntos, uma vez removida a colisão de nome de módulo `src`.
- **Evidência atual**: hoje falha — `stocks` e `brasileirao` colidem e um é servido como o outro (achado E01/E02 do Evidence Ledger).
- **Principal incerteza**: se a correção (renomear pacotes de topo para namespaced) é suficiente sozinha, ou se há outras colisões não descobertas (ex.: outros pacotes genéricos).
- **Experimento mínimo**: renomear os pacotes de topo de `brasileirao-predictor`/`stocks-predictor` para nomes namespaced; adicionar 1 teste de CI em `ecosystem-predictor` que instale os 3 domínios reais juntos e verifique `registry.get(X).instance is not registry.get(Y).instance` para todo par X≠Y, além de `health_snapshot()[X]['domain'] == X`.
- **Métrica primária**: teste de CI passa/falha (binário).
- **Baseline**: estado atual (teste não existe, bug não corrigido).
- **Critério PASS**: teste novo passa de forma reproduzível em pelo menos 3 execuções consecutivas de CI.
- **Critério FAIL**: qualquer colisão residual detectada.
- **Prazo/amostra**: 1 sprint (dias, não semanas) — é uma correção de nomenclatura, não uma feature nova.
- **Custo aproximado**: baixo (horas de engenharia).
- **Se PASS**: `ecosystem-predictor.registry`/`contracts` passam de REDUZIR para MANTER+TESTAR condicional.
- **Se FAIL**: reforça a recomendação de REDUZIR — o mecanismo central não é confiável mesmo após tentativa de correção.
- **Decisão que este experimento pode mudar**: se `ecosystem-predictor` deve continuar a existir como control plane multi-domínio, ou se o vocabulário de contratos deve simplesmente migrar para `core-predictor` e o resto ser descontinuado.

---

### Experimento 2 — Continuar coleta prospectiva de H6 (cripto-predictor) até poder adequado

- **Hipótese**: sinal invertido do LLM (score alto = queda; score baixo = alta) prevê retorno D+7 de cripto.
- **Evidência atual**: n=0 no último artefato commitado (2026-08-24); desenho prospectivo correto.
- **Principal incerteza**: se há sinal real, e se a coleta de fato avançou desde 24/08 (não visível nos artefatos versionados).
- **Experimento mínimo**: nenhum código novo — apenas continuar a coleta já em andamento e commitar `h6_status.json` a cada atualização real, não só ao atingir marcos.
- **Métrica primária**: Spearman entre score invertido e retorno D+7, com IC95 via bootstrap de bloco.
- **Baseline**: correlação zero (ruído).
- **Critério PASS**: IC95 não cruza zero na direção da hipótese, em n≥250 (poder adequado medido pelo próprio projeto).
- **Critério FAIL**: IC95 cruza zero, ou é significativo na direção oposta, em n≥250.
- **Prazo/amostra**: depende da cadência de coleta diária — estimar prazo real a partir do ritmo histórico de acumulação de n (não estimado nesta auditoria por falta de acesso ao ritmo real).
- **Custo aproximado**: baixo (é coleta passiva, não desenvolvimento).
- **Se PASS**: reabrir avaliação de edge líquido de custos, só então considerar reativar `trading/`.
- **Se FAIL**: encerrar H6 formalmente, arquivar a família LLM-score-D7 por completo (4ª tentativa fracassada).
- **Decisão que este experimento pode mudar**: se `cripto-predictor` tem algum caminho vivo de edge, ou se deve mover para CONGELAR também.

---

### Experimento 3 — Decisão explícita sobre retomada de A1 (brasileirao-predictor)

- **Hipótese**: existe divergência estrutural capturável entre a odds de referência (Pinnacle) e casas soft brasileiras, líquida de fricção.
- **Evidência atual**: protocolo formal pronto; `NOT_STARTED` em 3 checkpoints; automação desligada por pedido do usuário.
- **Principal incerteza**: se, uma vez operacional, a divergência é de fato capturável (limites de stake em casas soft, velocidade de ajuste de linha) — não testável sem coleta real.
- **Experimento mínimo**: rotacionar a chave de API; rodar 7 dias de coleta real em modo shadow (sem capital); auditoria manual de 50 eventos — exatamente como o próprio protocolo já especifica.
- **Métrica primária**: spread médio Pinnacle−soft líquido de fricção estimada (comissão, limites) nos 50 eventos auditados.
- **Baseline**: spread zero (mercados eficientemente arbitrados).
- **Critério PASS**: spread líquido positivo e economicamente relevante em ≥60% dos eventos auditados manualmente.
- **Critério FAIL**: spread líquido não relevante ou inconsistente.
- **Prazo/amostra**: 7 dias de coleta + tempo de auditoria manual (~1-2 semanas totais).
- **Custo aproximado**: baixo-médio (chave de API + tempo de auditoria manual, sem capital em risco).
- **Se PASS**: avançar para uma segunda fase com stake simbólico (paper) antes de qualquer capital real.
- **Se FAIL**: encerrar A1 formalmente — seria a última hipótese econômica viva do Brasileirão a cair, movendo o domínio inteiro para CONGELAR total.
- **Decisão que este experimento pode mudar**: se `brasileirao-predictor` mantém qualquer caminho econômico ativo, ou se passa a ser tratado só como ativo de plataforma/aprendizado.

---

### Experimento 4 — Primeira rodada real da linha RJ (stocks-predictor), condicionada

- **Hipótese**: existem padrões conhecíveis antes de rallies especulativos (≥50%) em ações de empresas em RJ na B3.
- **Evidência atual**: M0 absoluto (zero dado real); poder estatístico estruturalmente baixo (68% a N=40, efeito grande).
- **Principal incerteza**: se o universo real de empresas em RJ na B3 é grande o bastante para qualquer conclusão robusta; se a censura por empresa (hoje morta no código) muda materialmente o resultado.
- **Experimento mínimo**: (a) implementar a regra de censura por empresa no código antes de qualquer ingestão; (b) ingerir os snapshots reais disponíveis da lista de emissores em RJ; (c) rodar o primeiro julgamento formal com LOCO obrigatório.
- **Métrica primária**: efeito estimado por família de features, com IC95 via bootstrap, e resultado do LOCO (o efeito sobrevive à remoção de qualquer empresa individual?).
- **Baseline**: efeito zero.
- **Critério PASS**: pelo menos uma família com IC95 não cruzando zero E robusta a LOCO (não dominada por 1-2 empresas).
- **Critério FAIL**: nenhuma família passa, ou o resultado depende de 1-2 empresas.
- **Prazo/amostra**: depende do universo real de emissores em RJ disponível (não estimável sem a ingestão) — mas o próprio poder já calculado (68% máximo) implica que mesmo um PASS aqui merece ceticismo redobrado.
- **Custo aproximado**: médio (ingestão de dado real + correção de código + tempo de julgamento).
- **Se PASS**: tratar como candidato a validação adicional (nunca capital direto a partir de uma única rodada, dado o poder baixo) — replicar em janela temporal diferente antes de qualquer consideração de capital.
- **Se FAIL**: encerrar formalmente a linha RJ — stocks-predictor passaria a ter as duas teses (fatores e RJ) encerradas, movendo o domínio inteiro para revisão de continuidade.
- **Decisão que este experimento pode mudar**: se `stocks-predictor` mantém qualquer hipótese viva, ou se o domínio inteiro deve ser CONGELADO.

---

### Experimento 5 — Validar (não construir) a hipótese de monetização de `core-predictor`

- **Hipótese**: a governança de pesquisa quant do `core-predictor` (TrialRegistry N+1, power attestation, point-in-time contracts) tem valor comercial para equipes pequenas de pesquisa quant independente fora deste ecossistema.
- **Evidência atual**: nenhuma validação de demanda em nenhum dos 6 repositórios (`HYPOTHESIS`, não `FACT`).
- **Principal incerteza**: se existe alguém disposto a pagar por isso, e por quê (vs. alternativas como mlfinlab, ou simplesmente construir internamente).
- **Experimento mínimo**: 3-5 conversas reais com pesquisadores/equipes quant independentes (não clientes do próprio dono) apresentando o conceito (sem código, sem produto) e perguntando especificamente sobre disposição a pagar e alternativas atuais usadas.
- **Métrica primária**: número de conversas em que a pessoa descreve um problema real não resolvido pela ferramenta atual dela, e reação a uma pergunta direta de preço.
- **Baseline**: zero conversas realizadas até hoje.
- **Critério PASS**: pelo menos 2 de 5 conversas indicam um problema real + reação positiva a preço hipotético.
- **Critério FAIL**: nenhuma conversa indica isso, ou todas apontam para alternativas já satisfatórias.
- **Prazo/amostra**: 2-4 semanas (agendar e realizar as conversas).
- **Custo aproximado**: muito baixo (tempo de conversa, zero código).
- **Se PASS**: considerar um MVP mínimo (documentação pública + 1 exemplo de uso fora do domínio de trading/apostas) antes de qualquer investimento maior.
- **Se FAIL**: não investir em go-to-market; manter `core-predictor` só como infraestrutura interna.
- **Decisão que este experimento pode mudar**: se o Cenário B (monetizar infraestrutura) da Parte XXII do relatório master vale a pena perseguir, ou se deve ser descartado por falta de demanda.

---

### Experimento 6 — Cortar tag de release atualizada de `core-predictor`

- **Hipótese**: os 3 domínios se beneficiariam das correções já feitas no HEAD (`ledger.py`, `trials.py`, `harness.py`) que ainda não estão no wheel publicado `v2.3.0`.
- **Evidência atual**: STALE confirmado — HEAD 4 commits à frente da tag publicada.
- **Principal incerteza**: se as correções pendentes têm impacto material em algum resultado já reportado pelos 3 domínios.
- **Experimento mínimo**: cortar `v2.3.1`/`v2.4.0`; atualizar a URL do wheel nos 3 `pyproject.toml`; rerodar a suíte de testes dos 3 domínios contra a nova versão.
- **Métrica primária**: diff de resultado (testes que mudam de comportamento) entre v2.3.0 e a nova tag.
- **Baseline**: nenhuma mudança de comportamento esperada nos testes existentes (as correções são em módulos majoritariamente dormant).
- **Critério PASS**: nenhuma regressão; qualquer domínio que usava os módulos corrigidos (`ledger`/`trials`/`harness`) confirma comportamento esperado.
- **Critério FAIL**: alguma regressão inesperada aparece.
- **Prazo/amostra**: dias.
- **Custo aproximado**: baixo.
- **Se PASS**: fechar o item de dívida estratégica; documentar como parte de rotina de release.
- **Se FAIL**: investigar antes de propagar a nova tag.
- **Decisão que este experimento pode mudar**: nenhuma decisão de portfólio grande — é higiene de infraestrutura, mas de baixo custo e alto valor de redução de risco de "fonte única da verdade divergente".
